# 🚚 Тоҷрасон — Платформаи Таҳвил

Системаи пурраи таҳвил, монанди Яндекс Доставка, ба забони тоҷикӣ.

## Лоиҳаҳо

| Лоиҳа | Технология | Порт |
|-------|-----------|------|
| `backend/` | Node.js + Express + MongoDB + Redis + Socket.io | 5000 |
| `admin-panel/` | React.js + Redux | 3000 |
| `client-app/` | React Native | — |
| `courier-app/` | React Native | — |

## Зудтарин оғоз

```bash
# 1. Клон кунед
git clone https://github.com/your-org/tojrason.git
cd tojrason

# 2. Муҳит созед
cp backend/.env.example backend/.env
cp admin-panel/.env.example admin-panel/.env
# Файлҳои .env-ро таҳрир кунед

# 3. Docker бо ҳама сервисҳо
docker-compose up -d

# 4. Admin panel
cd admin-panel && npm install && npm start
```

## Меъмории система

```
Муштарӣ (React Native)
        ↕ REST API + WebSocket
Курьер (React Native)
        ↕ REST API + WebSocket
Админ (React.js)
        ↕ REST API + WebSocket
           ┌──────────────┐
           │   Backend    │
           │  Express.js  │
           └──────┬───────┘
           ┌──────┴───────┐
     MongoDB             Redis
  (маълумот)        (кеш + навбат)
```

## Хусусиятҳои асосӣ

- ✅ JWT аутентификатсия (access + refresh tokens)
- ✅ Нақши корбар (admin / courier / client)
- ✅ Системаи диспетчерии автоматикӣ (наздиктарин курьер)
- ✅ Формулаи Haversine (ҳисоби масофа)
- ✅ Нархгузории динамикӣ (шаб, рӯзи истироҳат, вазн)
- ✅ Мавқеияти GPS дар вақти воқеӣ (Socket.io)
- ✅ Идоракунии навбат (Redis)
- ✅ Нишондиҳандаи пайгирии фармоиш
- ✅ Баҳогузории курьер
- ✅ Панели идоракунии пурра

Барои роҳнамои пурра: [SETUP_GUIDE.md](./SETUP_GUIDE.md)

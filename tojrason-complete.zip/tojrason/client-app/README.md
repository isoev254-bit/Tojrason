# Tojrason Client App

## Технология
- React Native 0.73
- Redux Toolkit
- React Navigation (Tab + Stack)
- Socket.io Client
- React Native Maps (Google Maps)

## Оғоз

```bash
cp .env.example .env
npm install

# Android
npm run android

# iOS (Mac OS лозим аст)
cd ios && pod install && cd ..
npm run ios
```

## Талабот
- Node.js >= 18
- Android Studio / Xcode
- React Native CLI

## Имконот
- 🔐 Ворид шудан ва ба қайд гирифтан
- 📦 Сохтани фармоиш бо нархи тахминӣ
- 🗺️ Пайгирии зиндаи курьер (Google Maps)
- 📋 Таърихи фармоишҳо
- ⭐ Баҳогузории курьер
- 👤 Идоракунии профил

import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  ScrollView, Alert, Switch,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { logoutUser } from '../../store/slices/authSlice';
import { COLORS } from '../../utils/theme';

export default function ProfileScreen({ navigation }) {
  const dispatch = useDispatch();
  const { user } = useSelector((s) => s.auth);
  const [notifications, setNotifications] = useState(true);

  const handleLogout = () => {
    Alert.alert('Хуруҷ', 'Оё мехоҳед аз ҳисоб хориҷ шавед?', [
      { text: 'Не', style: 'cancel' },
      { text: 'Ҳа', style: 'destructive', onPress: () => dispatch(logoutUser()) },
    ]);
  };

  const MenuItem = ({ icon, label, onPress, right, danger }) => (
    <TouchableOpacity style={styles.menuItem} onPress={onPress} activeOpacity={0.7}>
      <Text style={styles.menuIcon}>{icon}</Text>
      <Text style={[styles.menuLabel, danger && { color: COLORS.danger }]}>{label}</Text>
      {right || <Text style={styles.menuArrow}>›</Text>}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.profileHeader}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{user?.name?.[0]?.toUpperCase()}</Text>
          </View>
          <Text style={styles.userName}>{user?.name}</Text>
          <Text style={styles.userPhone}>{user?.phone}</Text>
          <View style={styles.roleBadge}>
            <Text style={styles.roleText}>Муштарӣ</Text>
          </View>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          {[
            { label: 'Фармоишҳо', value: user?.totalOrders || 0, icon: '📦' },
            { label: 'Дар интизор', value: '-', icon: '⏳' },
            { label: 'Расонида', value: '-', icon: '✅' },
          ].map((item) => (
            <View key={item.label} style={styles.statItem}>
              <Text style={styles.statIcon}>{item.icon}</Text>
              <Text style={styles.statValue}>{item.value}</Text>
              <Text style={styles.statLabel}>{item.label}</Text>
            </View>
          ))}
        </View>

        {/* Menu */}
        <View style={styles.menuSection}>
          <Text style={styles.sectionTitle}>Ҳисоб</Text>
          <View style={styles.menuCard}>
            <MenuItem icon="👤" label="Таҳрири профил" onPress={() => Alert.alert('Ба зудӣ')} />
            <View style={styles.divider} />
            <MenuItem icon="📍" label="Суроғаҳои ман" onPress={() => Alert.alert('Ба зудӣ')} />
            <View style={styles.divider} />
            <MenuItem icon="🔒" label="Иваз кардани рамз" onPress={() => Alert.alert('Ба зудӣ')} />
          </View>
        </View>

        <View style={styles.menuSection}>
          <Text style={styles.sectionTitle}>Танзимот</Text>
          <View style={styles.menuCard}>
            <MenuItem
              icon="🔔"
              label="Огоҳиҳо"
              onPress={() => {}}
              right={<Switch value={notifications} onValueChange={setNotifications} trackColor={{ true: COLORS.primary }} />}
            />
            <View style={styles.divider} />
            <MenuItem icon="🌐" label="Забон: Тоҷикӣ" onPress={() => {}} />
          </View>
        </View>

        <View style={styles.menuSection}>
          <Text style={styles.sectionTitle}>Дигар</Text>
          <View style={styles.menuCard}>
            <MenuItem icon="❓" label="Ёрдам ва дастгирӣ" onPress={() => Alert.alert('Ёрдам', 'Рақами дастгирӣ: +992901234567')} />
            <View style={styles.divider} />
            <MenuItem icon="⭐" label="Баҳои барнома" onPress={() => Alert.alert('Ташаккур!')} />
            <View style={styles.divider} />
            <MenuItem icon="ℹ️" label="Дар бораи барнома" onPress={() => Alert.alert('Тоҷрасон', 'Версия 1.0.0')} />
          </View>
        </View>

        <View style={styles.menuSection}>
          <View style={styles.menuCard}>
            <MenuItem icon="🚪" label="Хуруҷ аз ҳисоб" onPress={handleLogout} danger />
          </View>
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  profileHeader: { backgroundColor: COLORS.white, alignItems: 'center', paddingVertical: 32, paddingHorizontal: 20, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  avatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 12, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 6 },
  avatarText: { fontSize: 34, fontWeight: '800', color: COLORS.white },
  userName: { fontSize: 22, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  userPhone: { fontSize: 14, color: COLORS.textSecondary, marginBottom: 10 },
  roleBadge: { backgroundColor: COLORS.primaryLight, paddingHorizontal: 16, paddingVertical: 5, borderRadius: 20 },
  roleText: { fontSize: 13, color: COLORS.primary, fontWeight: '700' },
  statsRow: { flexDirection: 'row', backgroundColor: COLORS.white, marginTop: 1, padding: 16, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  statItem: { flex: 1, alignItems: 'center', gap: 2 },
  statIcon: { fontSize: 22 },
  statValue: { fontSize: 20, fontWeight: '800', color: COLORS.text },
  statLabel: { fontSize: 11, color: COLORS.textSecondary, textAlign: 'center' },
  menuSection: { marginHorizontal: 16, marginTop: 20 },
  sectionTitle: { fontSize: 12, fontWeight: '700', color: COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8, paddingHorizontal: 4 },
  menuCard: { backgroundColor: COLORS.white, borderRadius: 14, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 15, gap: 12 },
  menuIcon: { fontSize: 20, width: 28, textAlign: 'center' },
  menuLabel: { flex: 1, fontSize: 15, color: COLORS.text, fontWeight: '500' },
  menuArrow: { fontSize: 20, color: COLORS.textSecondary },
  divider: { height: 1, backgroundColor: COLORS.border, marginLeft: 56 },
});

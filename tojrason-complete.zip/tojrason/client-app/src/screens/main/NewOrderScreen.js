import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, ScrollView, Alert, ActivityIndicator, Switch,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { createOrder, estimateFare, clearEstimate } from '../../store/slices/ordersSlice';
import { COLORS } from '../../utils/theme';

const CATEGORIES = [
  { key: 'document', label: '📄 Ҳуҷҷат' },
  { key: 'package', label: '📦 Баста' },
  { key: 'food', label: '🍱 Хӯрок' },
  { key: 'electronics', label: '📱 Электроника' },
  { key: 'clothing', label: '👔 Либос' },
  { key: 'other', label: '📌 Дигар' },
];

const PAYMENT_METHODS = [
  { key: 'cash', label: '💵 Нақд' },
  { key: 'card', label: '💳 Корт' },
  { key: 'wallet', label: '👝 Ҳамён' },
];

export default function NewOrderScreen({ navigation, route }) {
  const dispatch = useDispatch();
  const { creating, estimate } = useSelector((s) => s.orders);

  const [step, setStep] = useState(1);
  const [pickup, setPickup] = useState({ address: '', coordinates: { lat: 38.5598, lng: 68.7737 }, contactName: '', contactPhone: '', notes: '' });
  const [delivery, setDelivery] = useState({ address: '', coordinates: { lat: 38.5760, lng: 68.7864 }, contactName: '', contactPhone: '', notes: '' });
  const [pkg, setPkg] = useState({ description: '', weight: '1', fragile: false, category: 'other' });
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [estimating, setEstimating] = useState(false);

  useEffect(() => {
    return () => dispatch(clearEstimate());
  }, []);

  const handleEstimate = async () => {
    if (!pickup.address || !delivery.address) {
      Alert.alert('Хато', 'Лутфан ҳарду суроғаро ворид кунед');
      return;
    }
    setEstimating(true);
    await dispatch(estimateFare({
      pickupLat: pickup.coordinates.lat,
      pickupLng: pickup.coordinates.lng,
      deliveryLat: delivery.coordinates.lat,
      deliveryLng: delivery.coordinates.lng,
    }));
    setEstimating(false);
    setStep(2);
  };

  const handleSubmit = async () => {
    if (!pkg.description.trim()) {
      Alert.alert('Хато', 'Тавсифи баста талаб карда мешавад');
      return;
    }
    const result = await dispatch(createOrder({
      pickup: { address: pickup.address, coordinates: pickup.coordinates, contactName: pickup.contactName, contactPhone: pickup.contactPhone, notes: pickup.notes },
      delivery: { address: delivery.address, coordinates: delivery.coordinates, contactName: delivery.contactName, contactPhone: delivery.contactPhone, notes: delivery.notes },
      packageDetails: { description: pkg.description, weight: parseFloat(pkg.weight) || 1, fragile: pkg.fragile, category: pkg.category },
      paymentMethod,
    }));
    if (!result.error) {
      navigation.replace('OrderTracking', { orderId: result.payload._id });
    } else {
      Alert.alert('Хато', result.payload || 'Фармоиш сохта нашуд');
    }
  };

  const inputProps = (val, setter, placeholder, opts = {}) => ({
    style: styles.input,
    placeholder, placeholderTextColor: COLORS.textSecondary,
    value: val, onChangeText: setter, ...opts,
  });

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => step === 1 ? navigation.goBack() : setStep(1)}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.topTitle}>Фармоиши нав</Text>
        <View style={styles.steps}>
          <View style={[styles.stepDot, step >= 1 && styles.stepActive]} />
          <View style={[styles.stepLine]} />
          <View style={[styles.stepDot, step >= 2 && styles.stepActive]} />
        </View>
      </View>

      <ScrollView style={styles.body} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        {step === 1 ? (
          <>
            {/* Pickup */}
            <View style={styles.section}>
              <Text style={styles.sectionHeader}>📦 Суроғаи гирифтан</Text>
              <TextInput {...inputProps(pickup.address, (v) => setPickup({ ...pickup, address: v }), 'Суроғаи пурра...')} />
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <TextInput {...inputProps(pickup.contactName, (v) => setPickup({ ...pickup, contactName: v }), 'Ном (ихтиёрӣ)')} />
                </View>
                <View style={{ flex: 1 }}>
                  <TextInput {...inputProps(pickup.contactPhone, (v) => setPickup({ ...pickup, contactPhone: v }), 'Телефон', { keyboardType: 'phone-pad' })} />
                </View>
              </View>
              <TextInput {...inputProps(pickup.notes, (v) => setPickup({ ...pickup, notes: v }), 'Изоҳ (ихтиёрӣ)')} />
            </View>

            {/* Delivery */}
            <View style={styles.section}>
              <Text style={styles.sectionHeader}>🏠 Суроғаи расондан</Text>
              <TextInput {...inputProps(delivery.address, (v) => setDelivery({ ...delivery, address: v }), 'Суроғаи пурра...')} />
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <TextInput {...inputProps(delivery.contactName, (v) => setDelivery({ ...delivery, contactName: v }), 'Ном (ихтиёрӣ)')} />
                </View>
                <View style={{ flex: 1 }}>
                  <TextInput {...inputProps(delivery.contactPhone, (v) => setDelivery({ ...delivery, contactPhone: v }), 'Телефон', { keyboardType: 'phone-pad' })} />
                </View>
              </View>
              <TextInput {...inputProps(delivery.notes, (v) => setDelivery({ ...delivery, notes: v }), 'Изоҳ (ихтиёрӣ)')} />
            </View>

            <TouchableOpacity style={styles.primaryBtn} onPress={handleEstimate} disabled={estimating} activeOpacity={0.85}>
              {estimating ? <ActivityIndicator color={COLORS.white} /> : <Text style={styles.primaryBtnText}>Нарх ҳисоб кардан →</Text>}
            </TouchableOpacity>
          </>
        ) : (
          <>
            {/* Estimate */}
            {estimate && (
              <View style={styles.estimateCard}>
                <Text style={styles.estimateTitle}>💰 Нархи тахминӣ</Text>
                <Text style={styles.estimatePrice}>{estimate.pricing?.total?.toFixed(2)} сомонӣ</Text>
                <Text style={styles.estimateMeta}>📏 {estimate.distanceKm?.toFixed(1)} км · ⏱ {estimate.estimatedDuration} дақиқа</Text>
              </View>
            )}

            {/* Package details */}
            <View style={styles.section}>
              <Text style={styles.sectionHeader}>📦 Тафсилоти баста</Text>
              <TextInput {...inputProps(pkg.description, (v) => setPkg({ ...pkg, description: v }), 'Тавсиф (масалан: китоб, либос...)')} />
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Вазн (кг)</Text>
                  <TextInput {...inputProps(pkg.weight, (v) => setPkg({ ...pkg, weight: v }), '1', { keyboardType: 'numeric' })} />
                </View>
                <View style={[styles.row, { flex: 1, alignItems: 'center', paddingTop: 20 }]}>
                  <Text style={styles.label}>Шикастанӣ</Text>
                  <Switch value={pkg.fragile} onValueChange={(v) => setPkg({ ...pkg, fragile: v })} trackColor={{ true: COLORS.primary }} />
                </View>
              </View>

              <Text style={styles.label}>Категория</Text>
              <View style={styles.categoryGrid}>
                {CATEGORIES.map((cat) => (
                  <TouchableOpacity
                    key={cat.key}
                    style={[styles.catBtn, pkg.category === cat.key && styles.catBtnActive]}
                    onPress={() => setPkg({ ...pkg, category: cat.key })}
                  >
                    <Text style={[styles.catLabel, pkg.category === cat.key && styles.catLabelActive]}>{cat.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Payment */}
            <View style={styles.section}>
              <Text style={styles.sectionHeader}>💳 Усули пардохт</Text>
              <View style={styles.paymentRow}>
                {PAYMENT_METHODS.map((pm) => (
                  <TouchableOpacity
                    key={pm.key}
                    style={[styles.payBtn, paymentMethod === pm.key && styles.payBtnActive]}
                    onPress={() => setPaymentMethod(pm.key)}
                  >
                    <Text style={[styles.payLabel, paymentMethod === pm.key && styles.payLabelActive]}>{pm.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <TouchableOpacity style={styles.primaryBtn} onPress={handleSubmit} disabled={creating} activeOpacity={0.85}>
              {creating ? <ActivityIndicator color={COLORS.white} /> : <Text style={styles.primaryBtnText}>✅ Фармоиш додан</Text>}
            </TouchableOpacity>
          </>
        )}
        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  backText: { fontSize: 22, color: COLORS.primary, fontWeight: '600', paddingHorizontal: 4 },
  topTitle: { fontSize: 17, fontWeight: '700', color: COLORS.text },
  steps: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  stepDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: COLORS.border },
  stepActive: { backgroundColor: COLORS.primary },
  stepLine: { width: 20, height: 2, backgroundColor: COLORS.border },
  body: { flex: 1 },
  section: { backgroundColor: COLORS.white, marginHorizontal: 16, marginTop: 16, borderRadius: 14, padding: 16, gap: 10, borderWidth: 1, borderColor: COLORS.border },
  sectionHeader: { fontSize: 15, fontWeight: '700', color: COLORS.text, marginBottom: 4 },
  label: { fontSize: 12, fontWeight: '600', color: COLORS.textSecondary, marginBottom: 4 },
  input: { borderWidth: 1, borderColor: COLORS.border, borderRadius: 10, padding: 12, fontSize: 14, color: COLORS.text, backgroundColor: COLORS.bg },
  row: { flexDirection: 'row', gap: 10 },
  estimateCard: { margin: 16, backgroundColor: COLORS.primary, borderRadius: 16, padding: 20, alignItems: 'center' },
  estimateTitle: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginBottom: 6 },
  estimatePrice: { fontSize: 32, fontWeight: '900', color: COLORS.white },
  estimateMeta: { fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 4 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  catBtn: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.bg },
  catBtnActive: { backgroundColor: COLORS.primaryLight, borderColor: COLORS.primary },
  catLabel: { fontSize: 12, color: COLORS.text },
  catLabelActive: { color: COLORS.primary, fontWeight: '700' },
  paymentRow: { flexDirection: 'row', gap: 10 },
  payBtn: { flex: 1, padding: 12, borderRadius: 10, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', backgroundColor: COLORS.bg },
  payBtnActive: { backgroundColor: COLORS.primaryLight, borderColor: COLORS.primary },
  payLabel: { fontSize: 13, color: COLORS.text, fontWeight: '500' },
  payLabelActive: { color: COLORS.primary, fontWeight: '700' },
  primaryBtn: { margin: 16, backgroundColor: COLORS.primary, borderRadius: 14, padding: 16, alignItems: 'center', shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 },
  primaryBtnText: { color: COLORS.white, fontSize: 16, fontWeight: '800' },
});

import React, { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  ScrollView, Alert, ActivityIndicator, Platform,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchOrderById, rateOrder } from '../../store/slices/ordersSlice';
import { COLORS, STATUS_LABELS, STATUS_COLORS } from '../../utils/theme';

export default function OrderDetailScreen({ navigation, route }) {
  const dispatch = useDispatch();
  const { orderId } = route.params;
  const { currentOrder, loading } = useSelector((s) => s.orders);
  const [ratingScore, setRatingScore] = useState(0);
  const [ratingComment, setRatingComment] = useState('');
  const [submittingRating, setSubmittingRating] = useState(false);

  useEffect(() => {
    dispatch(fetchOrderById(orderId));
  }, [orderId]);

  const handleRate = async () => {
    if (ratingScore === 0) { Alert.alert('Хато', 'Лутфан ситора интихоб кунед'); return; }
    setSubmittingRating(true);
    const res = await dispatch(rateOrder({ id: orderId, score: ratingScore, comment: ratingComment }));
    setSubmittingRating(false);
    if (!res.error) {
      Alert.alert('Ташаккур!', 'Баҳогузории шумо қабул карда шуд');
      dispatch(fetchOrderById(orderId));
    } else Alert.alert('Хато', res.payload || 'Баҳо дода нашуд');
  };

  if (!currentOrder) return <View style={styles.loading}><ActivityIndicator size="large" color={COLORS.primary} /></View>;

  const statusColor = STATUS_COLORS[currentOrder.status] || COLORS.primary;
  const canRate = currentOrder.status === 'delivered' && !currentOrder.rating?.score;

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.topTitle}>Тафсилоти фармоиш</Text>
        <View />
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Status */}
        <View style={[styles.statusCard, { borderLeftColor: statusColor }]}>
          <Text style={styles.orderNum}>{currentOrder.orderNumber}</Text>
          <View style={[styles.badge, { backgroundColor: statusColor + '20' }]}>
            <Text style={[styles.badgeText, { color: statusColor }]}>{STATUS_LABELS[currentOrder.status]}</Text>
          </View>
        </View>

        {/* Addresses */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>📍 Суроғаҳо</Text>
          <View style={styles.addrBlock}>
            <View style={styles.addrIcon}>
              <View style={[styles.addrDot, { backgroundColor: COLORS.primary }]} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.addrLabel}>Гирифтан</Text>
              <Text style={styles.addrText}>{currentOrder.pickup?.address}</Text>
            </View>
          </View>
          <View style={styles.addrLine} />
          <View style={styles.addrBlock}>
            <View style={styles.addrIcon}>
              <View style={[styles.addrDot, { backgroundColor: COLORS.success }]} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.addrLabel}>Расондан</Text>
              <Text style={styles.addrText}>{currentOrder.delivery?.address}</Text>
            </View>
          </View>
        </View>

        {/* Package */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>📦 Баста</Text>
          <Row label="Тавсиф" value={currentOrder.packageDetails?.description} />
          <Row label="Вазн" value={`${currentOrder.packageDetails?.weight} кг`} />
          <Row label="Шикастанӣ" value={currentOrder.packageDetails?.fragile ? '⚠️ Ҳа' : 'Не'} />
          <Row label="Масофа" value={`${currentOrder.distance?.toFixed(1)} км`} />
          <Row label="Вақти тахминӣ" value={`${currentOrder.estimatedDuration} дақиқа`} />
        </View>

        {/* Pricing */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>💰 Нарх</Text>
          <Row label="Нархи асосӣ" value={`${currentOrder.pricing?.baseFare?.toFixed(2)} с.`} />
          <Row label="Нархи масофа" value={`${currentOrder.pricing?.distanceFare?.toFixed(2)} с.`} />
          {currentOrder.pricing?.surcharge > 0 && <Row label="Иловапардохт" value={`${currentOrder.pricing?.surcharge?.toFixed(2)} с.`} />}
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Ҳамагӣ</Text>
            <Text style={styles.totalValue}>{currentOrder.pricing?.total?.toFixed(2)} сомонӣ</Text>
          </View>
        </View>

        {/* Courier */}
        {currentOrder.courier && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>🛵 Курьер</Text>
            <Row label="Ном" value={currentOrder.courier.name} />
            <Row label="Телефон" value={currentOrder.courier.phone} />
          </View>
        )}

        {/* Tracking history */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>📋 Таърихи ҳолат</Text>
          {[...currentOrder.trackingHistory].reverse().map((ev, idx) => (
            <View key={idx} style={styles.trackItem}>
              <View style={styles.trackDot} />
              <View style={{ flex: 1 }}>
                <Text style={styles.trackStatus}>{STATUS_LABELS[ev.status] || ev.status}</Text>
                <Text style={styles.trackTime}>{new Date(ev.timestamp).toLocaleString('ru')}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Rating */}
        {canRate && (
          <View style={styles.ratingCard}>
            <Text style={styles.ratingTitle}>⭐ Курьерро баҳо диҳед</Text>
            <View style={styles.starsRow}>
              {[1, 2, 3, 4, 5].map((s) => (
                <TouchableOpacity key={s} onPress={() => setRatingScore(s)}>
                  <Text style={[styles.star, ratingScore >= s && styles.starActive]}>★</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity style={styles.rateBtn} onPress={handleRate} disabled={submittingRating}>
              {submittingRating ? <ActivityIndicator color={COLORS.white} /> : <Text style={styles.rateBtnText}>Баҳо фиристодан</Text>}
            </TouchableOpacity>
          </View>
        )}

        {currentOrder.rating?.score && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>⭐ Баҳогузории шумо</Text>
            <Text style={styles.ratingStars}>{'⭐'.repeat(currentOrder.rating.score)}</Text>
            {currentOrder.rating.comment && <Text style={styles.ratingComment}>{currentOrder.rating.comment}</Text>}
          </View>
        )}

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function Row({ label, value }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: '#f3f4f6' }}>
      <Text style={{ fontSize: 13, color: COLORS.textSecondary }}>{label}</Text>
      <Text style={{ fontSize: 13, fontWeight: '600', color: COLORS.text, maxWidth: '60%', textAlign: 'right' }}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  backText: { fontSize: 22, color: COLORS.primary, fontWeight: '600' },
  topTitle: { fontSize: 17, fontWeight: '700', color: COLORS.text },
  scroll: { flex: 1 },
  statusCard: { margin: 16, marginBottom: 0, backgroundColor: COLORS.white, borderRadius: 14, padding: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderLeftWidth: 4, borderWidth: 1, borderColor: COLORS.border },
  orderNum: { fontSize: 12, fontWeight: '700', color: COLORS.textSecondary, fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
  badge: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20 },
  badgeText: { fontSize: 12, fontWeight: '700' },
  card: { margin: 16, marginBottom: 0, backgroundColor: COLORS.white, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: COLORS.border },
  cardTitle: { fontSize: 15, fontWeight: '700', color: COLORS.text, marginBottom: 10 },
  addrBlock: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  addrIcon: { width: 20, alignItems: 'center', paddingTop: 4 },
  addrDot: { width: 10, height: 10, borderRadius: 5 },
  addrLine: { width: 1, height: 14, backgroundColor: COLORS.border, marginLeft: 9, marginVertical: 4 },
  addrLabel: { fontSize: 11, color: COLORS.textSecondary, marginBottom: 2 },
  addrText: { fontSize: 14, fontWeight: '600', color: COLORS.text },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', paddingTop: 10, marginTop: 4, borderTopWidth: 2, borderTopColor: COLORS.border },
  totalLabel: { fontSize: 15, fontWeight: '700', color: COLORS.text },
  totalValue: { fontSize: 18, fontWeight: '800', color: COLORS.success },
  trackItem: { flexDirection: 'row', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  trackDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.primary, marginTop: 5 },
  trackStatus: { fontSize: 13, fontWeight: '600', color: COLORS.text },
  trackTime: { fontSize: 11, color: COLORS.textSecondary, marginTop: 2 },
  ratingCard: { margin: 16, marginBottom: 0, backgroundColor: '#fef9c3', borderRadius: 14, padding: 18, alignItems: 'center', gap: 12 },
  ratingTitle: { fontSize: 17, fontWeight: '700', color: '#92400e' },
  starsRow: { flexDirection: 'row', gap: 8 },
  star: { fontSize: 36, color: '#e5e7eb' },
  starActive: { color: '#f59e0b' },
  rateBtn: { backgroundColor: '#f59e0b', borderRadius: 12, paddingHorizontal: 32, paddingVertical: 12 },
  rateBtnText: { color: COLORS.white, fontWeight: '800', fontSize: 15 },
  ratingStars: { fontSize: 24, marginTop: 4 },
  ratingComment: { fontSize: 13, color: COLORS.textSecondary, fontStyle: 'italic', marginTop: 4 },
});

import React, { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  FlatList, ActivityIndicator, Platform,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchMyOrders } from '../../store/slices/ordersSlice';
import { COLORS, STATUS_LABELS, STATUS_COLORS } from '../../utils/theme';

const FILTERS = [
  { key: '', label: 'Ҳама' },
  { key: 'in_transit', label: 'Фаъол' },
  { key: 'delivered', label: 'Расонида' },
  { key: 'cancelled', label: 'Бекор' },
];

export default function OrdersHistoryScreen({ navigation }) {
  const dispatch = useDispatch();
  const { list, total, loading } = useSelector((s) => s.orders);
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    dispatch(fetchMyOrders({ page: 1, limit: 20, status: status || undefined }));
    setPage(1);
  }, [status]);

  const loadMore = () => {
    if (list.length < total && !loading) {
      const nextPage = page + 1;
      setPage(nextPage);
      dispatch(fetchMyOrders({ page: nextPage, limit: 20, status: status || undefined }));
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await dispatch(fetchMyOrders({ page: 1, limit: 20, status: status || undefined }));
    setPage(1);
    setRefreshing(false);
  };

  const renderItem = ({ item }) => {
    const statusColor = STATUS_COLORS[item.status] || COLORS.textSecondary;
    const isActive = !['delivered', 'cancelled', 'failed'].includes(item.status);
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => isActive
          ? navigation.navigate('OrderTracking', { orderId: item._id })
          : navigation.navigate('OrderDetail', { orderId: item._id })
        }
        activeOpacity={0.85}
      >
        <View style={styles.cardTop}>
          <Text style={styles.orderNum}>{item.orderNumber}</Text>
          <View style={[styles.badge, { backgroundColor: statusColor + '20' }]}>
            <Text style={[styles.badgeText, { color: statusColor }]}>{STATUS_LABELS[item.status]}</Text>
          </View>
        </View>
        <View style={styles.addrRow}>
          <Text style={styles.addrDot}>📦</Text>
          <Text style={styles.addrText} numberOfLines={1}>{item.pickup?.address}</Text>
        </View>
        <View style={styles.addrRow}>
          <Text style={styles.addrDot}>🏠</Text>
          <Text style={styles.addrText} numberOfLines={1}>{item.delivery?.address}</Text>
        </View>
        <View style={styles.cardBottom}>
          <Text style={styles.price}>{item.pricing?.total?.toFixed(2)} сомонӣ</Text>
          <Text style={styles.date}>{new Date(item.createdAt).toLocaleDateString('ru')}</Text>
        </View>
        {item.rating?.score && (
          <View style={styles.ratingRow}>
            <Text style={styles.ratingText}>{'⭐'.repeat(item.rating.score)}</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.title}>Фармоишҳои ман</Text>
      </View>

      <View style={styles.filterRow}>
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.filterBtn, status === f.key && styles.filterBtnActive]}
            onPress={() => setStatus(f.key)}
          >
            <Text style={[styles.filterText, status === f.key && styles.filterTextActive]}>{f.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={list}
        keyExtractor={(item) => item._id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        onEndReached={loadMore}
        onEndReachedThreshold={0.3}
        refreshing={refreshing}
        onRefresh={onRefresh}
        ListEmptyComponent={
          loading
            ? <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 60 }} />
            : (
              <View style={styles.empty}>
                <Text style={styles.emptyIcon}>📭</Text>
                <Text style={styles.emptyTitle}>Фармоишҳо нестанд</Text>
                <Text style={styles.emptySubtitle}>Аввалин фармоиши худро диҳед!</Text>
              </View>
            )
        }
        ListFooterComponent={loading && list.length > 0 ? <ActivityIndicator color={COLORS.primary} style={{ padding: 16 }} /> : null}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  header: { padding: 20, paddingBottom: 12, backgroundColor: COLORS.white },
  title: { fontSize: 22, fontWeight: '800', color: COLORS.text },
  filterRow: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 10, backgroundColor: COLORS.white, gap: 8, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  filterBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: COLORS.bg, borderWidth: 1, borderColor: COLORS.border },
  filterBtnActive: { backgroundColor: COLORS.primaryLight, borderColor: COLORS.primary },
  filterText: { fontSize: 13, color: COLORS.textSecondary, fontWeight: '500' },
  filterTextActive: { color: COLORS.primary, fontWeight: '700' },
  list: { padding: 16, gap: 12, flexGrow: 1 },
  card: { backgroundColor: COLORS.white, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: COLORS.border, gap: 8 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderNum: { fontSize: 12, fontWeight: '700', color: COLORS.textSecondary, fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
  badge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 20 },
  badgeText: { fontSize: 11, fontWeight: '700' },
  addrRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  addrDot: { fontSize: 13 },
  addrText: { flex: 1, fontSize: 13, color: COLORS.textSecondary },
  cardBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 2 },
  price: { fontSize: 16, fontWeight: '800', color: COLORS.text },
  date: { fontSize: 12, color: COLORS.textSecondary },
  ratingRow: { borderTopWidth: 1, borderTopColor: COLORS.border, paddingTop: 6 },
  ratingText: { fontSize: 14 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80 },
  emptyIcon: { fontSize: 56, marginBottom: 12 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: COLORS.text, marginBottom: 6 },
  emptySubtitle: { fontSize: 14, color: COLORS.textSecondary },
});

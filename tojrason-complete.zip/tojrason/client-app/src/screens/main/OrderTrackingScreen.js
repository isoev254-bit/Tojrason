import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  Alert, ActivityIndicator, Linking, Platform,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { fetchOrderById, cancelOrder } from '../../store/slices/ordersSlice';
import { connectSocket, joinOrderRoom, leaveOrderRoom, onEvent, offEvent } from '../../services/socket';
import { setCourierLocation } from '../../store/slices/trackingSlice';
import { COLORS, STATUS_LABELS, STATUS_COLORS } from '../../utils/theme';

export default function OrderTrackingScreen({ navigation, route }) {
  const dispatch = useDispatch();
  const { orderId } = route.params;
  const { currentOrder } = useSelector((s) => s.orders);
  const { courierLocation } = useSelector((s) => s.tracking);
  const mapRef = useRef(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    dispatch(fetchOrderById(orderId)).finally(() => setLoading(false));
    setupSocket();
    const interval = setInterval(() => dispatch(fetchOrderById(orderId)), 15000);
    return () => {
      clearInterval(interval);
      leaveOrderRoom(orderId);
    };
  }, [orderId]);

  const setupSocket = async () => {
    const socket = await connectSocket();
    if (!socket) return;
    joinOrderRoom(orderId);

    const handleStatus = (data) => {
      if (data.orderId === orderId || data.orderId === orderId?.toString()) {
        dispatch(fetchOrderById(orderId));
        if (data.status === 'delivered') {
          Alert.alert('🎉 Ташаккур!', 'Бастаи шумо расонида шуд. Лутфан баҳо диҳед.', [
            { text: 'Баҳо додан', onPress: () => navigation.replace('OrderDetail', { orderId }) },
            { text: 'Хуб', style: 'cancel' },
          ]);
        }
      }
    };
    const handleLocation = (data) => {
      dispatch(setCourierLocation({ lat: data.lat, lng: data.lng }));
      if (mapRef.current) {
        mapRef.current.animateToRegion({ latitude: data.lat, longitude: data.lng, latitudeDelta: 0.02, longitudeDelta: 0.02 }, 500);
      }
    };

    onEvent('order:status_changed', handleStatus);
    onEvent('courier:location', handleLocation);
    return () => {
      offEvent('order:status_changed', handleStatus);
      offEvent('courier:location', handleLocation);
    };
  };

  const handleCancel = () => {
    Alert.alert('Бекор кардан', 'Оё мехоҳед фармоишро бекор кунед?', [
      { text: 'Не', style: 'cancel' },
      {
        text: 'Ҳа, бекор кунед', style: 'destructive',
        onPress: async () => {
          const res = await dispatch(cancelOrder({ id: orderId, reason: 'Муштарӣ бекор кард' }));
          if (!res.error) navigation.goBack();
          else Alert.alert('Хато', 'Бекор кардан мумкин нашуд');
        },
      },
    ]);
  };

  const callCourier = () => {
    const phone = currentOrder?.courier?.phone;
    if (phone) Linking.openURL(`tel:${phone}`);
  };

  if (loading || !currentOrder) {
    return <View style={styles.loadingContainer}><ActivityIndicator size="large" color={COLORS.primary} /></View>;
  }

  const pickupCoord = currentOrder.pickup?.coordinates;
  const deliveryCoord = currentOrder.delivery?.coordinates;
  const initialRegion = pickupCoord ? {
    latitude: pickupCoord.lat,
    longitude: pickupCoord.lng,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  } : { latitude: 38.5598, longitude: 68.7737, latitudeDelta: 0.05, longitudeDelta: 0.05 };

  const statusColor = STATUS_COLORS[currentOrder.status] || COLORS.primary;
  const isActive = !['delivered', 'cancelled', 'failed'].includes(currentOrder.status);
  const canCancel = ['pending', 'searching_courier', 'courier_assigned'].includes(currentOrder.status);

  return (
    <SafeAreaView style={styles.safe}>
      {/* Top bar */}
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.topTitle}>Пайгирии фармоиш</Text>
        <Text style={styles.orderNum}>{currentOrder.orderNumber}</Text>
      </View>

      {/* Map */}
      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={initialRegion}
        showsUserLocation
      >
        {pickupCoord && (
          <Marker coordinate={{ latitude: pickupCoord.lat, longitude: pickupCoord.lng }} title="Гирифтан">
            <View style={[styles.mapMarker, { backgroundColor: COLORS.primary }]}>
              <Text style={styles.markerText}>📦</Text>
            </View>
          </Marker>
        )}
        {deliveryCoord && (
          <Marker coordinate={{ latitude: deliveryCoord.lat, longitude: deliveryCoord.lng }} title="Расондан">
            <View style={[styles.mapMarker, { backgroundColor: COLORS.success }]}>
              <Text style={styles.markerText}>🏠</Text>
            </View>
          </Marker>
        )}
        {courierLocation && (
          <Marker coordinate={{ latitude: courierLocation.lat, longitude: courierLocation.lng }} title="Курьер">
            <View style={[styles.mapMarker, { backgroundColor: COLORS.warning }]}>
              <Text style={styles.markerText}>🛵</Text>
            </View>
          </Marker>
        )}
        {pickupCoord && deliveryCoord && (
          <Polyline
            coordinates={[
              { latitude: pickupCoord.lat, longitude: pickupCoord.lng },
              { latitude: deliveryCoord.lat, longitude: deliveryCoord.lng },
            ]}
            strokeColor={COLORS.primary}
            strokeWidth={2}
            lineDashPattern={[8, 4]}
          />
        )}
      </MapView>

      {/* Bottom sheet */}
      <View style={styles.bottomSheet}>
        <View style={[styles.statusBar, { backgroundColor: statusColor + '20', borderLeftColor: statusColor }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>
            {STATUS_LABELS[currentOrder.status]}
          </Text>
        </View>

        {/* Courier info */}
        {currentOrder.courier && (
          <View style={styles.courierRow}>
            <View style={styles.courierAvatar}>
              <Text style={styles.courierAvatarText}>{currentOrder.courier.name?.[0]?.toUpperCase()}</Text>
            </View>
            <View style={styles.courierInfo}>
              <Text style={styles.courierName}>{currentOrder.courier.name}</Text>
              <Text style={styles.courierLabel}>Курьери шумо</Text>
            </View>
            <TouchableOpacity style={styles.callBtn} onPress={callCourier}>
              <Text style={styles.callBtnText}>📞 Занг</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Route summary */}
        <View style={styles.routeRow}>
          <View style={styles.routeItem}>
            <Text style={styles.routeLabel}>📏 Масофа</Text>
            <Text style={styles.routeValue}>{currentOrder.distance?.toFixed(1)} км</Text>
          </View>
          <View style={styles.routeItem}>
            <Text style={styles.routeLabel}>⏱ Вақт</Text>
            <Text style={styles.routeValue}>{currentOrder.estimatedDuration} дақ.</Text>
          </View>
          <View style={styles.routeItem}>
            <Text style={styles.routeLabel}>💰 Нарх</Text>
            <Text style={styles.routeValue}>{currentOrder.pricing?.total?.toFixed(2)} с.</Text>
          </View>
        </View>

        {/* Action buttons */}
        <View style={styles.actionRow}>
          {canCancel && (
            <TouchableOpacity style={styles.cancelBtn} onPress={handleCancel} activeOpacity={0.85}>
              <Text style={styles.cancelBtnText}>✕ Бекор кардан</Text>
            </TouchableOpacity>
          )}
          {currentOrder.status === 'delivered' && !currentOrder.rating?.score && (
            <TouchableOpacity
              style={styles.rateBtn}
              onPress={() => navigation.replace('OrderDetail', { orderId })}
              activeOpacity={0.85}
            >
              <Text style={styles.rateBtnText}>⭐ Баҳо диҳед</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.white },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  backText: { fontSize: 22, color: COLORS.primary, fontWeight: '600' },
  topTitle: { fontSize: 16, fontWeight: '700', color: COLORS.text },
  orderNum: { fontSize: 11, color: COLORS.textSecondary, fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
  map: { flex: 1 },
  mapMarker: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 4, elevation: 4 },
  markerText: { fontSize: 18 },
  bottomSheet: { backgroundColor: COLORS.white, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 16, paddingBottom: 24, shadowColor: '#000', shadowOffset: { width: 0, height: -4 }, shadowOpacity: 0.08, shadowRadius: 12, elevation: 8, gap: 12 },
  statusBar: { borderLeftWidth: 4, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 8 },
  statusText: { fontSize: 15, fontWeight: '700' },
  courierRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  courierAvatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  courierAvatarText: { color: COLORS.white, fontWeight: '800', fontSize: 18 },
  courierInfo: { flex: 1 },
  courierName: { fontSize: 15, fontWeight: '700', color: COLORS.text },
  courierLabel: { fontSize: 12, color: COLORS.textSecondary },
  callBtn: { backgroundColor: COLORS.primaryLight, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  callBtnText: { color: COLORS.primary, fontWeight: '700', fontSize: 13 },
  routeRow: { flexDirection: 'row', backgroundColor: COLORS.bg, borderRadius: 12, padding: 12 },
  routeItem: { flex: 1, alignItems: 'center' },
  routeLabel: { fontSize: 11, color: COLORS.textSecondary, marginBottom: 2 },
  routeValue: { fontSize: 14, fontWeight: '700', color: COLORS.text },
  actionRow: { flexDirection: 'row', gap: 10 },
  cancelBtn: { flex: 1, backgroundColor: '#fef2f2', borderRadius: 12, padding: 13, alignItems: 'center', borderWidth: 1, borderColor: '#fca5a5' },
  cancelBtnText: { color: COLORS.danger, fontWeight: '700', fontSize: 14 },
  rateBtn: { flex: 1, backgroundColor: '#fef3c7', borderRadius: 12, padding: 13, alignItems: 'center', borderWidth: 1, borderColor: '#fcd34d' },
  rateBtnText: { color: '#92400e', fontWeight: '700', fontSize: 14 },
});

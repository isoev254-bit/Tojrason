import React, { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  ScrollView, Alert, ActivityIndicator, Platform,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import Geolocation from '@react-native-community/geolocation';
import { fetchMyOrders } from '../../store/slices/ordersSlice';
import { connectSocket, onEvent, offEvent } from '../../services/socket';
import { COLORS, STATUS_LABELS, STATUS_COLORS } from '../../utils/theme';

export default function HomeScreen({ navigation }) {
  const dispatch = useDispatch();
  const { user } = useSelector((s) => s.auth);
  const { list } = useSelector((s) => s.orders);
  const [location, setLocation] = useState(null);
  const [locLoading, setLocLoading] = useState(true);

  useEffect(() => {
    dispatch(fetchMyOrders({ limit: 3 }));
    setupSocket();
    getLocation();
  }, []);

  const setupSocket = async () => {
    const socket = await connectSocket();
    if (!socket) return;
    const handleStatus = (data) => {
      if (data.status === 'delivered') {
        Alert.alert('✅ Расонида шуд', `Фармоиши шумо ${data.orderNumber || ''} расонида шуд!`);
      }
    };
    onEvent('order:status_changed', handleStatus);
    return () => offEvent('order:status_changed', handleStatus);
  };

  const getLocation = () => {
    Geolocation.getCurrentPosition(
      (pos) => { setLocation(pos.coords); setLocLoading(false); },
      () => { setLocLoading(false); },
      { enableHighAccuracy: false, timeout: 10000 }
    );
  };

  const activeOrders = list.filter((o) => !['delivered', 'cancelled', 'failed'].includes(o.status));

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Хуш омадед,</Text>
            <Text style={styles.userName}>{user?.name} 👋</Text>
          </View>
          <View style={styles.locationBadge}>
            <Text style={styles.locationText}>📍 Душанбе</Text>
          </View>
        </View>

        {/* New Order CTA */}
        <TouchableOpacity
          style={styles.ctaCard}
          onPress={() => navigation.navigate('NewOrder', location ? { pickupCoords: location } : {})}
          activeOpacity={0.9}
        >
          <View>
            <Text style={styles.ctaTitle}>Фармоиши нав диҳед</Text>
            <Text style={styles.ctaSubtitle}>Бастаи худро зуд ва бехатар расонед</Text>
          </View>
          <Text style={styles.ctaIcon}>📦</Text>
        </TouchableOpacity>

        {/* Quick actions */}
        <View style={styles.quickActions}>
          {[
            { icon: '🚀', label: 'Зуд', onPress: () => navigation.navigate('NewOrder', { express: true }) },
            { icon: '📅', label: 'Барнома', onPress: () => navigation.navigate('NewOrder', { scheduled: true }) },
            { icon: '📜', label: 'Таърих', onPress: () => navigation.navigate('Фармоишҳо') },
          ].map((item) => (
            <TouchableOpacity key={item.label} style={styles.quickBtn} onPress={item.onPress} activeOpacity={0.8}>
              <Text style={styles.quickIcon}>{item.icon}</Text>
              <Text style={styles.quickLabel}>{item.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Active orders */}
        {activeOrders.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Фармоишҳои фаъол</Text>
            {activeOrders.map((order) => (
              <TouchableOpacity
                key={order._id}
                style={styles.orderCard}
                onPress={() => navigation.navigate('OrderTracking', { orderId: order._id })}
                activeOpacity={0.85}
              >
                <View style={styles.orderCardTop}>
                  <Text style={styles.orderNum}>{order.orderNumber}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: STATUS_COLORS[order.status] + '20' }]}>
                    <Text style={[styles.statusText, { color: STATUS_COLORS[order.status] }]}>
                      {STATUS_LABELS[order.status]}
                    </Text>
                  </View>
                </View>
                <Text style={styles.orderAddr} numberOfLines={1}>📍 {order.delivery?.address}</Text>
                <View style={styles.orderCardBottom}>
                  <Text style={styles.orderPrice}>{order.pricing?.total?.toFixed(2)} сомонӣ</Text>
                  <Text style={styles.trackBtn}>Пайгирӣ →</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Info cards */}
        <View style={styles.infoGrid}>
          {[
            { icon: '⚡', title: 'Зуд', desc: 'Дар 30-60 дақиқа' },
            { icon: '🔒', title: 'Бехатар', desc: 'Суғурта барои бастаи шумо' },
            { icon: '📱', title: 'Пайгирӣ', desc: 'Дар вақти воқеӣ' },
          ].map((item) => (
            <View key={item.title} style={styles.infoCard}>
              <Text style={styles.infoIcon}>{item.icon}</Text>
              <Text style={styles.infoTitle}>{item.title}</Text>
              <Text style={styles.infoDesc}>{item.desc}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  container: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, paddingTop: 16, backgroundColor: COLORS.white },
  greeting: { fontSize: 14, color: COLORS.textSecondary },
  userName: { fontSize: 20, fontWeight: '800', color: COLORS.text },
  locationBadge: { backgroundColor: COLORS.primaryLight, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  locationText: { fontSize: 13, color: COLORS.primary, fontWeight: '600' },
  ctaCard: {
    margin: 16, borderRadius: 16,
    backgroundColor: COLORS.primary,
    padding: 20, flexDirection: 'row',
    justifyContent: 'space-between', alignItems: 'center',
    shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3, shadowRadius: 8, elevation: 6,
  },
  ctaTitle: { fontSize: 18, fontWeight: '800', color: COLORS.white, marginBottom: 4 },
  ctaSubtitle: { fontSize: 13, color: 'rgba(255,255,255,0.8)' },
  ctaIcon: { fontSize: 40 },
  quickActions: { flexDirection: 'row', marginHorizontal: 16, gap: 10, marginBottom: 20 },
  quickBtn: { flex: 1, backgroundColor: COLORS.white, borderRadius: 12, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  quickIcon: { fontSize: 22, marginBottom: 4 },
  quickLabel: { fontSize: 12, fontWeight: '600', color: COLORS.text },
  section: { paddingHorizontal: 16, marginBottom: 20 },
  sectionTitle: { fontSize: 17, fontWeight: '700', color: COLORS.text, marginBottom: 12 },
  orderCard: { backgroundColor: COLORS.white, borderRadius: 12, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: COLORS.border },
  orderCardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  orderNum: { fontSize: 12, fontWeight: '700', color: COLORS.textSecondary, fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 20 },
  statusText: { fontSize: 11, fontWeight: '700' },
  orderAddr: { fontSize: 13, color: COLORS.textSecondary, marginBottom: 8 },
  orderCardBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderPrice: { fontSize: 15, fontWeight: '700', color: COLORS.text },
  trackBtn: { fontSize: 13, color: COLORS.primary, fontWeight: '600' },
  infoGrid: { flexDirection: 'row', marginHorizontal: 16, gap: 10, marginBottom: 24 },
  infoCard: { flex: 1, backgroundColor: COLORS.white, borderRadius: 12, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  infoIcon: { fontSize: 24, marginBottom: 6 },
  infoTitle: { fontSize: 13, fontWeight: '700', color: COLORS.text, marginBottom: 2 },
  infoDesc: { fontSize: 11, color: COLORS.textSecondary, textAlign: 'center' },
});

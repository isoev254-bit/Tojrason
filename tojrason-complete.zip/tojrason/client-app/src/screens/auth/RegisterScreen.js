import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, KeyboardAvoidingView, Platform, ScrollView,
  ActivityIndicator, Alert,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { register, clearError } from '../../store/slices/authSlice';
import { COLORS } from '../../utils/theme';

export default function RegisterScreen({ navigation }) {
  const dispatch = useDispatch();
  const { loading } = useSelector((s) => s.auth);
  const [form, setForm] = useState({ name: '', phone: '', password: '', confirmPassword: '' });

  const set = (key) => (val) => setForm((f) => ({ ...f, [key]: val }));

  const handleRegister = async () => {
    if (!form.name.trim() || !form.phone.trim() || !form.password) {
      Alert.alert('Хато', 'Лутфан ҳамаи майдонҳоро пур кунед');
      return;
    }
    if (form.password !== form.confirmPassword) {
      Alert.alert('Хато', 'Рамзҳо мувофиқат намекунанд');
      return;
    }
    if (form.password.length < 6) {
      Alert.alert('Хато', 'Рамз бояд ҳадди аққал 6 рақам дошта бошад');
      return;
    }
    const result = await dispatch(register({ name: form.name.trim(), phone: form.phone.trim(), password: form.password, role: 'client' }));
    if (result.error) Alert.alert('Хато', result.payload || 'Ба қайд гирифтан мумкин нашуд');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Text style={styles.backText}>← Бозгашт</Text>
          </TouchableOpacity>
          <View style={styles.header}>
            <Text style={styles.title}>Ба қайд гиред</Text>
            <Text style={styles.subtitle}>Ҳисоби нав эҷод кунед</Text>
          </View>

          <View style={styles.form}>
            {[
              { key: 'name', label: 'Ном ва насаб', placeholder: 'Номи пурраи шумо', type: 'default' },
              { key: 'phone', label: 'Рақами телефон', placeholder: '+992901234567', type: 'phone-pad' },
              { key: 'password', label: 'Рамз', placeholder: 'Ҳадди аққал 6 рақам', secure: true },
              { key: 'confirmPassword', label: 'Такрори рамз', placeholder: 'Рамзро дубора ворид кунед', secure: true },
            ].map(({ key, label, placeholder, type, secure }) => (
              <View key={key} style={styles.inputGroup}>
                <Text style={styles.label}>{label}</Text>
                <TextInput
                  style={styles.input}
                  placeholder={placeholder}
                  placeholderTextColor={COLORS.textSecondary}
                  value={form[key]}
                  onChangeText={set(key)}
                  keyboardType={type || 'default'}
                  secureTextEntry={secure}
                  autoCapitalize="none"
                />
              </View>
            ))}

            <TouchableOpacity style={styles.btn} onPress={handleRegister} disabled={loading} activeOpacity={0.85}>
              {loading
                ? <ActivityIndicator color={COLORS.white} />
                : <Text style={styles.btnText}>Ба қайд гирифтан</Text>}
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.linkBtn}
              onPress={() => { dispatch(clearError()); navigation.navigate('Login'); }}
            >
              <Text style={styles.linkText}>Ҳисоб доред? <Text style={{ color: COLORS.primary, fontWeight: '700' }}>Ворид шавед</Text></Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.white },
  container: { flexGrow: 1, padding: 24 },
  backBtn: { marginBottom: 16, marginTop: 8 },
  backText: { fontSize: 15, color: COLORS.primary, fontWeight: '600' },
  header: { marginBottom: 32 },
  title: { fontSize: 28, fontWeight: '800', color: COLORS.text, marginBottom: 6 },
  subtitle: { fontSize: 15, color: COLORS.textSecondary },
  form: { gap: 14 },
  inputGroup: { gap: 6 },
  label: { fontSize: 13, fontWeight: '600', color: COLORS.textSecondary },
  input: {
    borderWidth: 1, borderColor: COLORS.border, borderRadius: 10,
    padding: 13, fontSize: 15, color: COLORS.text, backgroundColor: COLORS.bg,
  },
  btn: { backgroundColor: COLORS.primary, borderRadius: 12, padding: 15, alignItems: 'center', marginTop: 8 },
  btnText: { color: COLORS.white, fontSize: 16, fontWeight: '700' },
  linkBtn: { alignItems: 'center', marginTop: 8 },
  linkText: { fontSize: 14, color: COLORS.textSecondary },
});

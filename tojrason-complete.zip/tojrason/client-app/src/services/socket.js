import { io } from 'socket.io-client';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SOCKET_URL = process.env.SOCKET_URL || 'http://10.0.2.2:5000';

let socket = null;

export async function connectSocket() {
  if (socket?.connected) return socket;
  const token = await AsyncStorage.getItem('accessToken');
  if (!token) return null;

  socket = io(SOCKET_URL, {
    auth: { token },
    transports: ['websocket'],
    reconnection: true,
    reconnectionAttempts: 10,
    reconnectionDelay: 2000,
  });

  return socket;
}

export function disconnectSocket() {
  if (socket) { socket.disconnect(); socket = null; }
}

export function getSocket() { return socket; }

export function joinOrderRoom(orderId) {
  if (socket) socket.emit('join:order', orderId);
}

export function leaveOrderRoom(orderId) {
  if (socket) socket.emit('leave:order', orderId);
}

export function onEvent(event, handler) {
  if (socket) socket.on(event, handler);
}

export function offEvent(event, handler) {
  if (socket) socket.off(event, handler);
}

export const COLORS = {
  primary: '#1a56db',
  primaryDark: '#1e429f',
  primaryLight: '#e8f0fe',
  success: '#0e9f6e',
  warning: '#f59e0b',
  danger: '#e02424',
  bg: '#f9fafb',
  surface: '#ffffff',
  border: '#e5e7eb',
  text: '#111827',
  textSecondary: '#6b7280',
  white: '#ffffff',
  black: '#000000',
};

export const FONTS = {
  regular: 'System',
  medium: 'System',
  bold: 'System',
};

export const STATUS_LABELS = {
  pending: 'Интизор',
  searching_courier: 'Ҷустуҷӯи курьер',
  courier_assigned: 'Курьер таъин шуд',
  courier_pickup: 'Курьер дар роҳ аст',
  in_transit: 'Дар роҳ аст',
  delivered: 'Расонида шуд',
  cancelled: 'Бекор шуд',
  failed: 'Нокомёб',
};

export const STATUS_COLORS = {
  pending: '#f59e0b',
  searching_courier: '#3b82f6',
  courier_assigned: '#8b5cf6',
  courier_pickup: '#f97316',
  in_transit: '#06b6d4',
  delivered: '#10b981',
  cancelled: '#ef4444',
  failed: '#6b7280',
};

import { createSlice } from '@reduxjs/toolkit';

const trackingSlice = createSlice({
  name: 'tracking',
  initialState: {
    courierLocation: null,
    orderStatus: null,
    connected: false,
  },
  reducers: {
    setCourierLocation(state, action) { state.courierLocation = action.payload; },
    setOrderStatus(state, action) { state.orderStatus = action.payload; },
    setConnected(state, action) { state.connected = action.payload; },
    clearTracking(state) { state.courierLocation = null; state.orderStatus = null; },
  },
});

export const { setCourierLocation, setOrderStatus, setConnected, clearTracking } = trackingSlice.actions;
export default trackingSlice.reducer;

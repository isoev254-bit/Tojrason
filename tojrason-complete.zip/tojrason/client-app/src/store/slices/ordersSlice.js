import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { ordersAPI } from '../../services/api';

export const createOrder = createAsyncThunk('orders/create', async (orderData, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.create(orderData);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message || 'Хато рух дод'); }
});

export const fetchMyOrders = createAsyncThunk('orders/fetchMy', async (params, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.getMy(params);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const fetchOrderById = createAsyncThunk('orders/fetchById', async (id, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.getById(id);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const cancelOrder = createAsyncThunk('orders/cancel', async ({ id, reason }, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.cancel(id, reason);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const rateOrder = createAsyncThunk('orders/rate', async ({ id, score, comment }, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.rate(id, { score, comment });
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const estimateFare = createAsyncThunk('orders/estimate', async (coords, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.estimate(coords);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

const ordersSlice = createSlice({
  name: 'orders',
  initialState: {
    list: [],
    currentOrder: null,
    estimate: null,
    total: 0,
    loading: false,
    creating: false,
    error: null,
  },
  reducers: {
    clearCurrentOrder(state) { state.currentOrder = null; },
    clearEstimate(state) { state.estimate = null; },
    clearError(state) { state.error = null; },
    updateCurrentOrder(state, action) {
      if (state.currentOrder?._id === action.payload.orderId) {
        state.currentOrder.status = action.payload.status;
      }
      const idx = state.list.findIndex((o) => o._id === action.payload.orderId);
      if (idx !== -1) state.list[idx].status = action.payload.status;
    },
    updateCourierLocation(state, action) {
      if (state.currentOrder) {
        state.currentOrder.courierLocation = action.payload;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createOrder.pending, (state) => { state.creating = true; state.error = null; })
      .addCase(createOrder.fulfilled, (state, action) => { state.creating = false; state.currentOrder = action.payload; })
      .addCase(createOrder.rejected, (state, action) => { state.creating = false; state.error = action.payload; })
      .addCase(fetchMyOrders.pending, (state) => { state.loading = true; })
      .addCase(fetchMyOrders.fulfilled, (state, action) => { state.loading = false; state.list = action.payload.orders; state.total = action.payload.total; })
      .addCase(fetchMyOrders.rejected, (state, action) => { state.loading = false; state.error = action.payload; })
      .addCase(fetchOrderById.fulfilled, (state, action) => { state.currentOrder = action.payload; })
      .addCase(cancelOrder.fulfilled, (state, action) => {
        state.currentOrder = action.payload;
        const idx = state.list.findIndex((o) => o._id === action.payload._id);
        if (idx !== -1) state.list[idx] = action.payload;
      })
      .addCase(rateOrder.fulfilled, (state, action) => {
        const idx = state.list.findIndex((o) => o._id === action.payload._id);
        if (idx !== -1) state.list[idx] = action.payload;
      })
      .addCase(estimateFare.fulfilled, (state, action) => { state.estimate = action.payload; });
  },
});

export const { clearCurrentOrder, clearEstimate, clearError, updateCurrentOrder, updateCourierLocation } = ordersSlice.actions;
export default ordersSlice.reducer;

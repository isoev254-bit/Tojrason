import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';
import { Toaster } from 'react-hot-toast';
import App from './App';
import { store } from './store';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: { fontFamily: 'Inter, sans-serif', fontSize: '14px' },
          success: { style: { background: '#f0fdf4', border: '1px solid #86efac', color: '#166534' } },
          error: { style: { background: '#fef2f2', border: '1px solid #fca5a5', color: '#991b1b' } },
        }}
      />
    </Provider>
  </React.StrictMode>
);

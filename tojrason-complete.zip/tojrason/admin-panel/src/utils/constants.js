export const STATUS_LABELS = {
  pending: 'Интизор',
  searching_courier: 'Ҷустуҷӯи курьер',
  courier_assigned: 'Курьер таъин шуд',
  courier_pickup: 'Гирифтан',
  in_transit: 'Дар роҳ',
  delivered: 'Расонида шуд',
  cancelled: 'Бекор шуд',
  failed: 'Нокомёб',
};

export const STATUS_BADGES = {
  pending: 'badge-pending',
  searching_courier: 'badge-searching',
  courier_assigned: 'badge-assigned',
  courier_pickup: 'badge-pickup',
  in_transit: 'badge-transit',
  delivered: 'badge-delivered',
  cancelled: 'badge-cancelled',
  failed: 'badge-failed',
};

export const VEHICLE_LABELS = {
  bicycle: '🚲 Велосипед',
  motorcycle: '🛵 Мотосикл',
  car: '🚗 Мошин',
  van: '🚐 Фургон',
  on_foot: '🚶 Пиёда',
};

export const PAYMENT_LABELS = {
  cash: 'Нақд',
  card: 'Корти бонкӣ',
  wallet: 'Ҳамён',
};

export const CATEGORY_LABELS = {
  document: '📄 Ҳуҷҷат',
  package: '📦 Баста',
  food: '🍱 Хӯрок',
  electronics: '📱 Электроника',
  clothing: '👔 Либос',
  other: '📌 Дигар',
};

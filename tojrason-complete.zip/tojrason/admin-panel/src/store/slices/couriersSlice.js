import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { couriersAPI } from '../../services/api';

export const fetchCouriers = createAsyncThunk('couriers/fetchAll', async (params, { rejectWithValue }) => {
  try {
    const { data } = await couriersAPI.getAll(params);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const fetchOnlineCouriers = createAsyncThunk('couriers/fetchOnline', async (_, { rejectWithValue }) => {
  try {
    const { data } = await couriersAPI.getOnline();
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const verifyCourier = createAsyncThunk('couriers/verify', async ({ id, status }, { rejectWithValue }) => {
  try {
    const { data } = await couriersAPI.verify(id, status);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

const couriersSlice = createSlice({
  name: 'couriers',
  initialState: {
    list: [],
    onlineCouriers: [],
    total: 0,
    totalPages: 1,
    loading: false,
    error: null,
  },
  reducers: {
    updateCourierLocation(state, action) {
      const { courierId, lat, lng } = action.payload;
      const idx = state.onlineCouriers.findIndex((c) => c.user?._id === courierId);
      if (idx !== -1) state.onlineCouriers[idx].liveLocation = { lat, lng, timestamp: Date.now() };
    },
    updateCourierStatus(state, action) {
      const { courierId, isOnline } = action.payload;
      const idx = state.onlineCouriers.findIndex((c) => c.user?._id === courierId);
      if (!isOnline && idx !== -1) state.onlineCouriers.splice(idx, 1);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCouriers.pending, (state) => { state.loading = true; })
      .addCase(fetchCouriers.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.couriers;
        state.total = action.payload.total;
        state.totalPages = action.payload.totalPages;
      })
      .addCase(fetchCouriers.rejected, (state, action) => { state.loading = false; state.error = action.payload; })
      .addCase(fetchOnlineCouriers.fulfilled, (state, action) => { state.onlineCouriers = action.payload; })
      .addCase(verifyCourier.fulfilled, (state, action) => {
        const idx = state.list.findIndex((c) => c._id === action.payload._id);
        if (idx !== -1) state.list[idx] = action.payload;
      });
  },
});

export const { updateCourierLocation, updateCourierStatus } = couriersSlice.actions;
export default couriersSlice.reducer;

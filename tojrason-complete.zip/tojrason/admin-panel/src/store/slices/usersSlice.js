import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { usersAPI } from '../../services/api';

export const fetchUsers = createAsyncThunk('users/fetchAll', async (params, { rejectWithValue }) => {
  try {
    const { data } = await usersAPI.getAll(params);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const deactivateUser = createAsyncThunk('users/deactivate', async (id, { rejectWithValue }) => {
  try {
    await usersAPI.deactivate(id);
    return id;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

const usersSlice = createSlice({
  name: 'users',
  initialState: { list: [], total: 0, totalPages: 1, loading: false, error: null },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchUsers.pending, (state) => { state.loading = true; })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.users;
        state.total = action.payload.total;
        state.totalPages = action.payload.totalPages;
      })
      .addCase(fetchUsers.rejected, (state, action) => { state.loading = false; state.error = action.payload; })
      .addCase(deactivateUser.fulfilled, (state, action) => {
        const idx = state.list.findIndex((u) => u._id === action.payload);
        if (idx !== -1) state.list[idx].isActive = false;
      });
  },
});

export default usersSlice.reducer;

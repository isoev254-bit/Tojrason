import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { ordersAPI } from '../../services/api';

export const fetchOrders = createAsyncThunk('orders/fetchAll', async (params, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.getAll(params);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const fetchOrderStats = createAsyncThunk('orders/fetchStats', async (_, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.getStats();
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const cancelOrderAdmin = createAsyncThunk('orders/cancel', async ({ id, reason }, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.cancel(id, reason);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

const ordersSlice = createSlice({
  name: 'orders',
  initialState: {
    list: [],
    stats: null,
    total: 0,
    page: 1,
    totalPages: 1,
    loading: false,
    error: null,
    realtimeUpdates: [],
  },
  reducers: {
    addRealtimeUpdate(state, action) {
      state.realtimeUpdates.unshift(action.payload);
      if (state.realtimeUpdates.length > 50) state.realtimeUpdates.pop();
      const idx = state.list.findIndex((o) => o._id === action.payload.orderId);
      if (idx !== -1) state.list[idx].status = action.payload.status;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchOrders.pending, (state) => { state.loading = true; state.error = null; })
      .addCase(fetchOrders.fulfilled, (state, action) => {
        state.loading = false;
        state.list = action.payload.orders;
        state.total = action.payload.total;
        state.page = action.payload.page;
        state.totalPages = action.payload.totalPages;
      })
      .addCase(fetchOrders.rejected, (state, action) => { state.loading = false; state.error = action.payload; })
      .addCase(fetchOrderStats.fulfilled, (state, action) => { state.stats = action.payload; })
      .addCase(cancelOrderAdmin.fulfilled, (state, action) => {
        const idx = state.list.findIndex((o) => o._id === action.payload._id);
        if (idx !== -1) state.list[idx] = action.payload;
      });
  },
});

export const { addRealtimeUpdate } = ordersSlice.actions;
export default ordersSlice.reducer;

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { STATUS_LABELS, STATUS_BADGES } from '../../utils/constants';

export default function RecentOrders({ orders }) {
  const navigate = useNavigate();
  if (!orders?.length) return <div className="empty-state">📭<p>Фармоишҳо мавҷуд нестанд</p></div>;

  return (
    <div style={{ overflowX: 'auto' }}>
      <table>
        <thead>
          <tr>
            <th>№ Фармоиш</th>
            <th>Муштарӣ</th>
            <th>Ҳолат</th>
            <th>Нарх</th>
            <th>Вақт</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order._id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/orders/${order._id}`)}>
              <td><code style={{ fontSize: 12, background: '#f3f4f6', padding: '2px 6px', borderRadius: 4 }}>{order.orderNumber}</code></td>
              <td>{order.client?.name || '—'}</td>
              <td><span className={`badge ${STATUS_BADGES[order.status] || 'badge-pending'}`}>{STATUS_LABELS[order.status] || order.status}</span></td>
              <td><strong>{order.pricing?.total?.toFixed(2)} с.</strong></td>
              <td style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{new Date(order.createdAt).toLocaleString('ru')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

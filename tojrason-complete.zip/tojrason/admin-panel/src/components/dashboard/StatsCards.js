import React from 'react';

const STAT_DEFS = [
  { key: 'orders.total', label: 'Ҳамаи фармоишҳо', icon: '📦', bg: '#dbeafe', color: '#1e40af' },
  { key: 'orders.pending', label: 'Фаъол', icon: '⏳', bg: '#fef3c7', color: '#92400e' },
  { key: 'orders.delivered', label: 'Расонидашуда', icon: '✅', bg: '#d1fae5', color: '#065f46' },
  { key: 'couriers.online', label: 'Курьерони онлайн', icon: '🛵', bg: '#ede9fe', color: '#5b21b6' },
  { key: 'clients.total', label: 'Муштариён', icon: '👥', bg: '#fce7f3', color: '#9d174d' },
  { key: 'revenue.total', label: 'Даромад (сомонӣ)', icon: '💰', bg: '#d1fae5', color: '#065f46', format: 'money' },
];

function getValue(obj, path) {
  return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

export default function StatsCards({ stats }) {
  if (!stats) return null;
  return (
    <div className="stats-grid">
      {STAT_DEFS.map((def) => {
        const val = getValue(stats, def.key) || 0;
        return (
          <div key={def.key} className="card stat-card">
            <div className="stat-icon" style={{ background: def.bg, color: def.color }}>
              {def.icon}
            </div>
            <div className="stat-info">
              <h3 style={{ color: def.color }}>
                {def.format === 'money' ? `${Number(val).toFixed(0)}` : val}
              </h3>
              <p>{def.label}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

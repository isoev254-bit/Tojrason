import React, { useEffect, useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../../store/slices/authSlice';
import { connectSocket, onEvent, offEvent } from '../../services/socket';
import { addRealtimeUpdate } from '../../store/slices/ordersSlice';
import { updateCourierLocation, updateCourierStatus } from '../../store/slices/couriersSlice';
import './Layout.css';

const NAV_ITEMS = [
  { path: '/', label: 'Дашборд', icon: '📊', exact: true },
  { path: '/orders', label: 'Фармоишҳо', icon: '📦' },
  { path: '/couriers', label: 'Курьерон', icon: '🛵' },
  { path: '/users', label: 'Корбарон', icon: '👥' },
  { path: '/map', label: 'Харита', icon: '🗺️' },
];

export default function Layout() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((s) => s.auth);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (!token) return;
    const socket = connectSocket(token);

    const handleNewOrder = (data) => {
      setNotifications((prev) => [{ type: 'new_order', data, id: Date.now() }, ...prev.slice(0, 9)]);
    };
    const handleStatusChange = (data) => { dispatch(addRealtimeUpdate(data)); };
    const handleLocation = (data) => { dispatch(updateCourierLocation(data)); };
    const handleCourierStatus = (data) => { dispatch(updateCourierStatus(data)); };

    onEvent('order:new', handleNewOrder);
    onEvent('order:status_changed', handleStatusChange);
    onEvent('courier:location', handleLocation);
    onEvent('courier:status_changed', handleCourierStatus);

    return () => {
      offEvent('order:new', handleNewOrder);
      offEvent('order:status_changed', handleStatusChange);
      offEvent('courier:location', handleLocation);
      offEvent('courier:status_changed', handleCourierStatus);
    };
  }, [dispatch]);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login');
  };

  return (
    <div className={`layout ${sidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
      <aside className="sidebar">
        <div className="sidebar-header">
          <span className="logo">🚚 Тоҷрасон</span>
          <button className="sidebar-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>☰</button>
        </div>
        <nav className="sidebar-nav">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.exact}
              className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="user-info">
            <div className="user-avatar">{user?.name?.[0]?.toUpperCase()}</div>
            <div className="user-details">
              <span className="user-name">{user?.name}</span>
              <span className="user-role">Администратор</span>
            </div>
          </div>
          <button className="logout-btn" onClick={handleLogout} title="Хуруҷ">⇥</button>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>☰</button>
            <span className="topbar-title">Панели Идоракунӣ</span>
          </div>
          <div className="topbar-right">
            {notifications.length > 0 && (
              <div className="notification-bell" onClick={() => setNotifications([])}>
                🔔
                <span className="notif-badge">{notifications.length}</span>
              </div>
            )}
            <div className="online-indicator">
              <span className="dot" />
              Онлайн
            </div>
          </div>
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

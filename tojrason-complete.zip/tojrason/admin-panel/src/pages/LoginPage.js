import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loginAdmin, clearError } from '../store/slices/authSlice';
import './LoginPage.css';

export default function LoginPage() {
  const dispatch = useDispatch();
  const { loading, error } = useSelector((s) => s.auth);
  const [form, setForm] = useState({ phone: '', password: '' });

  useEffect(() => { return () => dispatch(clearError()); }, [dispatch]);

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(loginAdmin(form));
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo">🚚</div>
        <h1 className="login-title">Тоҷрасон</h1>
        <p className="login-subtitle">Панели Идоракунӣ</p>

        <form onSubmit={handleSubmit} className="login-form">
          {error && <div className="login-error">{error}</div>}
          <div className="form-group">
            <label className="form-label">Рақами телефон</label>
            <input
              type="tel"
              className="form-control"
              placeholder="+992901234567"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              required
              autoComplete="tel"
            />
          </div>
          <div className="form-group">
            <label className="form-label">Рамз</label>
            <input
              type="password"
              className="form-control"
              placeholder="Рамзи худро ворид кунед"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              required
              autoComplete="current-password"
            />
          </div>
          <button type="submit" className="btn btn-primary login-btn" disabled={loading}>
            {loading ? 'Дар ҳоли коркард...' : 'Ворид шудан'}
          </button>
        </form>
      </div>
    </div>
  );
}

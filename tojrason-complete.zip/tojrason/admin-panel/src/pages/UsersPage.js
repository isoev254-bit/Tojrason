import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUsers, deactivateUser } from '../store/slices/usersSlice';
import toast from 'react-hot-toast';

export default function UsersPage() {
  const dispatch = useDispatch();
  const { list, total, totalPages, loading } = useSelector((s) => s.users);
  const [page, setPage] = useState(1);
  const [role, setRole] = useState('');
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');

  useEffect(() => {
    dispatch(fetchUsers({ page, limit: 20, role: role || undefined, search: search || undefined }));
  }, [dispatch, page, role, search]);

  const handleDeactivate = async (id, name) => {
    if (!window.confirm(`Оё мехоҳед ${name}-ро ғайрифаъол кунед?`)) return;
    const result = await dispatch(deactivateUser(id));
    if (!result.error) toast.success('Корбар ғайрифаъол карда шуд');
    else toast.error('Хато рух дод');
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setSearch(searchInput);
    setPage(1);
  };

  const ROLE_LABELS = { client: 'Муштарӣ', courier: 'Курьер', admin: 'Админ' };
  const ROLE_COLORS = { client: '#dbeafe', courier: '#ede9fe', admin: '#fee2e2' };
  const ROLE_TEXT = { client: '#1e40af', courier: '#5b21b6', admin: '#991b1b' };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">👥 Корбарон</h1>
        <span style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Ҳамаги: {total}</span>
      </div>

      <div className="card">
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
          <form onSubmit={handleSearch} style={{ display: 'flex', gap: 8 }}>
            <input
              className="form-control"
              style={{ maxWidth: 240 }}
              placeholder="Ном ё рақами телефон..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
            />
            <button type="submit" className="btn btn-primary btn-sm">Ҷустуҷӯ</button>
          </form>
          <select className="form-control" style={{ maxWidth: 160 }} value={role} onChange={(e) => { setRole(e.target.value); setPage(1); }}>
            <option value="">Ҳамаи нақшҳо</option>
            <option value="client">Муштариён</option>
            <option value="courier">Курьерон</option>
            <option value="admin">Администраторон</option>
          </select>
        </div>

        {loading ? (
          <div className="loading-spinner"><div className="spinner" /></div>
        ) : list.length === 0 ? (
          <div className="empty-state">👥<p>Корбарон мавҷуд нестанд</p></div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table>
              <thead>
                <tr>
                  <th>Корбар</th>
                  <th>Телефон</th>
                  <th>Нақш</th>
                  <th>Ҳолат</th>
                  <th>Санаи қайд</th>
                  <th>Вуруди охирин</th>
                  <th>Амал</th>
                </tr>
              </thead>
              <tbody>
                {list.map((user) => (
                  <tr key={user._id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ width: 34, height: 34, borderRadius: '50%', background: ROLE_COLORS[user.role], color: ROLE_TEXT[user.role], display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 14, flexShrink: 0 }}>
                          {user.name?.[0]?.toUpperCase()}
                        </div>
                        <span style={{ fontWeight: 500 }}>{user.name}</span>
                      </div>
                    </td>
                    <td>{user.phone}</td>
                    <td>
                      <span className="badge" style={{ background: ROLE_COLORS[user.role], color: ROLE_TEXT[user.role] }}>
                        {ROLE_LABELS[user.role]}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${user.isActive ? 'badge-delivered' : 'badge-cancelled'}`}>
                        {user.isActive ? 'Фаъол' : 'Ғайрифаъол'}
                      </span>
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                      {new Date(user.createdAt).toLocaleDateString('ru')}
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
                      {user.lastLogin ? new Date(user.lastLogin).toLocaleString('ru') : '—'}
                    </td>
                    <td>
                      {user.isActive && user.role !== 'admin' && (
                        <button className="btn btn-danger btn-sm" onClick={() => handleDeactivate(user._id, user.name)}>
                          Ғайрифаъол
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="pagination">
          <button onClick={() => setPage(1)} disabled={page === 1}>«</button>
          <button onClick={() => setPage(p => p - 1)} disabled={page === 1}>‹</button>
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
            return p <= totalPages ? (
              <button key={p} onClick={() => setPage(p)} className={page === p ? 'active' : ''}>{p}</button>
            ) : null;
          })}
          <button onClick={() => setPage(p => p + 1)} disabled={page === totalPages}>›</button>
          <button onClick={() => setPage(totalPages)} disabled={page === totalPages}>»</button>
        </div>
      </div>
    </div>
  );
}

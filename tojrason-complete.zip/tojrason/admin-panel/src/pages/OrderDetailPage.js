import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ordersAPI } from '../services/api';
import { STATUS_LABELS, STATUS_BADGES, VEHICLE_LABELS, PAYMENT_LABELS, CATEGORY_LABELS } from '../utils/constants';
import toast from 'react-hot-toast';
import './OrderDetailPage.css';

export default function OrderDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    ordersAPI.getById(id)
      .then(({ data }) => setOrder(data.data))
      .catch(() => { toast.error('Фармоиш ёфт нашуд'); navigate('/orders'); })
      .finally(() => setLoading(false));
  }, [id, navigate]);

  const handleCancel = async () => {
    if (!window.confirm('Оё бекор кардан мехоҳед?')) return;
    try {
      await ordersAPI.cancel(id, 'Администратор бекор кард');
      toast.success('Фармоиш бекор карда шуд');
      const { data } = await ordersAPI.getById(id);
      setOrder(data.data);
    } catch { toast.error('Хато рух дод'); }
  };

  if (loading) return <div className="loading-spinner"><div className="spinner" /></div>;
  if (!order) return null;

  return (
    <div className="order-detail">
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/orders')}>← Бозгашт</button>
          <h1 className="page-title">Фармоиш #{order.orderNumber}</h1>
          <span className={`badge ${STATUS_BADGES[order.status]}`}>{STATUS_LABELS[order.status]}</span>
        </div>
        {['pending','searching_courier','courier_assigned'].includes(order.status) && (
          <button className="btn btn-danger" onClick={handleCancel}>Бекор кардан</button>
        )}
      </div>

      <div className="order-grid">
        {/* Left column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Locations */}
          <div className="card">
            <div className="card-header"><h2 className="card-title">📍 Суроғаҳо</h2></div>
            <div className="location-blocks">
              <div className="location-block pickup">
                <div className="location-label">📦 Гирифтан</div>
                <div className="location-address">{order.pickup.address}</div>
                {order.pickup.contactName && <div className="location-contact">👤 {order.pickup.contactName}</div>}
                {order.pickup.contactPhone && <div className="location-contact">📞 {order.pickup.contactPhone}</div>}
                {order.pickup.notes && <div className="location-notes">💬 {order.pickup.notes}</div>}
              </div>
              <div className="location-arrow">↓</div>
              <div className="location-block delivery">
                <div className="location-label">🏠 Расондан</div>
                <div className="location-address">{order.delivery.address}</div>
                {order.delivery.contactName && <div className="location-contact">👤 {order.delivery.contactName}</div>}
                {order.delivery.contactPhone && <div className="location-contact">📞 {order.delivery.contactPhone}</div>}
                {order.delivery.notes && <div className="location-notes">💬 {order.delivery.notes}</div>}
              </div>
            </div>
          </div>

          {/* Package */}
          <div className="card">
            <div className="card-header"><h2 className="card-title">📦 Маълумот дар бораи баста</h2></div>
            <div className="detail-list">
              <div className="detail-row"><span>Тавсиф</span><strong>{order.packageDetails.description}</strong></div>
              <div className="detail-row"><span>Вазн</span><strong>{order.packageDetails.weight} кг</strong></div>
              <div className="detail-row"><span>Категория</span><strong>{CATEGORY_LABELS[order.packageDetails.category]}</strong></div>
              <div className="detail-row"><span>Шикастанӣ</span><strong>{order.packageDetails.fragile ? '⚠️ Ҳа' : 'Не'}</strong></div>
            </div>
          </div>

          {/* Pricing */}
          <div className="card">
            <div className="card-header"><h2 className="card-title">💰 Нарх</h2></div>
            <div className="detail-list">
              <div className="detail-row"><span>Нархи асосӣ</span><span>{order.pricing.baseFare?.toFixed(2)} с.</span></div>
              <div className="detail-row"><span>Нархи масофа</span><span>{order.pricing.distanceFare?.toFixed(2)} с.</span></div>
              <div className="detail-row"><span>Нархи вазн</span><span>{order.pricing.weightFare?.toFixed(2)} с.</span></div>
              <div className="detail-row"><span>Иловапардохт</span><span>{order.pricing.surcharge?.toFixed(2)} с.</span></div>
              <div className="detail-row total-row"><span>Ҳамагӣ</span><strong>{order.pricing.total?.toFixed(2)} с.</strong></div>
              <div className="detail-row"><span>Усули пардохт</span><strong>{PAYMENT_LABELS[order.paymentMethod]}</strong></div>
              <div className="detail-row"><span>Ҳолати пардохт</span>
                <span className={`badge ${order.paymentStatus === 'paid' ? 'badge-delivered' : 'badge-pending'}`}>
                  {order.paymentStatus === 'paid' ? 'Пардохт шуд' : 'Интизор'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Client */}
          <div className="card">
            <div className="card-header"><h2 className="card-title">👤 Муштарӣ</h2></div>
            <div className="detail-list">
              <div className="detail-row"><span>Ном</span><strong>{order.client?.name}</strong></div>
              <div className="detail-row"><span>Телефон</span><strong>{order.client?.phone}</strong></div>
            </div>
          </div>

          {/* Courier */}
          <div className="card">
            <div className="card-header"><h2 className="card-title">🛵 Курьер</h2></div>
            {order.courier ? (
              <div className="detail-list">
                <div className="detail-row"><span>Ном</span><strong>{order.courier.name}</strong></div>
                <div className="detail-row"><span>Телефон</span><strong>{order.courier.phone}</strong></div>
              </div>
            ) : (
              <div className="empty-state" style={{ padding: '20px' }}>Курьер таъин нашудааст</div>
            )}
          </div>

          {/* Route info */}
          <div className="card">
            <div className="card-header"><h2 className="card-title">🗺️ Маршрут</h2></div>
            <div className="detail-list">
              <div className="detail-row"><span>Масофа</span><strong>{order.distance?.toFixed(2)} км</strong></div>
              <div className="detail-row"><span>Вақти тахминӣ</span><strong>{order.estimatedDuration} дақиқа</strong></div>
              {order.pickedUpAt && <div className="detail-row"><span>Гирифтан</span><strong>{new Date(order.pickedUpAt).toLocaleString('ru')}</strong></div>}
              {order.deliveredAt && <div className="detail-row"><span>Расондан</span><strong>{new Date(order.deliveredAt).toLocaleString('ru')}</strong></div>}
            </div>
          </div>

          {/* Rating */}
          {order.rating?.score && (
            <div className="card">
              <div className="card-header"><h2 className="card-title">⭐ Баҳогузорӣ</h2></div>
              <div className="detail-list">
                <div className="detail-row"><span>Баҳо</span><strong>{'⭐'.repeat(order.rating.score)} ({order.rating.score}/5)</strong></div>
                {order.rating.comment && <div className="detail-row"><span>Изоҳ</span><strong>{order.rating.comment}</strong></div>}
              </div>
            </div>
          )}

          {/* Tracking */}
          <div className="card">
            <div className="card-header"><h2 className="card-title">📋 Таърихи ҳолат</h2></div>
            <div className="tracking-list">
              {[...order.trackingHistory].reverse().map((event, idx) => (
                <div key={idx} className="tracking-item">
                  <div className="tracking-dot" />
                  <div>
                    <div className="tracking-status">{STATUS_LABELS[event.status] || event.status}</div>
                    {event.message && <div className="tracking-msg">{event.message}</div>}
                    <div className="tracking-time">{new Date(event.timestamp).toLocaleString('ru')}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

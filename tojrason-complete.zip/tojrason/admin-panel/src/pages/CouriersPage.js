import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCouriers, verifyCourier } from '../store/slices/couriersSlice';
import { VEHICLE_LABELS } from '../utils/constants';
import toast from 'react-hot-toast';
import './CouriersPage.css';

export default function CouriersPage() {
  const dispatch = useDispatch();
  const { list, total, totalPages, loading } = useSelector((s) => s.couriers);
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState({ verificationStatus: '', isOnline: '' });

  useEffect(() => {
    const params = { page, limit: 20 };
    if (filter.verificationStatus) params.verificationStatus = filter.verificationStatus;
    if (filter.isOnline !== '') params.isOnline = filter.isOnline;
    dispatch(fetchCouriers(params));
  }, [dispatch, page, filter]);

  const handleVerify = async (id, status) => {
    const label = status === 'verified' ? 'тасдиқ' : 'рад';
    if (!window.confirm(`Оё мехоҳед ин курьерро ${label} кунед?`)) return;
    const result = await dispatch(verifyCourier({ id, status }));
    if (!result.error) toast.success(`Курьер ${label} карда шуд`);
    else toast.error('Хато рух дод');
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">🛵 Курьерон</h1>
        <span style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Ҳамаги: {total}</span>
      </div>

      <div className="card">
        <div className="couriers-filters">
          <select className="form-control" style={{ maxWidth: 200 }}
            value={filter.verificationStatus}
            onChange={(e) => { setFilter({ ...filter, verificationStatus: e.target.value }); setPage(1); }}>
            <option value="">Ҳамаи тасдиқ</option>
            <option value="pending">Интизор</option>
            <option value="verified">Тасдиқ шуда</option>
            <option value="rejected">Рад шуда</option>
          </select>
          <select className="form-control" style={{ maxWidth: 200 }}
            value={filter.isOnline}
            onChange={(e) => { setFilter({ ...filter, isOnline: e.target.value }); setPage(1); }}>
            <option value="">Ҳамаи ҳолат</option>
            <option value="true">Онлайн</option>
            <option value="false">Офлайн</option>
          </select>
        </div>

        {loading ? (
          <div className="loading-spinner"><div className="spinner" /></div>
        ) : list.length === 0 ? (
          <div className="empty-state">🛵<p>Курьерон мавҷуд нестанд</p></div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table>
              <thead>
                <tr>
                  <th>Курьер</th>
                  <th>Нақлиёт</th>
                  <th>Ҳолат</th>
                  <th>Тасдиқ</th>
                  <th>Расонишҳо</th>
                  <th>Даромад</th>
                  <th>Рейтинг</th>
                  <th>Амал</th>
                </tr>
              </thead>
              <tbody>
                {list.map((courier) => (
                  <tr key={courier._id}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{courier.user?.name}</div>
                      <small style={{ color: 'var(--text-secondary)' }}>{courier.user?.phone}</small>
                    </td>
                    <td>{VEHICLE_LABELS[courier.vehicleType] || courier.vehicleType}</td>
                    <td>
                      <span className={`badge ${courier.isOnline ? 'badge-online' : 'badge-offline'}`}>
                        {courier.isOnline ? 'Онлайн' : 'Офлайн'}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${courier.verificationStatus === 'verified' ? 'badge-verified' : courier.verificationStatus === 'rejected' ? 'badge-rejected' : 'badge-pending-v'}`}>
                        {courier.verificationStatus === 'verified' ? 'Тасдиқ' : courier.verificationStatus === 'rejected' ? 'Рад' : 'Интизор'}
                      </span>
                    </td>
                    <td>{courier.stats?.completedDeliveries || 0}</td>
                    <td>{(courier.stats?.totalEarnings || 0).toFixed(0)} с.</td>
                    <td>
                      {courier.stats?.averageRating > 0
                        ? <span>⭐ {courier.stats.averageRating.toFixed(1)}</span>
                        : '—'}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        {courier.verificationStatus !== 'verified' && (
                          <button className="btn btn-success btn-sm" onClick={() => handleVerify(courier._id, 'verified')}>✓ Тасдиқ</button>
                        )}
                        {courier.verificationStatus !== 'rejected' && (
                          <button className="btn btn-danger btn-sm" onClick={() => handleVerify(courier._id, 'rejected')}>✗ Рад</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="pagination">
          <button onClick={() => setPage(1)} disabled={page === 1}>«</button>
          <button onClick={() => setPage(p => p - 1)} disabled={page === 1}>‹</button>
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
            return p <= totalPages ? (
              <button key={p} onClick={() => setPage(p)} className={page === p ? 'active' : ''}>{p}</button>
            ) : null;
          })}
          <button onClick={() => setPage(p => p + 1)} disabled={page === totalPages}>›</button>
          <button onClick={() => setPage(totalPages)} disabled={page === totalPages}>»</button>
        </div>
      </div>
    </div>
  );
}

import React, { useEffect, useRef, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchOnlineCouriers } from '../store/slices/couriersSlice';
import { VEHICLE_LABELS } from '../utils/constants';
import './MapPage.css';

const GOOGLE_MAPS_KEY = process.env.REACT_APP_GOOGLE_MAPS_KEY || '';

export default function MapPage() {
  const dispatch = useDispatch();
  const { onlineCouriers } = useSelector((s) => s.couriers);
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef({});
  const [selected, setSelected] = useState(null);
  const [mapLoaded, setMapLoaded] = useState(false);

  useEffect(() => {
    dispatch(fetchOnlineCouriers());
    const interval = setInterval(() => dispatch(fetchOnlineCouriers()), 10000);
    return () => clearInterval(interval);
  }, [dispatch]);

  useEffect(() => {
    if (!GOOGLE_MAPS_KEY) { setMapLoaded(false); return; }
    if (window.google?.maps) { initMap(); return; }
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_KEY}&libraries=places`;
    script.async = true;
    script.onload = () => { setMapLoaded(true); initMap(); };
    document.head.appendChild(script);
  }, []);

  function initMap() {
    if (!mapRef.current || mapInstanceRef.current) return;
    mapInstanceRef.current = new window.google.maps.Map(mapRef.current, {
      center: { lat: 38.5598, lng: 68.7737 },
      zoom: 13,
      styles: [
        { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
      ],
    });
    setMapLoaded(true);
  }

  useEffect(() => {
    if (!mapInstanceRef.current || !window.google?.maps) return;
    const currentIds = new Set(onlineCouriers.map((c) => c.user?._id));

    Object.keys(markersRef.current).forEach((id) => {
      if (!currentIds.has(id)) {
        markersRef.current[id].setMap(null);
        delete markersRef.current[id];
      }
    });

    onlineCouriers.forEach((courier) => {
      const id = courier.user?._id;
      if (!id) return;
      const loc = courier.liveLocation || courier.currentLocation;
      if (!loc?.lat || !loc?.lng) return;

      const position = { lat: loc.lat, lng: loc.lng };
      if (markersRef.current[id]) {
        markersRef.current[id].setPosition(position);
      } else {
        markersRef.current[id] = new window.google.maps.Marker({
          position,
          map: mapInstanceRef.current,
          title: courier.user?.name,
          icon: {
            url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(
              `<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36">
                <circle cx="18" cy="18" r="16" fill="#1a56db" stroke="white" stroke-width="2"/>
                <text x="18" y="24" text-anchor="middle" font-size="16">🛵</text>
              </svg>`
            ),
            scaledSize: new window.google.maps.Size(36, 36),
          },
        });
        markersRef.current[id].addListener('click', () => setSelected(courier));
      }
    });
  }, [onlineCouriers]);

  return (
    <div className="map-page">
      <div className="page-header">
        <h1 className="page-title">🗺️ Харитаи зинда</h1>
        <span className="badge badge-online">{onlineCouriers.length} курьери онлайн</span>
      </div>

      <div className="map-layout">
        <div className="map-sidebar">
          <div className="map-sidebar-header">Курьерони онлайн</div>
          {onlineCouriers.length === 0 ? (
            <div className="empty-state" style={{ padding: 20 }}>🛵<p>Курьерон нестанд</p></div>
          ) : (
            onlineCouriers.map((courier) => (
              <div
                key={courier._id}
                className={`courier-list-item ${selected?._id === courier._id ? 'active' : ''}`}
                onClick={() => {
                  setSelected(courier);
                  const loc = courier.liveLocation || courier.currentLocation;
                  if (loc && mapInstanceRef.current) {
                    mapInstanceRef.current.panTo({ lat: loc.lat, lng: loc.lng });
                    mapInstanceRef.current.setZoom(16);
                  }
                }}
              >
                <div className="courier-avatar">{courier.user?.name?.[0]?.toUpperCase()}</div>
                <div className="courier-info">
                  <div className="courier-name">{courier.user?.name}</div>
                  <div className="courier-vehicle">{VEHICLE_LABELS[courier.vehicleType]}</div>
                  <div className={`courier-avail ${courier.isAvailable ? 'avail' : 'busy'}`}>
                    {courier.isAvailable ? '✅ Озод' : '📦 Банд'}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="map-container">
          {!GOOGLE_MAPS_KEY ? (
            <div className="map-placeholder">
              <div className="map-placeholder-content">
                <div style={{ fontSize: 48, marginBottom: 16 }}>🗺️</div>
                <h3>Google Maps калид дарозкунӣ лозим аст</h3>
                <p>REACT_APP_GOOGLE_MAPS_KEY-ро ба файли .env илова кунед</p>
                <div style={{ marginTop: 24, textAlign: 'left', background: '#f3f4f6', padding: 16, borderRadius: 8 }}>
                  <strong>Курьерони онлайн ({onlineCouriers.length}):</strong>
                  {onlineCouriers.map((c) => (
                    <div key={c._id} style={{ marginTop: 8, fontSize: 13 }}>
                      🛵 {c.user?.name} — {c.liveLocation ? `${c.liveLocation.lat?.toFixed(4)}, ${c.liveLocation.lng?.toFixed(4)}` : 'Мавқеия нест'}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div ref={mapRef} style={{ width: '100%', height: '100%' }} />
          )}
        </div>
      </div>

      {selected && (
        <div className="courier-popup" onClick={() => setSelected(null)}>
          <div className="courier-popup-card" onClick={(e) => e.stopPropagation()}>
            <button className="popup-close" onClick={() => setSelected(null)}>✕</button>
            <h3>{selected.user?.name}</h3>
            <p>{selected.user?.phone}</p>
            <div className="popup-details">
              <div><span>Нақлиёт</span><strong>{VEHICLE_LABELS[selected.vehicleType]}</strong></div>
              <div><span>Ҳолат</span><strong>{selected.isAvailable ? '✅ Озод' : '📦 Банд'}</strong></div>
              <div><span>Расонишҳо</span><strong>{selected.stats?.completedDeliveries || 0}</strong></div>
              <div><span>Рейтинг</span><strong>{selected.stats?.averageRating > 0 ? `⭐ ${selected.stats.averageRating}` : '—'}</strong></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchDashboardStats } from '../store/slices/dashboardSlice';
import { fetchOrders } from '../store/slices/ordersSlice';
import { fetchOnlineCouriers } from '../store/slices/couriersSlice';
import RecentOrders from '../components/dashboard/RecentOrders';
import StatsCards from '../components/dashboard/StatsCards';
import './DashboardPage.css';

export default function DashboardPage() {
  const dispatch = useDispatch();
  const { stats, loading } = useSelector((s) => s.dashboard);
  const { list: recentOrders } = useSelector((s) => s.orders);

  useEffect(() => {
    dispatch(fetchDashboardStats());
    dispatch(fetchOrders({ limit: 10 }));
    dispatch(fetchOnlineCouriers());

    const interval = setInterval(() => {
      dispatch(fetchDashboardStats());
      dispatch(fetchOnlineCouriers());
    }, 30000);
    return () => clearInterval(interval);
  }, [dispatch]);

  if (loading && !stats) {
    return <div className="loading-spinner"><div className="spinner" /></div>;
  }

  return (
    <div className="dashboard">
      <div className="page-header">
        <h1 className="page-title">Дашборд</h1>
        <span className="last-updated">Навсозии охирин: ҳозир</span>
      </div>

      <StatsCards stats={stats} />

      <div className="dashboard-grid">
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">📦 Фармоишҳои охирин</h2>
          </div>
          <RecentOrders orders={recentOrders.slice(0, 8)} />
        </div>

        <div className="card">
          <div className="card-header">
            <h2 className="card-title">📊 Хулоса</h2>
          </div>
          <div className="summary-list">
            {stats && (
              <>
                <div className="summary-item">
                  <span>Фармоишҳои фаъол</span>
                  <strong style={{ color: '#1a56db' }}>{stats.orders?.pending || 0}</strong>
                </div>
                <div className="summary-item">
                  <span>Курьерони онлайн</span>
                  <strong style={{ color: '#10b981' }}>{stats.couriers?.online || 0}</strong>
                </div>
                <div className="summary-item">
                  <span>Ҳамаи курьерон</span>
                  <strong>{stats.couriers?.total || 0}</strong>
                </div>
                <div className="summary-item">
                  <span>Ҳамаи муштариён</span>
                  <strong>{stats.clients?.total || 0}</strong>
                </div>
                <div className="summary-item">
                  <span>Даромади умумӣ</span>
                  <strong style={{ color: '#10b981' }}>{(stats.revenue?.total || 0).toFixed(2)} сомонӣ</strong>
                </div>
                <div className="summary-item">
                  <span>Расонидашуда</span>
                  <strong style={{ color: '#10b981' }}>{stats.orders?.delivered || 0}</strong>
                </div>
                <div className="summary-item">
                  <span>Бекоршуда</span>
                  <strong style={{ color: '#ef4444' }}>{stats.orders?.cancelled || 0}</strong>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

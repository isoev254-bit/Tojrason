import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { fetchOrders, cancelOrderAdmin } from '../store/slices/ordersSlice';
import { STATUS_LABELS, STATUS_BADGES } from '../utils/constants';
import toast from 'react-hot-toast';
import './OrdersPage.css';

const STATUSES = ['', 'pending', 'searching_courier', 'courier_assigned', 'courier_pickup', 'in_transit', 'delivered', 'cancelled', 'failed'];

export default function OrdersPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { list, total, totalPages, loading } = useSelector((s) => s.orders);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');

  useEffect(() => {
    dispatch(fetchOrders({ page, limit: 20, status: status || undefined }));
  }, [dispatch, page, status]);

  const handleCancel = async (e, id) => {
    e.stopPropagation();
    if (!window.confirm('Оё шумо мехоҳед ин фармоишро бекор кунед?')) return;
    const result = await dispatch(cancelOrderAdmin({ id, reason: 'Администратор бекор кард' }));
    if (!result.error) toast.success('Фармоиш бекор карда шуд');
    else toast.error('Хато рух дод');
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">📦 Фармоишҳо</h1>
        <span style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Ҳамаги: {total}</span>
      </div>

      <div className="card">
        <div className="orders-filters">
          <select className="form-control" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} style={{ maxWidth: 220 }}>
            <option value="">Ҳамаи ҳолатҳо</option>
            {STATUSES.filter(Boolean).map((s) => (
              <option key={s} value={s}>{STATUS_LABELS[s]}</option>
            ))}
          </select>
        </div>

        {loading ? (
          <div className="loading-spinner"><div className="spinner" /></div>
        ) : list.length === 0 ? (
          <div className="empty-state">📭<p>Фармоишҳо мавҷуд нестанд</p></div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table>
              <thead>
                <tr>
                  <th>№ Фармоиш</th>
                  <th>Муштарӣ</th>
                  <th>Курьер</th>
                  <th>Ҳолат</th>
                  <th>Нарх</th>
                  <th>Масофа</th>
                  <th>Вақт</th>
                  <th>Амал</th>
                </tr>
              </thead>
              <tbody>
                {list.map((order) => (
                  <tr key={order._id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/orders/${order._id}`)}>
                    <td><code style={{ fontSize: 12, background: '#f3f4f6', padding: '2px 6px', borderRadius: 4 }}>{order.orderNumber}</code></td>
                    <td>{order.client?.name || '—'}<br /><small style={{ color: 'var(--text-secondary)' }}>{order.client?.phone}</small></td>
                    <td>{order.courier?.name || <span style={{ color: '#9ca3af' }}>Таъин нашуд</span>}</td>
                    <td><span className={`badge ${STATUS_BADGES[order.status]}`}>{STATUS_LABELS[order.status]}</span></td>
                    <td><strong>{order.pricing?.total?.toFixed(2)} с.</strong></td>
                    <td>{order.distance?.toFixed(1)} км</td>
                    <td style={{ fontSize: 12, color: 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{new Date(order.createdAt).toLocaleString('ru')}</td>
                    <td onClick={(e) => e.stopPropagation()}>
                      {['pending', 'searching_courier', 'courier_assigned'].includes(order.status) && (
                        <button className="btn btn-danger btn-sm" onClick={(e) => handleCancel(e, order._id)}>Бекор</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="pagination">
          <button onClick={() => setPage(1)} disabled={page === 1}>«</button>
          <button onClick={() => setPage(p => p - 1)} disabled={page === 1}>‹</button>
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            const p = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
            return p <= totalPages ? (
              <button key={p} onClick={() => setPage(p)} className={page === p ? 'active' : ''}>{p}</button>
            ) : null;
          })}
          <button onClick={() => setPage(p => p + 1)} disabled={page === totalPages}>›</button>
          <button onClick={() => setPage(totalPages)} disabled={page === totalPages}>»</button>
        </div>
      </div>
    </div>
  );
}

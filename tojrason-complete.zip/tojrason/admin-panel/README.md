# Tojrason Admin Panel

## Технология
- React.js 18
- Redux Toolkit
- Socket.io Client
- React Router v6

## Оғоз

```bash
cp .env.example .env
npm install
npm start
```

## Сохтмони истеҳсолӣ

```bash
npm run build
```

## Муҳити кор

```
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_SOCKET_URL=http://localhost:5000
REACT_APP_GOOGLE_MAPS_KEY=your_key
```

## Имконоти панел

- 📊 Дашборд бо омории зинда
- 📦 Идоракунии фармоишҳо
- 🛵 Идоракунии курьерон ва тасдиқи онҳо
- 👥 Идоракунии корбарон
- 🗺️ Харитаи зиндаи курьерон бо GPS

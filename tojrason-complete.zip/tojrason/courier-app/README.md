# Tojrason Courier App

## Технология
- React Native 0.73
- Redux Toolkit
- Socket.io (GPS ба вақти воқеӣ)
- React Native Maps (Google Maps)
- React Navigation

## Оғоз

```bash
cp .env.example .env
npm install

# Android
npm run android

# iOS
cd ios && pod install && cd ..
npm run ios
```

## Имконот
- 🔐 Ворид шудан ба ҳисоби курьер
- 🟢 Идоракунии ҳолати онлайн/офлайн
- 📦 Қабул/рад кардани фармоишҳо
- 🗺️ Пайгирии маршрут (Google Maps)
- 📡 Фиристодани мавқеияти GPS ба вақти воқеӣ
- 💰 Нишондиҳандаи даромад ва омор
- 📋 Таърихи фармоишҳо
- 👤 Идоракунии профил

import { AppRegistry } from 'react-native';
import { Provider } from 'react-redux';
import React from 'react';
import App from './src/App';
import { store } from './src/store';
import { name as appName } from './app.json';

function Root() {
  return <Provider store={store}><App /></Provider>;
}
AppRegistry.registerComponent(appName, () => Root);

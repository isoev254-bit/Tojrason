import React, { useEffect } from 'react';
import { StatusBar } from 'react-native';
import { useDispatch } from 'react-redux';
import { loadCourierUser } from './store/slices/authSlice';
import AppNavigator from './navigation/AppNavigator';
import { COLORS } from './utils/theme';

export default function App() {
  const dispatch = useDispatch();
  useEffect(() => { dispatch(loadCourierUser()); }, [dispatch]);
  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor={COLORS.white} />
      <AppNavigator />
    </>
  );
}

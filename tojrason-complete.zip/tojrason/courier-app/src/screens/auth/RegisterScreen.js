import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  SafeAreaView, KeyboardAvoidingView, Platform, ScrollView,
  ActivityIndicator, Alert,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { registerCourier, clearError } from '../../store/slices/authSlice';
import { COLORS } from '../../utils/theme';

const VEHICLES = [
  { key: 'motorcycle', label: '🛵 Мотосикл' },
  { key: 'bicycle', label: '🚲 Велосипед' },
  { key: 'car', label: '🚗 Мошин' },
  { key: 'van', label: '🚐 Фургон' },
  { key: 'on_foot', label: '🚶 Пиёда' },
];

export default function RegisterScreen({ navigation }) {
  const dispatch = useDispatch();
  const { loading } = useSelector((s) => s.auth);
  const [form, setForm] = useState({ name: '', phone: '', password: '', confirmPassword: '', vehicleType: 'motorcycle', vehicleNumber: '' });
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  const handleRegister = async () => {
    if (!form.name || !form.phone || !form.password) { Alert.alert('Хато', 'Ҳамаи майдонҳоро пур кунед'); return; }
    if (form.password !== form.confirmPassword) { Alert.alert('Хато', 'Рамзҳо мувофиқат намекунанд'); return; }
    if (form.password.length < 6) { Alert.alert('Хато', 'Рамз ҳадди аққал 6 рақам'); return; }
    const result = await dispatch(registerCourier({ name: form.name.trim(), phone: form.phone.trim(), password: form.password, vehicleType: form.vehicleType, vehicleNumber: form.vehicleNumber }));
    if (result.error) Alert.alert('Хато', result.payload || 'Ба қайд гирифтан мумкин нашуд');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Text style={styles.backText}>← Бозгашт</Text>
          </TouchableOpacity>
          <View style={styles.header}>
            <Text style={styles.title}>Ба қайд гиред</Text>
            <Text style={styles.subtitle}>Ҳисоби курьер эҷод кунед</Text>
          </View>

          <View style={styles.form}>
            {[
              { key: 'name', label: 'Ном ва насаб', placeholder: 'Номи пурраи шумо' },
              { key: 'phone', label: 'Рақами телефон', placeholder: '+992901234567', type: 'phone-pad' },
              { key: 'vehicleNumber', label: 'Рақами нақлиёт (ихтиёрӣ)', placeholder: 'масалан: ТД 123 АА' },
              { key: 'password', label: 'Рамз', placeholder: 'Ҳадди аққал 6 рақам', secure: true },
              { key: 'confirmPassword', label: 'Такрори рамз', placeholder: 'Рамзро дубора ворид кунед', secure: true },
            ].map(({ key, label, placeholder, type, secure }) => (
              <View key={key} style={styles.inputGroup}>
                <Text style={styles.label}>{label}</Text>
                <TextInput
                  style={styles.input} placeholder={placeholder}
                  placeholderTextColor={COLORS.textSecondary}
                  value={form[key]} onChangeText={set(key)}
                  keyboardType={type || 'default'} secureTextEntry={secure} autoCapitalize="none"
                />
              </View>
            ))}

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Навъи нақлиёт</Text>
              <View style={styles.vehicleGrid}>
                {VEHICLES.map((v) => (
                  <TouchableOpacity
                    key={v.key}
                    style={[styles.vehicleBtn, form.vehicleType === v.key && styles.vehicleBtnActive]}
                    onPress={() => set('vehicleType')(v.key)}
                  >
                    <Text style={[styles.vehicleLabel, form.vehicleType === v.key && styles.vehicleLabelActive]}>{v.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <TouchableOpacity style={styles.btn} onPress={handleRegister} disabled={loading} activeOpacity={0.85}>
              {loading ? <ActivityIndicator color={COLORS.white} /> : <Text style={styles.btnText}>Ба қайд гирифтан</Text>}
            </TouchableOpacity>
            <TouchableOpacity style={styles.linkBtn} onPress={() => { dispatch(clearError()); navigation.navigate('Login'); }}>
              <Text style={styles.linkText}>Ҳисоб доред? <Text style={{ color: COLORS.primary, fontWeight: '700' }}>Ворид шавед</Text></Text>
            </TouchableOpacity>
          </View>
          <View style={{ height: 32 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.white },
  container: { flexGrow: 1, padding: 24 },
  backBtn: { marginBottom: 16, marginTop: 8 },
  backText: { fontSize: 15, color: COLORS.primary, fontWeight: '600' },
  header: { marginBottom: 28 },
  title: { fontSize: 28, fontWeight: '800', color: COLORS.text, marginBottom: 6 },
  subtitle: { fontSize: 15, color: COLORS.textSecondary },
  form: { gap: 14 },
  inputGroup: { gap: 6 },
  label: { fontSize: 13, fontWeight: '600', color: COLORS.textSecondary },
  input: { borderWidth: 1, borderColor: COLORS.border, borderRadius: 10, padding: 13, fontSize: 15, color: COLORS.text, backgroundColor: COLORS.bg },
  vehicleGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  vehicleBtn: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.bg },
  vehicleBtnActive: { backgroundColor: '#fff7ed', borderColor: COLORS.primary },
  vehicleLabel: { fontSize: 13, color: COLORS.text },
  vehicleLabelActive: { color: COLORS.primary, fontWeight: '700' },
  btn: { backgroundColor: COLORS.primary, borderRadius: 12, padding: 15, alignItems: 'center', marginTop: 8 },
  btnText: { color: COLORS.white, fontSize: 16, fontWeight: '700' },
  linkBtn: { alignItems: 'center', marginTop: 8 },
  linkText: { fontSize: 14, color: COLORS.textSecondary },
});

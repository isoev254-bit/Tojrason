import React, { useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView, ScrollView, ActivityIndicator,
} from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { loadCourierProfile } from '../../store/slices/courierSlice';
import { fetchCourierOrders } from '../../store/slices/ordersSlice';
import { COLORS } from '../../utils/theme';

export default function EarningsScreen() {
  const dispatch = useDispatch();
  const { profile, loading } = useSelector((s) => s.courier);
  const { list } = useSelector((s) => s.orders);

  useEffect(() => {
    dispatch(loadCourierProfile());
    dispatch(fetchCourierOrders({ limit: 50 }));
  }, []);

  const deliveredOrders = list.filter((o) => o.status === 'delivered');
  const todayOrders = deliveredOrders.filter((o) => {
    const today = new Date();
    const orderDate = new Date(o.deliveredAt || o.updatedAt);
    return orderDate.toDateString() === today.toDateString();
  });
  const todayEarnings = todayOrders.reduce((sum, o) => sum + (o.pricing?.total || 0) * 0.8, 0);

  const thisWeekOrders = deliveredOrders.filter((o) => {
    const now = new Date();
    const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
    const orderDate = new Date(o.deliveredAt || o.updatedAt);
    return orderDate >= weekAgo;
  });
  const weekEarnings = thisWeekOrders.reduce((sum, o) => sum + (o.pricing?.total || 0) * 0.8, 0);

  if (loading && !profile) {
    return <View style={styles.loading}><ActivityIndicator size="large" color={COLORS.primary} /></View>;
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.title}>💰 Даромад</Text>
      </View>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Total earnings card */}
        <View style={styles.totalCard}>
          <Text style={styles.totalLabel}>Даромади умумӣ</Text>
          <Text style={styles.totalValue}>{(profile?.stats?.totalEarnings || 0).toFixed(2)}</Text>
          <Text style={styles.totalCurrency}>сомонӣ</Text>
          <View style={styles.totalMeta}>
            <Text style={styles.totalMetaText}>🏆 {profile?.stats?.completedDeliveries || 0} расониш</Text>
            {profile?.stats?.averageRating > 0 && (
              <Text style={styles.totalMetaText}>⭐ {profile.stats.averageRating.toFixed(1)} рейтинг</Text>
            )}
          </View>
        </View>

        {/* Period stats */}
        <View style={styles.periodGrid}>
          <View style={[styles.periodCard, { borderColor: COLORS.primary }]}>
            <Text style={styles.periodIcon}>📅</Text>
            <Text style={styles.periodLabel}>Имрӯз</Text>
            <Text style={[styles.periodValue, { color: COLORS.primary }]}>{todayEarnings.toFixed(2)} с.</Text>
            <Text style={styles.periodOrders}>{todayOrders.length} расониш</Text>
          </View>
          <View style={[styles.periodCard, { borderColor: COLORS.success }]}>
            <Text style={styles.periodIcon}>📆</Text>
            <Text style={styles.periodLabel}>Ин ҳафта</Text>
            <Text style={[styles.periodValue, { color: COLORS.success }]}>{weekEarnings.toFixed(2)} с.</Text>
            <Text style={styles.periodOrders}>{thisWeekOrders.length} расониш</Text>
          </View>
        </View>

        {/* Commission info */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>ℹ️ Маълумот дар бораи комиссия</Text>
          <Text style={styles.infoText}>Шумо 80% аз нархи ҳар расониш мегиред. Комиссияи хидматрасонӣ 20% мебошад.</Text>
        </View>

        {/* Recent delivered orders */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Расонишҳои охирин</Text>
          {deliveredOrders.slice(0, 10).map((order) => (
            <View key={order._id} style={styles.orderRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.orderNum}>{order.orderNumber}</Text>
                <Text style={styles.orderAddr} numberOfLines={1}>{order.delivery?.address}</Text>
                <Text style={styles.orderDate}>{new Date(order.deliveredAt || order.updatedAt).toLocaleDateString('ru')}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.orderEarning}>+{((order.pricing?.total || 0) * 0.8).toFixed(2)} с.</Text>
                <Text style={styles.orderTotal}>{(order.pricing?.total || 0).toFixed(2)} с.</Text>
              </View>
            </View>
          ))}
          {deliveredOrders.length === 0 && (
            <View style={styles.empty}>
              <Text style={styles.emptyIcon}>💸</Text>
              <Text style={styles.emptyText}>Ҳоло расониш нест</Text>
            </View>
          )}
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { padding: 20, paddingBottom: 12, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  title: { fontSize: 22, fontWeight: '800', color: COLORS.text },
  totalCard: { margin: 16, borderRadius: 20, padding: 28, alignItems: 'center', background: COLORS.primary, backgroundColor: COLORS.primary, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.35, shadowRadius: 12, elevation: 8 },
  totalLabel: { fontSize: 14, color: 'rgba(255,255,255,0.8)', marginBottom: 6 },
  totalValue: { fontSize: 48, fontWeight: '900', color: COLORS.white, lineHeight: 52 },
  totalCurrency: { fontSize: 16, color: 'rgba(255,255,255,0.8)', marginBottom: 16 },
  totalMeta: { flexDirection: 'row', gap: 16 },
  totalMetaText: { fontSize: 14, color: 'rgba(255,255,255,0.9)', fontWeight: '600' },
  periodGrid: { flexDirection: 'row', marginHorizontal: 16, gap: 12, marginBottom: 16 },
  periodCard: { flex: 1, backgroundColor: COLORS.white, borderRadius: 14, padding: 16, alignItems: 'center', borderWidth: 2, gap: 4 },
  periodIcon: { fontSize: 24 },
  periodLabel: { fontSize: 12, color: COLORS.textSecondary, fontWeight: '600' },
  periodValue: { fontSize: 20, fontWeight: '800' },
  periodOrders: { fontSize: 11, color: COLORS.textSecondary },
  infoCard: { marginHorizontal: 16, marginBottom: 16, backgroundColor: '#eff6ff', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: '#bfdbfe' },
  infoTitle: { fontSize: 13, fontWeight: '700', color: '#1e40af', marginBottom: 4 },
  infoText: { fontSize: 12, color: '#1e40af', lineHeight: 18 },
  section: { marginHorizontal: 16 },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: COLORS.text, marginBottom: 12 },
  orderRow: { flexDirection: 'row', backgroundColor: COLORS.white, borderRadius: 12, padding: 14, marginBottom: 8, borderWidth: 1, borderColor: COLORS.border },
  orderNum: { fontSize: 11, fontWeight: '700', color: COLORS.textSecondary, marginBottom: 2 },
  orderAddr: { fontSize: 13, color: COLORS.text, fontWeight: '500', marginBottom: 2 },
  orderDate: { fontSize: 11, color: COLORS.textSecondary },
  orderEarning: { fontSize: 16, fontWeight: '800', color: COLORS.success },
  orderTotal: { fontSize: 11, color: COLORS.textSecondary, marginTop: 2 },
  empty: { alignItems: 'center', paddingVertical: 40 },
  emptyIcon: { fontSize: 40, marginBottom: 8 },
  emptyText: { fontSize: 14, color: COLORS.textSecondary },
});

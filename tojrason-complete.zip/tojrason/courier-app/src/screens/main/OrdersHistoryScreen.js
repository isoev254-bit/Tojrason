import React, { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  FlatList, ActivityIndicator, Platform,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCourierOrders } from '../../store/slices/ordersSlice';
import { COLORS, STATUS_LABELS, STATUS_COLORS } from '../../utils/theme';

export default function OrdersHistoryScreen({ navigation }) {
  const dispatch = useDispatch();
  const { list, total, loading } = useSelector((s) => s.orders);
  const [page, setPage] = useState(1);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { dispatch(fetchCourierOrders({ page: 1, limit: 20 })); }, []);

  const loadMore = () => {
    if (list.length < total && !loading) {
      const np = page + 1;
      setPage(np);
      dispatch(fetchCourierOrders({ page: np, limit: 20 }));
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await dispatch(fetchCourierOrders({ page: 1, limit: 20 }));
    setPage(1);
    setRefreshing(false);
  };

  const renderItem = ({ item }) => {
    const sc = STATUS_COLORS[item.status] || COLORS.textSecondary;
    const isActive = ['courier_assigned','courier_pickup','in_transit'].includes(item.status);
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => isActive ? navigation.navigate('ActiveOrder', { orderId: item._id }) : null}
        activeOpacity={isActive ? 0.85 : 1}
      >
        <View style={styles.cardTop}>
          <Text style={styles.orderNum}>{item.orderNumber}</Text>
          <View style={[styles.badge, { backgroundColor: sc + '20' }]}>
            <Text style={[styles.badgeText, { color: sc }]}>{STATUS_LABELS[item.status]}</Text>
          </View>
        </View>
        <View style={styles.addrRow}>
          <Text style={styles.addrDot}>📦</Text>
          <Text style={styles.addrText} numberOfLines={1}>{item.pickup?.address}</Text>
        </View>
        <View style={styles.addrRow}>
          <Text style={styles.addrDot}>🏠</Text>
          <Text style={styles.addrText} numberOfLines={1}>{item.delivery?.address}</Text>
        </View>
        <View style={styles.cardBottom}>
          <Text style={styles.earnings}>+{(item.pricing?.total * 0.8)?.toFixed(2)} сомонӣ</Text>
          <Text style={styles.date}>{new Date(item.createdAt).toLocaleDateString('ru')}</Text>
        </View>
        {isActive && <View style={styles.activePill}><Text style={styles.activePillText}>Фаъол — зер кунед →</Text></View>}
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.title}>Фармоишҳои ман</Text>
        <Text style={styles.total}>Ҳамаги: {total}</Text>
      </View>
      <FlatList
        data={list}
        keyExtractor={(i) => i._id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        onEndReached={loadMore}
        onEndReachedThreshold={0.3}
        refreshing={refreshing}
        onRefresh={onRefresh}
        ListEmptyComponent={
          loading
            ? <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 60 }} />
            : <View style={styles.empty}><Text style={styles.emptyIcon}>📭</Text><Text style={styles.emptyTitle}>Фармоишҳо нестанд</Text></View>
        }
        ListFooterComponent={loading && list.length > 0 ? <ActivityIndicator color={COLORS.primary} style={{ padding: 16 }} /> : null}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  header: { padding: 20, paddingBottom: 12, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title: { fontSize: 22, fontWeight: '800', color: COLORS.text },
  total: { fontSize: 13, color: COLORS.textSecondary },
  list: { padding: 16, gap: 12, flexGrow: 1 },
  card: { backgroundColor: COLORS.white, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: COLORS.border, gap: 8 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderNum: { fontSize: 12, fontWeight: '700', color: COLORS.textSecondary, fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
  badge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 20 },
  badgeText: { fontSize: 11, fontWeight: '700' },
  addrRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  addrDot: { fontSize: 13 },
  addrText: { flex: 1, fontSize: 13, color: COLORS.textSecondary },
  cardBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  earnings: { fontSize: 16, fontWeight: '800', color: COLORS.success },
  date: { fontSize: 12, color: COLORS.textSecondary },
  activePill: { backgroundColor: '#fff7ed', borderRadius: 8, padding: 8, alignItems: 'center' },
  activePillText: { color: COLORS.primary, fontWeight: '700', fontSize: 12 },
  empty: { flex: 1, alignItems: 'center', paddingTop: 80 },
  emptyIcon: { fontSize: 56, marginBottom: 12 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: COLORS.textSecondary },
});

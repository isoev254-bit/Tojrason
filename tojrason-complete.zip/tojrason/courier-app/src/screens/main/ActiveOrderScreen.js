import React, { useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  Alert, Linking, ScrollView, Platform,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { fetchOrderById, updateStatusAction } from '../../store/slices/ordersSlice';
import { connectSocket, joinOrderRoom } from '../../services/socket';
import { COLORS, STATUS_LABELS, STATUS_COLORS, NEXT_STATUS } from '../../utils/theme';

export default function ActiveOrderScreen({ navigation, route }) {
  const dispatch = useDispatch();
  const { orderId } = route.params;
  const { currentOrder } = useSelector((s) => s.orders);
  const { currentLocation } = useSelector((s) => s.courier);
  const mapRef = useRef(null);

  useEffect(() => {
    dispatch(fetchOrderById(orderId));
    setupSocket();
    const interval = setInterval(() => dispatch(fetchOrderById(orderId)), 10000);
    return () => clearInterval(interval);
  }, [orderId]);

  const setupSocket = async () => {
    const socket = await connectSocket();
    if (socket) joinOrderRoom(orderId);
  };

  const handleUpdateStatus = async (newStatus) => {
    const labels = {
      courier_pickup: 'Оё ба суроғаи гирифтан расидед?',
      in_transit: 'Оё бастаро гирифтед?',
      delivered: 'Оё бастаро расонидед?',
    };
    Alert.alert('Тасдиқ', labels[newStatus] || 'Ҳолатро иваз кунед?', [
      { text: 'Не', style: 'cancel' },
      {
        text: 'Ҳа', onPress: async () => {
          const result = await dispatch(updateStatusAction({ id: orderId, status: newStatus }));
          if (!result.error) {
            if (newStatus === 'delivered') {
              Alert.alert('🎉 Ташаккур!', 'Фармоиш бомуваффақият расонида шуд!', [
                { text: 'Хуб', onPress: () => navigation.goBack() },
              ]);
            }
          } else {
            Alert.alert('Хато', result.payload || 'Ҳолат иваз нашуд');
          }
        },
      },
    ]);
  };

  const callClient = () => {
    const phone = currentOrder?.client?.phone;
    if (phone) Linking.openURL(`tel:${phone}`);
  };

  const openMaps = (lat, lng, label) => {
    const scheme = Platform.OS === 'ios' ? 'maps:' : 'geo:';
    const url = Platform.OS === 'ios'
      ? `maps:?daddr=${lat},${lng}&q=${label}`
      : `geo:${lat},${lng}?q=${lat},${lng}(${label})`;
    Linking.openURL(url).catch(() => {
      Linking.openURL(`https://maps.google.com/maps?daddr=${lat},${lng}`);
    });
  };

  if (!currentOrder) return (
    <SafeAreaView style={styles.safe}>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ fontSize: 16, color: COLORS.textSecondary }}>Фармоиш бор мешавад...</Text>
      </View>
    </SafeAreaView>
  );

  const pickup = currentOrder.pickup?.coordinates;
  const delivery = currentOrder.delivery?.coordinates;
  const nextStatus = NEXT_STATUS[currentOrder.status];
  const statusColor = STATUS_COLORS[currentOrder.status] || COLORS.primary;

  const mapRegion = (pickup || currentLocation) ? {
    latitude: (pickup?.lat || currentLocation?.lat) || 38.5598,
    longitude: (pickup?.lng || currentLocation?.lng) || 68.7737,
    latitudeDelta: 0.04,
    longitudeDelta: 0.04,
  } : { latitude: 38.5598, longitude: 68.7737, latitudeDelta: 0.04, longitudeDelta: 0.04 };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.topTitle}>Фармоиши фаъол</Text>
        <Text style={styles.orderNum}>{currentOrder.orderNumber}</Text>
      </View>

      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={mapRegion}
        showsUserLocation
        showsMyLocationButton
      >
        {pickup && (
          <Marker coordinate={{ latitude: pickup.lat, longitude: pickup.lng }} title="Гирифтан">
            <View style={[styles.marker, { backgroundColor: COLORS.primary }]}>
              <Text style={styles.markerText}>📦</Text>
            </View>
          </Marker>
        )}
        {delivery && (
          <Marker coordinate={{ latitude: delivery.lat, longitude: delivery.lng }} title="Расондан">
            <View style={[styles.marker, { backgroundColor: COLORS.success }]}>
              <Text style={styles.markerText}>🏠</Text>
            </View>
          </Marker>
        )}
        {pickup && delivery && (
          <Polyline
            coordinates={[
              { latitude: pickup.lat, longitude: pickup.lng },
              { latitude: delivery.lat, longitude: delivery.lng },
            ]}
            strokeColor={statusColor}
            strokeWidth={3}
            lineDashPattern={[10, 5]}
          />
        )}
      </MapView>

      <ScrollView style={styles.sheet}>
        {/* Status */}
        <View style={[styles.statusBar, { borderLeftColor: statusColor }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>{STATUS_LABELS[currentOrder.status]}</Text>
          <Text style={styles.statusSub}>{currentOrder.distance?.toFixed(1)} км · {currentOrder.estimatedDuration} дақ.</Text>
        </View>

        {/* Client info */}
        <View style={styles.clientRow}>
          <View style={styles.clientAvatar}>
            <Text style={styles.clientAvatarText}>{currentOrder.client?.name?.[0]?.toUpperCase()}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.clientName}>{currentOrder.client?.name}</Text>
            <Text style={styles.clientLabel}>Муштарӣ</Text>
          </View>
          <TouchableOpacity style={styles.callBtn} onPress={callClient}>
            <Text style={styles.callBtnText}>📞 Занг</Text>
          </TouchableOpacity>
        </View>

        {/* Addresses with navigation */}
        <View style={styles.addrCard}>
          <TouchableOpacity style={styles.addrItem} onPress={() => pickup && openMaps(pickup.lat, pickup.lng, 'Гирифтан')} activeOpacity={0.7}>
            <View style={[styles.addrDot, { backgroundColor: COLORS.primary }]} />
            <View style={{ flex: 1 }}>
              <Text style={styles.addrLabel}>📦 Гирифтан</Text>
              <Text style={styles.addrText}>{currentOrder.pickup?.address}</Text>
              {currentOrder.pickup?.contactPhone && <Text style={styles.addrPhone}>📞 {currentOrder.pickup.contactPhone}</Text>}
            </View>
            <Text style={styles.navArrow}>🗺️</Text>
          </TouchableOpacity>

          <View style={styles.addrDivider} />

          <TouchableOpacity style={styles.addrItem} onPress={() => delivery && openMaps(delivery.lat, delivery.lng, 'Расондан')} activeOpacity={0.7}>
            <View style={[styles.addrDot, { backgroundColor: COLORS.success }]} />
            <View style={{ flex: 1 }}>
              <Text style={styles.addrLabel}>🏠 Расондан</Text>
              <Text style={styles.addrText}>{currentOrder.delivery?.address}</Text>
              {currentOrder.delivery?.contactPhone && <Text style={styles.addrPhone}>📞 {currentOrder.delivery.contactPhone}</Text>}
            </View>
            <Text style={styles.navArrow}>🗺️</Text>
          </TouchableOpacity>
        </View>

        {/* Package info */}
        <View style={styles.pkgCard}>
          <Text style={styles.pkgTitle}>📦 {currentOrder.packageDetails?.description}</Text>
          <View style={styles.pkgMeta}>
            <Text style={styles.pkgMetaItem}>⚖️ {currentOrder.packageDetails?.weight} кг</Text>
            {currentOrder.packageDetails?.fragile && <Text style={[styles.pkgMetaItem, { color: COLORS.danger }]}>⚠️ Шикастанӣ</Text>}
            <Text style={styles.pkgMetaItem}>💰 {currentOrder.pricing?.total?.toFixed(2)} сомонӣ</Text>
          </View>
        </View>

        {/* Next status button */}
        {nextStatus && (
          <TouchableOpacity
            style={[styles.nextStatusBtn, { backgroundColor: nextStatus.color }]}
            onPress={() => handleUpdateStatus(nextStatus.status)}
            activeOpacity={0.85}
          >
            <Text style={styles.nextStatusText}>{nextStatus.label}</Text>
          </TouchableOpacity>
        )}

        <View style={{ height: 24 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.white },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  backText: { fontSize: 22, color: COLORS.primary, fontWeight: '600' },
  topTitle: { fontSize: 16, fontWeight: '700', color: COLORS.text },
  orderNum: { fontSize: 11, color: COLORS.textSecondary, fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace' },
  map: { height: 250 },
  marker: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.25, shadowRadius: 4, elevation: 4 },
  markerText: { fontSize: 18 },
  sheet: { flex: 1, backgroundColor: COLORS.bg },
  statusBar: { margin: 12, marginBottom: 0, backgroundColor: COLORS.white, borderRadius: 12, padding: 14, borderLeftWidth: 4, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  statusText: { fontSize: 16, fontWeight: '800' },
  statusSub: { fontSize: 13, color: COLORS.textSecondary },
  clientRow: { flexDirection: 'row', alignItems: 'center', gap: 12, margin: 12, marginBottom: 0, backgroundColor: COLORS.white, borderRadius: 12, padding: 14, borderWidth: 1, borderColor: COLORS.border },
  clientAvatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center' },
  clientAvatarText: { color: COLORS.white, fontWeight: '800', fontSize: 18 },
  clientName: { fontSize: 15, fontWeight: '700', color: COLORS.text },
  clientLabel: { fontSize: 12, color: COLORS.textSecondary },
  callBtn: { backgroundColor: '#fff7ed', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  callBtnText: { color: COLORS.primary, fontWeight: '700', fontSize: 13 },
  addrCard: { margin: 12, marginBottom: 0, backgroundColor: COLORS.white, borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden' },
  addrItem: { flexDirection: 'row', gap: 10, padding: 14, alignItems: 'center' },
  addrDivider: { height: 1, backgroundColor: COLORS.border, marginLeft: 14 },
  addrDot: { width: 12, height: 12, borderRadius: 6, flexShrink: 0 },
  addrLabel: { fontSize: 11, color: COLORS.textSecondary, marginBottom: 3 },
  addrText: { fontSize: 14, fontWeight: '600', color: COLORS.text },
  addrPhone: { fontSize: 12, color: COLORS.primary, marginTop: 2 },
  navArrow: { fontSize: 20 },
  pkgCard: { margin: 12, marginBottom: 0, backgroundColor: COLORS.white, borderRadius: 12, padding: 14, borderWidth: 1, borderColor: COLORS.border },
  pkgTitle: { fontSize: 15, fontWeight: '700', color: COLORS.text, marginBottom: 8 },
  pkgMeta: { flexDirection: 'row', gap: 12, flexWrap: 'wrap' },
  pkgMetaItem: { fontSize: 13, color: COLORS.textSecondary, fontWeight: '500' },
  nextStatusBtn: { margin: 12, borderRadius: 14, padding: 18, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 8, elevation: 4 },
  nextStatusText: { color: COLORS.white, fontSize: 17, fontWeight: '800' },
});

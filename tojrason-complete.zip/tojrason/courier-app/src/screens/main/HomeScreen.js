import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  ScrollView, Alert, Modal, Animated, Vibration, AppState,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import Geolocation from '@react-native-community/geolocation';
import { setOnline, setAvailable, loadCourierProfile, setIncomingOffer, clearIncomingOffer, setCurrentLocation } from '../../store/slices/courierSlice';
import { acceptOrderAction, rejectOrderAction, fetchOrderById } from '../../store/slices/ordersSlice';
import { connectSocket, onEvent, offEvent, emitLocationUpdate } from '../../services/socket';
import { COLORS, STATUS_LABELS } from '../../utils/theme';

export default function HomeScreen({ navigation }) {
  const dispatch = useDispatch();
  const { isOnline, isAvailable, profile, incomingOffer } = useSelector((s) => s.courier);
  const { currentOrder } = useSelector((s) => s.orders);
  const { user } = useSelector((s) => s.auth);
  const locationWatchId = useRef(null);
  const offerTimerRef = useRef(null);
  const [offerCountdown, setOfferCountdown] = useState(30);
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    dispatch(loadCourierProfile());
    setupSocket();
    return () => {
      clearInterval(offerTimerRef.current);
      if (locationWatchId.current !== null) Geolocation.clearWatch(locationWatchId.current);
    };
  }, []);

  useEffect(() => {
    if (isOnline) startLocationTracking();
    else {
      if (locationWatchId.current !== null) { Geolocation.clearWatch(locationWatchId.current); locationWatchId.current = null; }
    }
  }, [isOnline]);

  useEffect(() => {
    if (incomingOffer) {
      Vibration.vibrate([0, 400, 200, 400, 200, 400]);
      startPulse();
      let count = 30;
      setOfferCountdown(count);
      clearInterval(offerTimerRef.current);
      offerTimerRef.current = setInterval(() => {
        count -= 1;
        setOfferCountdown(count);
        if (count <= 0) {
          clearInterval(offerTimerRef.current);
          dispatch(clearIncomingOffer());
        }
      }, 1000);
    } else {
      clearInterval(offerTimerRef.current);
      pulseAnim.stopAnimation();
    }
  }, [incomingOffer]);

  const startPulse = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.05, duration: 500, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
      ])
    ).start();
  };

  const setupSocket = async () => {
    const socket = await connectSocket();
    if (!socket) return;

    const handleOffer = (data) => { dispatch(setIncomingOffer(data)); };
    const handleCancelled = () => {
      dispatch(clearIncomingOffer());
      if (currentOrder) dispatch(fetchOrderById(currentOrder._id));
    };

    onEvent('order:new_offer', handleOffer);
    onEvent('order:cancelled', handleCancelled);
    return () => { offEvent('order:new_offer', handleOffer); offEvent('order:cancelled', handleCancelled); };
  };

  const startLocationTracking = () => {
    if (locationWatchId.current !== null) return;
    locationWatchId.current = Geolocation.watchPosition(
      (pos) => {
        const { latitude: lat, longitude: lng } = pos.coords;
        dispatch(setCurrentLocation({ lat, lng }));
        emitLocationUpdate(lat, lng, currentOrder?._id || null);
      },
      (err) => console.warn('Location error:', err),
      { enableHighAccuracy: true, distanceFilter: 20, interval: 5000 }
    );
  };

  const handleToggleOnline = async () => {
    const newStatus = !isOnline;
    const result = await dispatch(setOnline(newStatus));
    if (result.error) Alert.alert('Хато', result.payload || 'Амал иҷро нашуд');
  };

  const handleAcceptOffer = async () => {
    if (!incomingOffer?.orderId) return;
    clearInterval(offerTimerRef.current);
    const result = await dispatch(acceptOrderAction(incomingOffer.orderId));
    dispatch(clearIncomingOffer());
    if (!result.error) {
      navigation.navigate('ActiveOrder', { orderId: result.payload._id });
    } else {
      Alert.alert('Хато', result.payload || 'Фармоиш қабул нашуд');
    }
  };

  const handleRejectOffer = async () => {
    if (!incomingOffer?.orderId) return;
    clearInterval(offerTimerRef.current);
    await dispatch(rejectOrderAction(incomingOffer.orderId));
    dispatch(clearIncomingOffer());
  };

  const goToActiveOrder = () => {
    if (currentOrder?._id) navigation.navigate('ActiveOrder', { orderId: currentOrder._id });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Салом,</Text>
            <Text style={styles.name}>{user?.name} 👋</Text>
          </View>
          <View style={[styles.verifyBadge, { backgroundColor: profile?.verificationStatus === 'verified' ? '#d1fae5' : '#fef3c7' }]}>
            <Text style={{ fontSize: 12, fontWeight: '700', color: profile?.verificationStatus === 'verified' ? '#065f46' : '#92400e' }}>
              {profile?.verificationStatus === 'verified' ? '✅ Тасдиқ' : '⏳ Тасдиқ нашуд'}
            </Text>
          </View>
        </View>

        {/* Online toggle */}
        <View style={styles.onlineCard}>
          <View>
            <Text style={styles.onlineTitle}>{isOnline ? '🟢 Онлайн' : '🔴 Офлайн'}</Text>
            <Text style={styles.onlineSubtitle}>{isOnline ? 'Фармоишҳо қабул мешавад' : 'Ба фармоиш дастрас нестед'}</Text>
          </View>
          <TouchableOpacity
            style={[styles.toggleBtn, isOnline ? styles.toggleOff : styles.toggleOn]}
            onPress={handleToggleOnline}
            activeOpacity={0.85}
          >
            <Text style={styles.toggleText}>{isOnline ? 'Офлайн шудан' : 'Онлайн шудан'}</Text>
          </TouchableOpacity>
        </View>

        {/* Active order banner */}
        {currentOrder && !['delivered', 'cancelled', 'failed'].includes(currentOrder.status) && (
          <TouchableOpacity style={styles.activeOrderBanner} onPress={goToActiveOrder} activeOpacity={0.85}>
            <View>
              <Text style={styles.activeOrderTitle}>📦 Фармоиши фаъол</Text>
              <Text style={styles.activeOrderNum}>{currentOrder.orderNumber}</Text>
              <Text style={styles.activeOrderStatus}>{STATUS_LABELS[currentOrder.status]}</Text>
            </View>
            <Text style={styles.activeOrderArrow}>→</Text>
          </TouchableOpacity>
        )}

        {/* Stats */}
        <View style={styles.statsRow}>
          {[
            { label: 'Расонишҳо', value: profile?.stats?.completedDeliveries || 0, icon: '✅' },
            { label: 'Рейтинг', value: profile?.stats?.averageRating > 0 ? profile?.stats?.averageRating?.toFixed(1) : '—', icon: '⭐' },
            { label: 'Даромад', value: `${(profile?.stats?.totalEarnings || 0).toFixed(0)} с.`, icon: '💰' },
          ].map((s) => (
            <View key={s.label} style={styles.statCard}>
              <Text style={styles.statIcon}>{s.icon}</Text>
              <Text style={styles.statValue}>{s.value}</Text>
              <Text style={styles.statLabel}>{s.label}</Text>
            </View>
          ))}
        </View>

        {/* Tips */}
        <View style={styles.tipsCard}>
          <Text style={styles.tipsTitle}>💡 Маслиҳатҳо</Text>
          {[
            'Ҳангоми гирифтани баста ҳуввияти муштариро тасдиқ кунед',
            'Дар вақти расондан бо муштарӣ тамос гиред',
            'Бастаи шикастанӣро бо эҳтиёт нигоҳ доред',
          ].map((tip, i) => (
            <Text key={i} style={styles.tipItem}>• {tip}</Text>
          ))}
        </View>
      </ScrollView>

      {/* Incoming offer modal */}
      <Modal visible={!!incomingOffer} transparent animationType="slide">
        <View style={styles.offerOverlay}>
          <Animated.View style={[styles.offerCard, { transform: [{ scale: pulseAnim }] }]}>
            <View style={styles.offerHeader}>
              <Text style={styles.offerTitle}>🔔 Фармоиши нав!</Text>
              <View style={styles.countdown}>
                <Text style={styles.countdownText}>{offerCountdown}</Text>
              </View>
            </View>

            <View style={styles.offerRouteCard}>
              <View style={styles.offerRouteItem}>
                <View style={[styles.routeDot, { backgroundColor: COLORS.primary }]} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.routeLabel}>Гирифтан</Text>
                  <Text style={styles.routeAddr} numberOfLines={2}>{incomingOffer?.pickup?.address}</Text>
                </View>
              </View>
              <View style={styles.routeLine} />
              <View style={styles.offerRouteItem}>
                <View style={[styles.routeDot, { backgroundColor: COLORS.success }]} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.routeLabel}>Расондан</Text>
                  <Text style={styles.routeAddr} numberOfLines={2}>{incomingOffer?.delivery?.address}</Text>
                </View>
              </View>
            </View>

            <View style={styles.offerMeta}>
              <View style={styles.offerMetaItem}>
                <Text style={styles.offerMetaLabel}>💰 Нарх</Text>
                <Text style={styles.offerMetaValue}>{incomingOffer?.pricing?.total?.toFixed(2)} сомонӣ</Text>
              </View>
              <View style={styles.offerMetaItem}>
                <Text style={styles.offerMetaLabel}>📏 Масофа</Text>
                <Text style={styles.offerMetaValue}>{incomingOffer?.distance?.toFixed(1)} км</Text>
              </View>
              <View style={styles.offerMetaItem}>
                <Text style={styles.offerMetaLabel}>📦 Баста</Text>
                <Text style={styles.offerMetaValue} numberOfLines={1}>{incomingOffer?.packageDetails?.description}</Text>
              </View>
            </View>

            <View style={styles.offerButtons}>
              <TouchableOpacity style={styles.rejectBtn} onPress={handleRejectOffer} activeOpacity={0.85}>
                <Text style={styles.rejectBtnText}>✕ Рад кардан</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.acceptBtn} onPress={handleAcceptOffer} activeOpacity={0.85}>
                <Text style={styles.acceptBtnText}>✓ Қабул кардан</Text>
              </TouchableOpacity>
            </View>
          </Animated.View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 20, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  greeting: { fontSize: 14, color: COLORS.textSecondary },
  name: { fontSize: 20, fontWeight: '800', color: COLORS.text },
  verifyBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20 },
  onlineCard: { margin: 16, backgroundColor: COLORS.white, borderRadius: 16, padding: 20, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderWidth: 1, borderColor: COLORS.border, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 8, elevation: 3 },
  onlineTitle: { fontSize: 18, fontWeight: '800', color: COLORS.text, marginBottom: 4 },
  onlineSubtitle: { fontSize: 13, color: COLORS.textSecondary },
  toggleBtn: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 25 },
  toggleOn: { backgroundColor: COLORS.primary },
  toggleOff: { backgroundColor: '#fee2e2' },
  toggleText: { fontWeight: '700', fontSize: 14, color: COLORS.white },
  activeOrderBanner: { marginHorizontal: 16, marginBottom: 16, backgroundColor: COLORS.primary, borderRadius: 14, padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  activeOrderTitle: { fontSize: 13, color: 'rgba(255,255,255,0.8)', marginBottom: 2 },
  activeOrderNum: { fontSize: 14, fontWeight: '700', color: COLORS.white, fontFamily: 'monospace' },
  activeOrderStatus: { fontSize: 13, color: 'rgba(255,255,255,0.9)', marginTop: 2 },
  activeOrderArrow: { fontSize: 22, color: COLORS.white },
  statsRow: { flexDirection: 'row', marginHorizontal: 16, gap: 10, marginBottom: 16 },
  statCard: { flex: 1, backgroundColor: COLORS.white, borderRadius: 14, padding: 14, alignItems: 'center', borderWidth: 1, borderColor: COLORS.border },
  statIcon: { fontSize: 22, marginBottom: 4 },
  statValue: { fontSize: 18, fontWeight: '800', color: COLORS.text },
  statLabel: { fontSize: 11, color: COLORS.textSecondary, textAlign: 'center', marginTop: 2 },
  tipsCard: { marginHorizontal: 16, backgroundColor: '#eff6ff', borderRadius: 14, padding: 16, borderWidth: 1, borderColor: '#bfdbfe', marginBottom: 24 },
  tipsTitle: { fontSize: 14, fontWeight: '700', color: '#1e40af', marginBottom: 10 },
  tipItem: { fontSize: 13, color: '#1e40af', marginBottom: 6, lineHeight: 20 },
  offerOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  offerCard: { backgroundColor: COLORS.white, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, paddingBottom: 36 },
  offerHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  offerTitle: { fontSize: 22, fontWeight: '800', color: COLORS.text },
  countdown: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#fef3c7', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: COLORS.warning },
  countdownText: { fontSize: 16, fontWeight: '800', color: COLORS.warning },
  offerRouteCard: { backgroundColor: COLORS.bg, borderRadius: 14, padding: 16, marginBottom: 16 },
  offerRouteItem: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  routeDot: { width: 12, height: 12, borderRadius: 6, marginTop: 4, flexShrink: 0 },
  routeLine: { width: 2, height: 12, backgroundColor: COLORS.border, marginLeft: 5, marginVertical: 4 },
  routeLabel: { fontSize: 11, color: COLORS.textSecondary, marginBottom: 2 },
  routeAddr: { fontSize: 14, fontWeight: '600', color: COLORS.text },
  offerMeta: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  offerMetaItem: { flex: 1, backgroundColor: COLORS.bg, borderRadius: 10, padding: 10, alignItems: 'center' },
  offerMetaLabel: { fontSize: 11, color: COLORS.textSecondary, marginBottom: 4 },
  offerMetaValue: { fontSize: 13, fontWeight: '700', color: COLORS.text, textAlign: 'center' },
  offerButtons: { flexDirection: 'row', gap: 12 },
  rejectBtn: { flex: 1, backgroundColor: '#fef2f2', borderRadius: 14, padding: 16, alignItems: 'center', borderWidth: 1, borderColor: '#fca5a5' },
  rejectBtnText: { color: COLORS.danger, fontWeight: '800', fontSize: 15 },
  acceptBtn: { flex: 1.5, backgroundColor: COLORS.success, borderRadius: 14, padding: 16, alignItems: 'center', shadowColor: COLORS.success, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 },
  acceptBtnText: { color: COLORS.white, fontWeight: '800', fontSize: 15 },
});

import React, { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, SafeAreaView,
  ScrollView, Alert, Switch, ActivityIndicator,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { logoutCourier } from '../../store/slices/authSlice';
import { loadCourierProfile, setOnline, setAvailable } from '../../store/slices/courierSlice';
import { COLORS } from '../../utils/theme';
import { VEHICLE_LABELS } from '../../utils/constants';

export default function ProfileScreen() {
  const dispatch = useDispatch();
  const { user } = useSelector((s) => s.auth);
  const { profile, isOnline, isAvailable, loading } = useSelector((s) => s.courier);

  useEffect(() => { dispatch(loadCourierProfile()); }, []);

  const toggleOnline = async () => {
    const res = await dispatch(setOnline(!isOnline));
    if (res.error) Alert.alert('Хато', res.payload || 'Хато рух дод');
  };

  const toggleAvailable = async () => {
    if (!isOnline) { Alert.alert('Огоҳӣ', 'Аввал онлайн шавед'); return; }
    const res = await dispatch(setAvailable(!isAvailable));
    if (res.error) Alert.alert('Хато', res.payload || 'Хато рух дод');
  };

  const handleLogout = () => {
    Alert.alert('Хуруҷ', 'Оё мехоҳед аз ҳисоб хориҷ шавед?', [
      { text: 'Не', style: 'cancel' },
      { text: 'Ҳа', style: 'destructive', onPress: () => dispatch(logoutCourier()) },
    ]);
  };

  const MenuItem = ({ icon, label, onPress, right, danger }) => (
    <TouchableOpacity style={styles.menuItem} onPress={onPress} activeOpacity={0.7}>
      <Text style={styles.menuIcon}>{icon}</Text>
      <Text style={[styles.menuLabel, danger && { color: COLORS.danger }]}>{label}</Text>
      {right !== undefined ? right : <Text style={styles.menuArrow}>›</Text>}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.profileHeader}>
          <View style={[styles.avatar, { backgroundColor: isOnline ? COLORS.success : COLORS.textSecondary }]}>
            <Text style={styles.avatarText}>{user?.name?.[0]?.toUpperCase()}</Text>
          </View>
          <View style={[styles.onlineDot, { backgroundColor: isOnline ? COLORS.success : COLORS.textSecondary }]} />
          <Text style={styles.userName}>{user?.name}</Text>
          <Text style={styles.userPhone}>{user?.phone}</Text>
          {profile && (
            <View style={styles.vehicleBadge}>
              <Text style={styles.vehicleText}>{VEHICLE_LABELS[profile.vehicleType] || profile.vehicleType}</Text>
            </View>
          )}
          {profile?.verificationStatus === 'pending' && (
            <View style={styles.verifyWarning}>
              <Text style={styles.verifyText}>⏳ Ҳисоби шумо дар ҳоли тасдиқ аст</Text>
            </View>
          )}
          {profile?.verificationStatus === 'verified' && (
            <View style={styles.verifySuccess}>
              <Text style={styles.verifySuccessText}>✅ Тасдиқ шудааст</Text>
            </View>
          )}
        </View>

        {/* Stats */}
        {profile && (
          <View style={styles.statsRow}>
            {[
              { label: 'Расонишҳо', value: profile.stats?.completedDeliveries || 0, icon: '✅' },
              { label: 'Рейтинг', value: profile.stats?.averageRating > 0 ? `${profile.stats.averageRating}⭐` : '—', icon: '⭐' },
              { label: 'Даромад', value: `${(profile.stats?.totalEarnings || 0).toFixed(0)}с`, icon: '💰' },
            ].map((item) => (
              <View key={item.label} style={styles.statItem}>
                <Text style={styles.statIcon}>{item.icon}</Text>
                <Text style={styles.statValue}>{item.value}</Text>
                <Text style={styles.statLabel}>{item.label}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Status controls */}
        <View style={styles.menuSection}>
          <Text style={styles.sectionTitle}>Ҳолати кор</Text>
          <View style={styles.menuCard}>
            <MenuItem
              icon={isOnline ? '🟢' : '⚫'}
              label={isOnline ? 'Онлайн' : 'Офлайн'}
              right={
                loading
                  ? <ActivityIndicator size="small" color={COLORS.primary} />
                  : <Switch value={isOnline} onValueChange={toggleOnline} trackColor={{ true: COLORS.success }} />
              }
            />
            <View style={styles.divider} />
            <MenuItem
              icon={isAvailable ? '🆓' : '📦'}
              label={isAvailable ? 'Озодам' : 'Бандам'}
              right={
                <Switch
                  value={isAvailable}
                  onValueChange={toggleAvailable}
                  disabled={!isOnline}
                  trackColor={{ true: COLORS.primary }}
                />
              }
            />
          </View>
        </View>

        {/* Account */}
        <View style={styles.menuSection}>
          <Text style={styles.sectionTitle}>Ҳисоб</Text>
          <View style={styles.menuCard}>
            <MenuItem icon="👤" label="Таҳрири профил" onPress={() => Alert.alert('Ба зудӣ')} />
            <View style={styles.divider} />
            <MenuItem icon="🚗" label="Маълумоти нақлиёт" onPress={() => Alert.alert('Ба зудӣ')} />
            <View style={styles.divider} />
            <MenuItem icon="🏦" label="Маълумоти бонкӣ" onPress={() => Alert.alert('Ба зудӣ')} />
            <View style={styles.divider} />
            <MenuItem icon="🔒" label="Иваз кардани рамз" onPress={() => Alert.alert('Ба зудӣ')} />
          </View>
        </View>

        {/* Support */}
        <View style={styles.menuSection}>
          <Text style={styles.sectionTitle}>Дигар</Text>
          <View style={styles.menuCard}>
            <MenuItem icon="❓" label="Ёрдам" onPress={() => Alert.alert('Дастгирӣ', '+992901234567')} />
            <View style={styles.divider} />
            <MenuItem icon="📋" label="Қоидаҳо" onPress={() => Alert.alert('Ба зудӣ')} />
          </View>
        </View>

        <View style={styles.menuSection}>
          <View style={styles.menuCard}>
            <MenuItem icon="🚪" label="Хуруҷ аз ҳисоб" onPress={handleLogout} danger right={null} />
          </View>
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  profileHeader: { backgroundColor: COLORS.white, alignItems: 'center', paddingVertical: 28, paddingHorizontal: 20, borderBottomWidth: 1, borderBottomColor: COLORS.border, position: 'relative' },
  avatar: { width: 80, height: 80, borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  avatarText: { fontSize: 34, fontWeight: '800', color: COLORS.white },
  onlineDot: { position: 'absolute', top: 48, left: '50%', marginLeft: 22, width: 18, height: 18, borderRadius: 9, borderWidth: 2, borderColor: COLORS.white },
  userName: { fontSize: 20, fontWeight: '800', color: COLORS.text, marginBottom: 2 },
  userPhone: { fontSize: 14, color: COLORS.textSecondary, marginBottom: 10 },
  vehicleBadge: { backgroundColor: COLORS.primaryLight, paddingHorizontal: 14, paddingVertical: 5, borderRadius: 20, marginBottom: 8 },
  vehicleText: { fontSize: 13, color: COLORS.primary, fontWeight: '700' },
  verifyWarning: { backgroundColor: '#fef3c7', paddingHorizontal: 14, paddingVertical: 6, borderRadius: 10, marginTop: 4 },
  verifyText: { fontSize: 12, color: '#92400e', fontWeight: '600' },
  verifySuccess: { backgroundColor: '#d1fae5', paddingHorizontal: 14, paddingVertical: 6, borderRadius: 10, marginTop: 4 },
  verifySuccessText: { fontSize: 12, color: '#065f46', fontWeight: '600' },
  statsRow: { flexDirection: 'row', backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border, padding: 16 },
  statItem: { flex: 1, alignItems: 'center', gap: 2 },
  statIcon: { fontSize: 20 },
  statValue: { fontSize: 18, fontWeight: '800', color: COLORS.text },
  statLabel: { fontSize: 11, color: COLORS.textSecondary, textAlign: 'center' },
  menuSection: { marginHorizontal: 16, marginTop: 20 },
  sectionTitle: { fontSize: 11, fontWeight: '700', color: COLORS.textSecondary, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8, paddingHorizontal: 4 },
  menuCard: { backgroundColor: COLORS.white, borderRadius: 14, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 15, gap: 12 },
  menuIcon: { fontSize: 20, width: 28, textAlign: 'center' },
  menuLabel: { flex: 1, fontSize: 15, color: COLORS.text, fontWeight: '500' },
  menuArrow: { fontSize: 20, color: COLORS.textSecondary },
  divider: { height: 1, backgroundColor: COLORS.border, marginLeft: 56 },
});

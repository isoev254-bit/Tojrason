import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = process.env.API_URL || 'http://10.0.2.2:5000/api';

const api = axios.create({
  baseURL: API_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('accessToken');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && error.response?.data?.code === 'TOKEN_EXPIRED' && !original._retry) {
      original._retry = true;
      try {
        const refreshToken = await AsyncStorage.getItem('refreshToken');
        const { data } = await axios.post(`${API_URL}/auth/refresh`, { refreshToken });
        await AsyncStorage.setItem('accessToken', data.data.accessToken);
        await AsyncStorage.setItem('refreshToken', data.data.refreshToken);
        original.headers.Authorization = `Bearer ${data.data.accessToken}`;
        return api(original);
      } catch {
        await AsyncStorage.multiRemove(['accessToken', 'refreshToken']);
      }
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  login: (d) => api.post('/auth/login', d),
  register: (d) => api.post('/auth/register', d),
  logout: (d) => api.post('/auth/logout', d),
  getProfile: () => api.get('/auth/profile'),
};

export const courierAPI = {
  getProfile: () => api.get('/couriers/me'),
  setOnline: (isOnline) => api.put('/couriers/me/online', { isOnline }),
  setAvailable: (isAvailable) => api.put('/couriers/me/availability', { isAvailable }),
  updateLocation: (lat, lng) => api.put('/couriers/me/location', { lat, lng }),
  getStats: () => api.get('/couriers/me/stats'),
};

export const ordersAPI = {
  getMyCourier: (params) => api.get('/orders/courier/my', { params }),
  getById: (id) => api.get(`/orders/${id}`),
  accept: (id) => api.post(`/orders/${id}/accept`),
  reject: (id) => api.post(`/orders/${id}/reject`),
  updateStatus: (id, status) => api.patch(`/orders/${id}/status`, { status }),
};

export default api;

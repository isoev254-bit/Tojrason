export const COLORS = {
  primary: '#f97316',
  primaryDark: '#ea580c',
  primaryLight: '#fff7ed',
  success: '#10b981',
  danger: '#ef4444',
  warning: '#f59e0b',
  bg: '#f9fafb',
  surface: '#ffffff',
  border: '#e5e7eb',
  text: '#111827',
  textSecondary: '#6b7280',
  white: '#ffffff',
  black: '#000000',
};

export const STATUS_LABELS = {
  pending: 'Интизор',
  searching_courier: 'Ҷустуҷӯ',
  courier_assigned: 'Таъин шуд',
  courier_pickup: 'Гирифтан',
  in_transit: 'Дар роҳ',
  delivered: 'Расонида шуд',
  cancelled: 'Бекор шуд',
  failed: 'Нокомёб',
};

export const STATUS_COLORS = {
  courier_assigned: '#8b5cf6',
  courier_pickup: '#f97316',
  in_transit: '#06b6d4',
  delivered: '#10b981',
  cancelled: '#ef4444',
};

export const NEXT_STATUS = {
  courier_assigned: { status: 'courier_pickup', label: '🚀 Рафтан барои гирифтан', color: '#f97316' },
  courier_pickup: { status: 'in_transit', label: '📦 Гирифтам, дар роҳам', color: '#06b6d4' },
  in_transit: { status: 'delivered', label: '✅ Расонидам', color: '#10b981' },
};

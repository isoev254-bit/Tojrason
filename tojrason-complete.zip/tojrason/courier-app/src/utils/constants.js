export const VEHICLE_LABELS = {
  bicycle: '🚲 Велосипед',
  motorcycle: '🛵 Мотосикл',
  car: '🚗 Мошин',
  van: '🚐 Фургон',
  on_foot: '🚶 Пиёда',
};

export const STATUS_LABELS = {
  pending: 'Интизор',
  searching_courier: 'Ҷустуҷӯи курьер',
  courier_assigned: 'Таъин шуд',
  courier_pickup: 'Гирифтан',
  in_transit: 'Дар роҳ',
  delivered: 'Расонида шуд',
  cancelled: 'Бекор шуд',
  failed: 'Нокомёб',
};

export const NEXT_STATUS = {
  courier_assigned: { status: 'courier_pickup', label: '🚀 Рафтам гирифтан', color: '#f97316' },
  courier_pickup:   { status: 'in_transit',     label: '📦 Гирифтам, дар роҳам', color: '#06b6d4' },
  in_transit:       { status: 'delivered',       label: '✅ Расонидам!', color: '#10b981' },
};

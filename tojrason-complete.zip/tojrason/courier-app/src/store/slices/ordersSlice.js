import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { ordersAPI } from '../../services/api';

export const fetchCourierOrders = createAsyncThunk('orders/fetchMy', async (params, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.getMyCourier(params);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const acceptOrderAction = createAsyncThunk('orders/accept', async (orderId, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.accept(orderId);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const rejectOrderAction = createAsyncThunk('orders/reject', async (orderId, { rejectWithValue }) => {
  try {
    await ordersAPI.reject(orderId);
    return orderId;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const updateStatusAction = createAsyncThunk('orders/updateStatus', async ({ id, status }, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.updateStatus(id, status);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const fetchOrderById = createAsyncThunk('orders/fetchById', async (id, { rejectWithValue }) => {
  try {
    const { data } = await ordersAPI.getById(id);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

const ordersSlice = createSlice({
  name: 'orders',
  initialState: {
    list: [],
    currentOrder: null,
    total: 0,
    loading: false,
    error: null,
  },
  reducers: {
    setCurrentOrder(state, action) { state.currentOrder = action.payload; },
    clearCurrentOrder(state) { state.currentOrder = null; },
  },
  extraReducers: (b) => {
    b
      .addCase(fetchCourierOrders.pending, (s) => { s.loading = true; })
      .addCase(fetchCourierOrders.fulfilled, (s, a) => { s.loading = false; s.list = a.payload.orders; s.total = a.payload.total; })
      .addCase(fetchCourierOrders.rejected, (s, a) => { s.loading = false; s.error = a.payload; })
      .addCase(acceptOrderAction.fulfilled, (s, a) => { s.currentOrder = a.payload; })
      .addCase(updateStatusAction.fulfilled, (s, a) => {
        s.currentOrder = a.payload;
        const idx = s.list.findIndex((o) => o._id === a.payload._id);
        if (idx !== -1) s.list[idx] = a.payload;
      })
      .addCase(fetchOrderById.fulfilled, (s, a) => { s.currentOrder = a.payload; });
  },
});

export const { setCurrentOrder, clearCurrentOrder } = ordersSlice.actions;
export default ordersSlice.reducer;

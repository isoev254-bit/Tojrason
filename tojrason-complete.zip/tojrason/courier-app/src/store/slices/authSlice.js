import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authAPI } from '../../services/api';

export const loginCourier = createAsyncThunk('auth/login', async (creds, { rejectWithValue }) => {
  try {
    const { data } = await authAPI.login(creds);
    if (data.data.user.role !== 'courier') throw new Error('Танҳо курьерон метавонанд ворид шаванд');
    await AsyncStorage.setItem('accessToken', data.data.accessToken);
    await AsyncStorage.setItem('refreshToken', data.data.refreshToken);
    return data.data.user;
  } catch (err) { return rejectWithValue(err.response?.data?.message || err.message); }
});

export const registerCourier = createAsyncThunk('auth/register', async (userData, { rejectWithValue }) => {
  try {
    const { data } = await authAPI.register({ ...userData, role: 'courier' });
    await AsyncStorage.setItem('accessToken', data.data.accessToken);
    await AsyncStorage.setItem('refreshToken', data.data.refreshToken);
    return data.data.user;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const loadCourierUser = createAsyncThunk('auth/load', async (_, { rejectWithValue }) => {
  try {
    const token = await AsyncStorage.getItem('accessToken');
    if (!token) throw new Error('no token');
    const { data } = await authAPI.getProfile();
    if (data.data.role !== 'courier') throw new Error('Not a courier');
    return data.data;
  } catch (err) {
    await AsyncStorage.multiRemove(['accessToken', 'refreshToken']);
    return rejectWithValue(err.message);
  }
});

export const logoutCourier = createAsyncThunk('auth/logout', async () => {
  try {
    const refreshToken = await AsyncStorage.getItem('refreshToken');
    await authAPI.logout({ refreshToken });
  } catch {}
  await AsyncStorage.multiRemove(['accessToken', 'refreshToken']);
});

const authSlice = createSlice({
  name: 'auth',
  initialState: { user: null, loading: false, error: null, initialized: false },
  reducers: { clearError: (s) => { s.error = null; } },
  extraReducers: (b) => {
    b
      .addCase(loginCourier.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(loginCourier.fulfilled, (s, a) => { s.loading = false; s.user = a.payload; s.initialized = true; })
      .addCase(loginCourier.rejected, (s, a) => { s.loading = false; s.error = a.payload; })
      .addCase(registerCourier.pending, (s) => { s.loading = true; })
      .addCase(registerCourier.fulfilled, (s, a) => { s.loading = false; s.user = a.payload; s.initialized = true; })
      .addCase(registerCourier.rejected, (s, a) => { s.loading = false; s.error = a.payload; })
      .addCase(loadCourierUser.pending, (s) => { s.loading = true; })
      .addCase(loadCourierUser.fulfilled, (s, a) => { s.loading = false; s.user = a.payload; s.initialized = true; })
      .addCase(loadCourierUser.rejected, (s) => { s.loading = false; s.user = null; s.initialized = true; })
      .addCase(logoutCourier.fulfilled, (s) => { s.user = null; });
  },
});
export const { clearError } = authSlice.actions;
export default authSlice.reducer;

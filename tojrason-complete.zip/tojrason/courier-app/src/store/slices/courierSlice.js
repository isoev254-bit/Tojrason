import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { courierAPI } from '../../services/api';

export const loadCourierProfile = createAsyncThunk('courier/loadProfile', async (_, { rejectWithValue }) => {
  try {
    const { data } = await courierAPI.getProfile();
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const setOnline = createAsyncThunk('courier/setOnline', async (isOnline, { rejectWithValue }) => {
  try {
    const { data } = await courierAPI.setOnline(isOnline);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const setAvailable = createAsyncThunk('courier/setAvailable', async (isAvailable, { rejectWithValue }) => {
  try {
    const { data } = await courierAPI.setAvailable(isAvailable);
    return data.data;
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

export const updateLocation = createAsyncThunk('courier/updateLocation', async ({ lat, lng }, { rejectWithValue }) => {
  try {
    await courierAPI.updateLocation(lat, lng);
    return { lat, lng };
  } catch (err) { return rejectWithValue(err.response?.data?.message); }
});

const courierSlice = createSlice({
  name: 'courier',
  initialState: {
    profile: null,
    isOnline: false,
    isAvailable: false,
    currentLocation: null,
    loading: false,
    error: null,
    incomingOffer: null,
  },
  reducers: {
    setIncomingOffer(state, action) { state.incomingOffer = action.payload; },
    clearIncomingOffer(state) { state.incomingOffer = null; },
    setCurrentLocation(state, action) { state.currentLocation = action.payload; },
  },
  extraReducers: (b) => {
    b
      .addCase(loadCourierProfile.pending, (s) => { s.loading = true; })
      .addCase(loadCourierProfile.fulfilled, (s, a) => {
        s.loading = false;
        s.profile = a.payload;
        s.isOnline = a.payload.isOnline;
        s.isAvailable = a.payload.isAvailable;
      })
      .addCase(loadCourierProfile.rejected, (s, a) => { s.loading = false; s.error = a.payload; })
      .addCase(setOnline.fulfilled, (s, a) => { s.isOnline = a.payload.isOnline; s.isAvailable = a.payload.isAvailable; })
      .addCase(setAvailable.fulfilled, (s, a) => { s.isAvailable = a.payload.isAvailable; })
      .addCase(updateLocation.fulfilled, (s, a) => { s.currentLocation = a.payload; });
  },
});

export const { setIncomingOffer, clearIncomingOffer, setCurrentLocation } = courierSlice.actions;
export default courierSlice.reducer;

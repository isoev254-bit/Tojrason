import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import courierReducer from './slices/courierSlice';
import ordersReducer from './slices/ordersSlice';

export const store = configureStore({
  reducer: { auth: authReducer, courier: courierReducer, orders: ordersReducer },
  middleware: (m) => m({ serializableCheck: false }),
});

const authService = require('../services/authService');
const logger = require('../utils/logger');

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const register = asyncHandler(async (req, res) => {
  const result = await authService.register(req.body);
  res.status(201).json({ success: true, message: 'Бомуваффақият ба қайд гирифта шудед', data: result });
});

const login = asyncHandler(async (req, res) => {
  const { phone, password } = req.body;
  const result = await authService.login(phone, password);
  res.json({ success: true, message: 'Бомуваффақият ворид шудед', data: result });
});

const refreshToken = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ success: false, message: 'Токени навсозӣ талаб карда мешавад' });
  const tokens = await authService.refreshTokens(refreshToken);
  res.json({ success: true, data: tokens });
});

const logout = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  await authService.logout(req.user._id, refreshToken);
  res.json({ success: true, message: 'Бомуваффақият хориҷ шудед' });
});

const getProfile = asyncHandler(async (req, res) => {
  const user = await authService.getProfile(req.user._id);
  res.json({ success: true, data: user });
});

const updateProfile = asyncHandler(async (req, res) => {
  const { name, email, address, fcmToken } = req.body;
  const User = require('../models/User');
  const user = await User.findByIdAndUpdate(
    req.user._id,
    { $set: { name, email, address, fcmToken } },
    { new: true, runValidators: true }
  ).select('-password -refreshTokens');
  res.json({ success: true, message: 'Профил навсозӣ шуд', data: user });
});

module.exports = { register, login, refreshToken, logout, getProfile, updateProfile };

const courierService = require('../services/courierService');

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const getMyProfile = asyncHandler(async (req, res) => {
  const courier = await courierService.getCourierProfile(req.user._id);
  res.json({ success: true, data: courier });
});

const setOnlineStatus = asyncHandler(async (req, res) => {
  const { isOnline } = req.body;
  if (typeof isOnline !== 'boolean') {
    return res.status(400).json({ success: false, message: 'isOnline бояд boolean бошад' });
  }
  const courier = await courierService.updateOnlineStatus(req.user._id, isOnline);
  res.json({
    success: true,
    message: isOnline ? 'Шумо онлайн ҳастед' : 'Шумо офлайн ҳастед',
    data: courier,
  });
});

const setAvailability = asyncHandler(async (req, res) => {
  const { isAvailable } = req.body;
  const courier = await courierService.updateAvailability(req.user._id, isAvailable);
  res.json({ success: true, data: courier });
});

const updateLocation = asyncHandler(async (req, res) => {
  const { lat, lng } = req.body;
  const result = await courierService.updateLocation(req.user._id, lat, lng);
  res.json({ success: true, data: result });
});

const getMyStats = asyncHandler(async (req, res) => {
  const stats = await courierService.getCourierStats(req.user._id);
  res.json({ success: true, data: stats });
});

const getAllCouriers = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, isOnline, verificationStatus, vehicleType } = req.query;
  const filters = {};
  if (isOnline !== undefined) filters.isOnline = isOnline === 'true';
  if (verificationStatus) filters.verificationStatus = verificationStatus;
  if (vehicleType) filters.vehicleType = vehicleType;
  const result = await courierService.getAllCouriers(parseInt(page), parseInt(limit), filters);
  res.json({ success: true, data: result });
});

const verifyCourier = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['verified', 'rejected'].includes(status)) {
    return res.status(400).json({ success: false, message: 'Ҳолати нодуруст' });
  }
  const courier = await courierService.verifyCourier(req.params.id, status, req.user._id);
  res.json({ success: true, message: 'Ҳолати курьер навсозӣ шуд', data: courier });
});

const getOnlineCouriers = asyncHandler(async (req, res) => {
  const couriers = await courierService.getOnlineCouriers();
  res.json({ success: true, data: couriers });
});

module.exports = {
  getMyProfile, setOnlineStatus, setAvailability, updateLocation,
  getMyStats, getAllCouriers, verifyCourier, getOnlineCouriers,
};

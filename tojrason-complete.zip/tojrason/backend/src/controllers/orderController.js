const orderService = require('../services/orderService');
const dispatchService = require('../services/dispatchService');

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const createOrder = asyncHandler(async (req, res) => {
  const order = await orderService.createOrder(req.user._id, req.body);
  res.status(201).json({ success: true, message: 'Фармоиш бомуваффақият сохта шуд', data: order });
});

const getMyOrders = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, status } = req.query;
  const result = await orderService.getClientOrders(req.user._id, parseInt(page), parseInt(limit), status);
  res.json({ success: true, data: result });
});

const getOrderById = asyncHandler(async (req, res) => {
  const order = await orderService.getOrderById(req.params.id, req.user._id, req.user.role);
  res.json({ success: true, data: order });
});

const cancelOrder = asyncHandler(async (req, res) => {
  const order = await orderService.cancelOrder(req.params.id, req.user._id, req.user.role, req.body.reason);
  res.json({ success: true, message: 'Фармоиш бекор карда шуд', data: order });
});

const rateOrder = asyncHandler(async (req, res) => {
  const { score, comment } = req.body;
  const order = await orderService.rateOrder(req.params.id, req.user._id, score, comment);
  res.json({ success: true, message: 'Ташаккур барои баҳогузорӣ!', data: order });
});

const estimateFare = asyncHandler(async (req, res) => {
  const { pickupLat, pickupLng, deliveryLat, deliveryLng } = req.query;
  if (!pickupLat || !pickupLng || !deliveryLat || !deliveryLng) {
    return res.status(400).json({ success: false, message: 'Координатҳо талаб карда мешаванд' });
  }
  const result = await orderService.estimateFare(
    { lat: parseFloat(pickupLat), lng: parseFloat(pickupLng) },
    { lat: parseFloat(deliveryLat), lng: parseFloat(deliveryLng) }
  );
  res.json({ success: true, data: result });
});

const getAllOrders = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, status, startDate, endDate } = req.query;
  const result = await orderService.getAllOrders(parseInt(page), parseInt(limit), { status, startDate, endDate });
  res.json({ success: true, data: result });
});

const updateOrderStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  const order = await orderService.updateOrderStatus(req.params.id, req.user._id, status);
  res.json({ success: true, message: 'Ҳолати фармоиш навсозӣ шуд', data: order });
});

const acceptOrder = asyncHandler(async (req, res) => {
  const order = await dispatchService.acceptOrder(req.params.id, req.user._id);
  res.json({ success: true, message: 'Фармоиш қабул карда шуд', data: order });
});

const rejectOrder = asyncHandler(async (req, res) => {
  await dispatchService.rejectOrder(req.params.id, req.user._id);
  res.json({ success: true, message: 'Фармоиш рад карда шуд' });
});

const getCourierOrders = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const result = await orderService.getCourierOrders(req.user._id, parseInt(page), parseInt(limit));
  res.json({ success: true, data: result });
});

const getAdminStats = asyncHandler(async (req, res) => {
  const Order = require('../models/Order');
  const Courier = require('../models/Courier');
  const User = require('../models/User');

  const [
    totalOrders, pendingOrders, deliveredOrders, cancelledOrders,
    totalCouriers, onlineCouriers, totalClients, revenueData
  ] = await Promise.all([
    Order.countDocuments(),
    Order.countDocuments({ status: { $in: ['pending', 'searching_courier', 'courier_assigned', 'courier_pickup', 'in_transit'] } }),
    Order.countDocuments({ status: 'delivered' }),
    Order.countDocuments({ status: 'cancelled' }),
    Courier.countDocuments(),
    Courier.countDocuments({ isOnline: true }),
    User.countDocuments({ role: 'client' }),
    Order.aggregate([
      { $match: { status: 'delivered' } },
      { $group: { _id: null, total: { $sum: '$pricing.total' } } },
    ]),
  ]);

  res.json({
    success: true,
    data: {
      orders: { total: totalOrders, pending: pendingOrders, delivered: deliveredOrders, cancelled: cancelledOrders },
      couriers: { total: totalCouriers, online: onlineCouriers },
      clients: { total: totalClients },
      revenue: { total: revenueData[0]?.total || 0, currency: 'TJS' },
    },
  });
});

module.exports = {
  createOrder, getMyOrders, getOrderById, cancelOrder, rateOrder,
  estimateFare, getAllOrders, updateOrderStatus, acceptOrder,
  rejectOrder, getCourierOrders, getAdminStats,
};

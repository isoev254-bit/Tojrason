const User = require('../models/User');
const { AppError } = require('../middleware/errorHandler');

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const getAllUsers = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, role, search } = req.query;
  const query = {};
  if (role) query.role = role;
  if (search) {
    query.$or = [
      { name: { $regex: search, $options: 'i' } },
      { phone: { $regex: search, $options: 'i' } },
    ];
  }

  const [users, total] = await Promise.all([
    User.find(query)
      .select('-password -refreshTokens')
      .sort({ createdAt: -1 })
      .skip((page - 1) * parseInt(limit))
      .limit(parseInt(limit)),
    User.countDocuments(query),
  ]);

  res.json({ success: true, data: { users, total, page: parseInt(page), totalPages: Math.ceil(total / parseInt(limit)) } });
});

const getUserById = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id).select('-password -refreshTokens');
  if (!user) throw new AppError('Корбар ёфт нашуд', 404);
  res.json({ success: true, data: user });
});

const updateUser = asyncHandler(async (req, res) => {
  const { name, email, isActive, role } = req.body;
  const updates = {};
  if (name) updates.name = name;
  if (email) updates.email = email;
  if (isActive !== undefined) updates.isActive = isActive;
  if (role && req.user.role === 'admin') updates.role = role;

  const user = await User.findByIdAndUpdate(
    req.params.id,
    { $set: updates },
    { new: true, runValidators: true }
  ).select('-password -refreshTokens');

  if (!user) throw new AppError('Корбар ёфт нашуд', 404);
  res.json({ success: true, message: 'Корбар навсозӣ шуд', data: user });
});

const deactivateUser = asyncHandler(async (req, res) => {
  const user = await User.findByIdAndUpdate(
    req.params.id,
    { $set: { isActive: false } },
    { new: true }
  ).select('-password -refreshTokens');
  if (!user) throw new AppError('Корбар ёфт нашуд', 404);
  res.json({ success: true, message: 'Корбар ғайрифаъол карда шуд', data: user });
});

module.exports = { getAllUsers, getUserById, updateUser, deactivateUser };

const EARTH_RADIUS_KM = 6371;

function toRadians(degrees) {
  return degrees * (Math.PI / 180);
}

function haversineDistance(lat1, lng1, lat2, lng2) {
  const dLat = toRadians(lat2 - lat1);
  const dLng = toRadians(lng2 - lng1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) *
    Math.cos(toRadians(lat2)) *
    Math.sin(dLng / 2) *
    Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_KM * c;
}

function estimateDuration(distanceKm, vehicleType = 'motorcycle') {
  const speeds = {
    on_foot: 5,
    bicycle: 15,
    motorcycle: 30,
    car: 25,
    van: 20,
  };
  const speedKmh = speeds[vehicleType] || 25;
  const trafficFactor = 1.3;
  return Math.ceil((distanceKm / speedKmh) * 60 * trafficFactor);
}

function findNearestPoints(origin, points, maxDistanceKm = 10) {
  return points
    .map((point) => ({
      ...point,
      distance: haversineDistance(
        origin.lat, origin.lng,
        point.lat, point.lng
      ),
    }))
    .filter((p) => p.distance <= maxDistanceKm)
    .sort((a, b) => a.distance - b.distance);
}

module.exports = { haversineDistance, estimateDuration, findNearestPoints };

const express = require('express');
const router = express.Router();
const {
  createOrder, getMyOrders, getOrderById, cancelOrder, rateOrder,
  estimateFare, getAllOrders, updateOrderStatus, acceptOrder,
  rejectOrder, getCourierOrders, getAdminStats,
} = require('../controllers/orderController');
const { authenticate, authorize } = require('../middleware/auth');
const { validate, schemas } = require('../middleware/validate');

router.use(authenticate);

router.get('/estimate', estimateFare);

// Client routes
router.post('/', authorize('client'), validate(schemas.createOrder), createOrder);
router.get('/my', authorize('client'), getMyOrders);
router.post('/:id/rate', authorize('client'), validate(schemas.rateOrder), rateOrder);

// Courier routes
router.get('/courier/my', authorize('courier'), getCourierOrders);
router.post('/:id/accept', authorize('courier'), acceptOrder);
router.post('/:id/reject', authorize('courier'), rejectOrder);
router.patch('/:id/status', authorize('courier'), updateOrderStatus);

// Admin routes
router.get('/stats', authorize('admin'), getAdminStats);
router.get('/', authorize('admin'), getAllOrders);

// Shared
router.get('/:id', getOrderById);
router.post('/:id/cancel', cancelOrder);

module.exports = router;

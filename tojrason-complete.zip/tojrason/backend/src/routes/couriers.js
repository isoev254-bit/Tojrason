const express = require('express');
const router = express.Router();
const {
  getMyProfile, setOnlineStatus, setAvailability, updateLocation,
  getMyStats, getAllCouriers, verifyCourier, getOnlineCouriers,
} = require('../controllers/courierController');
const { authenticate, authorize } = require('../middleware/auth');
const { validate, schemas } = require('../middleware/validate');

router.use(authenticate);

// Courier self-management
router.get('/me', authorize('courier'), getMyProfile);
router.put('/me/online', authorize('courier'), setOnlineStatus);
router.put('/me/availability', authorize('courier'), setAvailability);
router.put('/me/location', authorize('courier'), validate(schemas.updateLocation), updateLocation);
router.get('/me/stats', authorize('courier'), getMyStats);

// Admin routes
router.get('/', authorize('admin'), getAllCouriers);
router.get('/online', authorize('admin', 'client'), getOnlineCouriers);
router.put('/:id/verify', authorize('admin'), verifyCourier);

module.exports = router;

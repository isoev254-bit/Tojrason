const Joi = require('joi');

const validate = (schema, property = 'body') => (req, res, next) => {
  const { error, value } = schema.validate(req[property], { abortEarly: false, stripUnknown: true });
  if (error) {
    const messages = error.details.map((d) => d.message).join(', ');
    return res.status(400).json({ success: false, message: messages });
  }
  req[property] = value;
  next();
};

const schemas = {
  register: Joi.object({
    name: Joi.string().min(2).max(50).required().messages({
      'string.min': 'Ном бояд ҳадди аққал 2 ҳарф дошта бошад',
      'string.max': 'Ном бояд ҳадди аксар 50 ҳарф дошта бошад',
      'any.required': 'Ном талаб карда мешавад',
    }),
    phone: Joi.string().pattern(/^\+?[1-9]\d{8,14}$/).required().messages({
      'string.pattern.base': 'Рақами телефон нодуруст аст',
      'any.required': 'Рақами телефон талаб карда мешавад',
    }),
    password: Joi.string().min(6).required().messages({
      'string.min': 'Рамз бояд ҳадди аққал 6 рақам дошта бошад',
      'any.required': 'Рамз талаб карда мешавад',
    }),
    email: Joi.string().email().optional(),
    role: Joi.string().valid('client', 'courier').default('client'),
  }),

  login: Joi.object({
    phone: Joi.string().required().messages({ 'any.required': 'Рақами телефон талаб карда мешавад' }),
    password: Joi.string().required().messages({ 'any.required': 'Рамз талаб карда мешавад' }),
  }),

  createOrder: Joi.object({
    pickup: Joi.object({
      address: Joi.string().required().messages({ 'any.required': 'Суроғаи гирифтан талаб карда мешавад' }),
      coordinates: Joi.object({
        lat: Joi.number().min(-90).max(90).required(),
        lng: Joi.number().min(-180).max(180).required(),
      }).required(),
      contactName: Joi.string().optional(),
      contactPhone: Joi.string().optional(),
      notes: Joi.string().optional(),
    }).required(),
    delivery: Joi.object({
      address: Joi.string().required().messages({ 'any.required': 'Суроғаи расондан талаб карда мешавад' }),
      coordinates: Joi.object({
        lat: Joi.number().min(-90).max(90).required(),
        lng: Joi.number().min(-180).max(180).required(),
      }).required(),
      contactName: Joi.string().optional(),
      contactPhone: Joi.string().optional(),
      notes: Joi.string().optional(),
    }).required(),
    packageDetails: Joi.object({
      description: Joi.string().required().messages({ 'any.required': 'Тавсифи бастаи талаб карда мешавад' }),
      weight: Joi.number().min(0.1).max(50).default(1),
      fragile: Joi.boolean().default(false),
      category: Joi.string().valid('document', 'package', 'food', 'electronics', 'clothing', 'other').default('other'),
    }).required(),
    paymentMethod: Joi.string().valid('cash', 'card', 'wallet').default('cash'),
    scheduledAt: Joi.date().min('now').optional(),
  }),

  updateLocation: Joi.object({
    lat: Joi.number().min(-90).max(90).required(),
    lng: Joi.number().min(-180).max(180).required(),
  }),

  rateOrder: Joi.object({
    score: Joi.number().min(1).max(5).required().messages({
      'any.required': 'Баҳогузорӣ талаб карда мешавад',
      'number.min': 'Баҳо бояд аз 1 то 5 бошад',
      'number.max': 'Баҳо бояд аз 1 то 5 бошад',
    }),
    comment: Joi.string().max(500).optional(),
  }),
};

module.exports = { validate, schemas };

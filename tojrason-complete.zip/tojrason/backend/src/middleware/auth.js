const { verifyAccessToken } = require('../utils/jwt');
const User = require('../models/User');
const logger = require('../utils/logger');

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Дастрасӣ рад карда шуд. Токен мавҷуд нест.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = verifyAccessToken(token);

    const user = await User.findById(decoded.id).select('-password -refreshTokens');
    if (!user) {
      return res.status(401).json({ success: false, message: 'Корбар ёфт нашуд' });
    }

    if (!user.isActive) {
      return res.status(403).json({ success: false, message: 'Ҳисоби корбар ғайрифаъол аст' });
    }

    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, message: 'Токен мӯҳлаташ гузашт', code: 'TOKEN_EXPIRED' });
    }
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ success: false, message: 'Токен нодуруст аст' });
    }
    logger.error('Auth middleware error:', error);
    next(error);
  }
};

const authorize = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) {
    return res.status(403).json({
      success: false,
      message: `Ин амал барои нақши '${req.user.role}' иҷозат дода намешавад`,
    });
  }
  next();
};

const optionalAuth = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) return next();
  try {
    const token = authHeader.split(' ')[1];
    const decoded = verifyAccessToken(token);
    req.user = await User.findById(decoded.id).select('-password -refreshTokens');
  } catch {}
  next();
};

module.exports = { authenticate, authorize, optionalAuth };

const User = require('../models/User');
const Courier = require('../models/Courier');
const { generateTokenPair, verifyRefreshToken } = require('../utils/jwt');
const { AppError } = require('../middleware/errorHandler');
const logger = require('../utils/logger');

class AuthService {
  async register(data) {
    const existingUser = await User.findOne({ phone: data.phone });
    if (existingUser) throw new AppError('Ин рақами телефон аллакай ба қайд гирифта шудааст', 409);

    const user = await User.create(data);

    if (data.role === 'courier') {
      await Courier.create({
        user: user._id,
        vehicleType: data.vehicleType || 'motorcycle',
        vehicleNumber: data.vehicleNumber || '',
      });
    }

    const { accessToken, refreshToken, expiresAt } = generateTokenPair(user);
    user.refreshTokens.push({ token: refreshToken, expiresAt });
    user.lastLogin = new Date();
    await user.save({ validateBeforeSave: false });

    logger.info(`New user registered: ${user.phone}, role: ${user.role}`);
    return { user: user.toSafeObject(), accessToken, refreshToken };
  }

  async login(phone, password) {
    const user = await User.findOne({ phone }).select('+password');
    if (!user) throw new AppError('Рақами телефон ё рамз нодуруст аст', 401);

    const isPasswordCorrect = await user.comparePassword(password);
    if (!isPasswordCorrect) throw new AppError('Рақами телефон ё рамз нодуруст аст', 401);

    if (!user.isActive) throw new AppError('Ҳисоби шумо ғайрифаъол карда шудааст', 403);

    const { accessToken, refreshToken, expiresAt } = generateTokenPair(user);

    user.refreshTokens = user.refreshTokens.filter((t) => t.expiresAt > new Date());
    if (user.refreshTokens.length >= 5) user.refreshTokens.shift();
    user.refreshTokens.push({ token: refreshToken, expiresAt });
    user.lastLogin = new Date();
    await user.save({ validateBeforeSave: false });

    logger.info(`User logged in: ${user.phone}`);
    return { user: user.toSafeObject(), accessToken, refreshToken };
  }

  async refreshTokens(refreshToken) {
    let decoded;
    try {
      decoded = verifyRefreshToken(refreshToken);
    } catch {
      throw new AppError('Токени навсозии нодуруст ё мӯҳлаташ гузашт', 401);
    }

    const user = await User.findById(decoded.id).select('+refreshTokens');
    if (!user) throw new AppError('Корбар ёфт нашуд', 401);

    const tokenIndex = user.refreshTokens.findIndex((t) => t.token === refreshToken);
    if (tokenIndex === -1) throw new AppError('Токени навсозии нодуруст', 401);

    const { accessToken, refreshToken: newRefreshToken, expiresAt } = generateTokenPair(user);
    user.refreshTokens.splice(tokenIndex, 1);
    user.refreshTokens.push({ token: newRefreshToken, expiresAt });
    await user.save({ validateBeforeSave: false });

    return { accessToken, refreshToken: newRefreshToken };
  }

  async logout(userId, refreshToken) {
    const user = await User.findById(userId).select('+refreshTokens');
    if (!user) return;
    user.refreshTokens = user.refreshTokens.filter((t) => t.token !== refreshToken);
    await user.save({ validateBeforeSave: false });
  }

  async getProfile(userId) {
    const user = await User.findById(userId).select('-password -refreshTokens');
    if (!user) throw new AppError('Корбар ёфт нашуд', 404);
    return user;
  }
}

module.exports = new AuthService();

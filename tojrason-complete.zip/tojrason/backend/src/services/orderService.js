const Order = require('../models/Order');
const Courier = require('../models/Courier');
const pricingService = require('./pricingService');
const dispatchService = require('./dispatchService');
const { haversineDistance, estimateDuration } = require('../utils/haversine');
const { emitToUser, emitToOrder, emitToAdmins } = require('../config/socket');
const { AppError } = require('../middleware/errorHandler');
const logger = require('../utils/logger');

class OrderService {
  async createOrder(clientId, data) {
    const { pickup, delivery, packageDetails, paymentMethod, scheduledAt } = data;

    const distanceKm = haversineDistance(
      pickup.coordinates.lat, pickup.coordinates.lng,
      delivery.coordinates.lat, delivery.coordinates.lng
    );

    const pricing = pricingService.calculate({
      distanceKm,
      weightKg: packageDetails.weight || 1,
      fragile: packageDetails.fragile || false,
      scheduledAt,
    });

    const estimatedDuration = estimateDuration(distanceKm);

    const order = await Order.create({
      client: clientId,
      pickup,
      delivery,
      packageDetails,
      pricing,
      distance: Math.round(distanceKm * 100) / 100,
      estimatedDuration,
      paymentMethod: paymentMethod || 'cash',
      scheduledAt,
      trackingHistory: [{
        status: 'pending',
        message: 'Фармоиш қабул карда шуд',
        timestamp: new Date(),
      }],
    });

    logger.info(`Order created: ${order.orderNumber} by client ${clientId}`);

    emitToAdmins('order:new', {
      orderId: order._id,
      orderNumber: order.orderNumber,
      clientId,
      pricing,
    });

    if (!scheduledAt) {
      setImmediate(() => dispatchService.dispatch(order));
    }

    return order;
  }

  async getOrderById(orderId, userId, userRole) {
    const order = await Order.findById(orderId)
      .populate('client', 'name phone avatar')
      .populate('courier', 'name phone avatar');

    if (!order) throw new AppError('Фармоиш ёфт нашуд', 404);

    if (userRole !== 'admin') {
      const isClient = order.client._id.toString() === userId.toString();
      const isCourier = order.courier && order.courier._id.toString() === userId.toString();
      if (!isClient && !isCourier) throw new AppError('Ба ин фармоиш дастрасӣ нест', 403);
    }

    return order;
  }

  async getClientOrders(clientId, page = 1, limit = 20, status) {
    const query = { client: clientId };
    if (status) query.status = status;

    const [orders, total] = await Promise.all([
      Order.find(query)
        .populate('courier', 'name phone avatar')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Order.countDocuments(query),
    ]);

    return { orders, total, page, totalPages: Math.ceil(total / limit) };
  }

  async getCourierOrders(courierId, page = 1, limit = 20) {
    const query = { courier: courierId };
    const [orders, total] = await Promise.all([
      Order.find(query)
        .populate('client', 'name phone')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Order.countDocuments(query),
    ]);
    return { orders, total, page, totalPages: Math.ceil(total / limit) };
  }

  async getAllOrders(page = 1, limit = 20, filters = {}) {
    const query = {};
    if (filters.status) query.status = filters.status;
    if (filters.startDate || filters.endDate) {
      query.createdAt = {};
      if (filters.startDate) query.createdAt.$gte = new Date(filters.startDate);
      if (filters.endDate) query.createdAt.$lte = new Date(filters.endDate);
    }

    const [orders, total] = await Promise.all([
      Order.find(query)
        .populate('client', 'name phone')
        .populate('courier', 'name phone')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Order.countDocuments(query),
    ]);

    return { orders, total, page, totalPages: Math.ceil(total / limit) };
  }

  async updateOrderStatus(orderId, courierId, newStatus) {
    const order = await Order.findById(orderId);
    if (!order) throw new AppError('Фармоиш ёфт нашуд', 404);

    if (order.courier.toString() !== courierId.toString()) {
      throw new AppError('Шумо иҷозат надоред', 403);
    }

    const allowedTransitions = {
      courier_assigned: ['courier_pickup'],
      courier_pickup: ['in_transit'],
      in_transit: ['delivered'],
    };

    const allowed = allowedTransitions[order.status];
    if (!allowed || !allowed.includes(newStatus)) {
      throw new AppError(`Ин тағйири ҳолат иҷозат дода намешавад: ${order.status} → ${newStatus}`, 400);
    }

    const statusMessages = {
      courier_pickup: 'Курьер дар роҳ аст',
      in_transit: 'Бастаи шумо дар роҳ аст',
      delivered: 'Бастаи шумо расонида шуд',
    };

    order.addTrackingEvent(newStatus, statusMessages[newStatus]);

    if (newStatus === 'courier_pickup') order.pickedUpAt = new Date();
    if (newStatus === 'delivered') {
      order.deliveredAt = new Date();
      order.paymentStatus = order.paymentMethod === 'cash' ? 'paid' : order.paymentStatus;

      const courier = await Courier.findOne({ user: courierId });
      if (courier) {
        courier.isAvailable = true;
        courier.currentOrder = null;
        courier.stats.totalDeliveries += 1;
        courier.stats.completedDeliveries += 1;
        courier.stats.totalEarnings += order.pricing.total * 0.8;
        await courier.save();
      }
    }

    await order.save();

    emitToUser(order.client.toString(), 'order:status_changed', {
      orderId: order._id,
      status: newStatus,
      message: statusMessages[newStatus],
    });
    emitToOrder(orderId.toString(), 'order:status_changed', { status: newStatus });
    emitToAdmins('order:status_changed', { orderId, status: newStatus });

    return order;
  }

  async cancelOrder(orderId, userId, userRole, reason) {
    const order = await Order.findById(orderId);
    if (!order) throw new AppError('Фармоиш ёфт нашуд', 404);

    const cancellableStatuses = ['pending', 'searching_courier', 'courier_assigned'];
    if (!cancellableStatuses.includes(order.status)) {
      throw new AppError('Ин фармоишро бекор кардан мумкин нест', 400);
    }

    if (userRole !== 'admin' && order.client.toString() !== userId.toString()) {
      throw new AppError('Иҷозат нест', 403);
    }

    order.addTrackingEvent('cancelled', reason || 'Фармоиш бекор карда шуд');
    order.cancelReason = reason;
    order.cancelledAt = new Date();

    if (order.courier) {
      const courier = await Courier.findOne({ user: order.courier });
      if (courier) {
        courier.isAvailable = true;
        courier.currentOrder = null;
        courier.stats.cancelledDeliveries += 1;
        await courier.save();
      }
      emitToUser(order.courier.toString(), 'order:cancelled', {
        orderId: order._id,
        message: 'Фармоиш бекор карда шуд',
      });
    }

    await order.save();

    emitToUser(order.client.toString(), 'order:cancelled', { orderId: order._id });
    emitToAdmins('order:cancelled', { orderId });

    return order;
  }

  async rateOrder(orderId, clientId, score, comment) {
    const order = await Order.findById(orderId);
    if (!order) throw new AppError('Фармоиш ёфт нашуд', 404);
    if (order.client.toString() !== clientId.toString()) throw new AppError('Иҷозат нест', 403);
    if (order.status !== 'delivered') throw new AppError('Танҳо фармоишҳои расонидашуда баҳогузорӣ шуда метавонанд', 400);
    if (order.rating.score) throw new AppError('Шумо аллакай баҳо додаед', 400);

    order.rating = { score, comment, ratedAt: new Date() };
    await order.save();

    if (order.courier) {
      const courier = await Courier.findOne({ user: order.courier });
      if (courier) {
        courier.updateRating(score);
        await courier.save();
      }
    }

    return order;
  }

  async estimateFare(pickupCoords, deliveryCoords) {
    const distanceKm = haversineDistance(
      pickupCoords.lat, pickupCoords.lng,
      deliveryCoords.lat, deliveryCoords.lng
    );
    const pricing = pricingService.calculate({ distanceKm });
    const duration = estimateDuration(distanceKm);
    return { pricing, distanceKm: Math.round(distanceKm * 100) / 100, estimatedDuration: duration };
  }
}

module.exports = new OrderService();

const Courier = require('../models/Courier');
const Order = require('../models/Order');
const { haversineDistance } = require('../utils/haversine');
const { pushToQueue, getRedisClient } = require('../config/redis');
const { emitToUser, emitToOrder, emitToAdmins } = require('../config/socket');
const logger = require('../utils/logger');

const DISPATCH_RADIUS_KM = 10;
const MAX_DISPATCH_ATTEMPTS = 5;
const COURIER_RESPONSE_TIMEOUT_MS = 30000;

class DispatchService {
  async dispatch(order) {
    try {
      logger.info(`Dispatching order: ${order.orderNumber}`);

      order.status = 'searching_courier';
      order.addTrackingEvent('searching_courier', 'Ҷустуҷӯи курьер');
      await order.save();

      emitToAdmins('order:status_changed', { orderId: order._id, status: 'searching_courier' });
      emitToUser(order.client.toString(), 'order:status_changed', {
        orderId: order._id,
        status: 'searching_courier',
        message: 'Ҷустуҷӯи курьер...',
      });

      await this._findAndAssign(order);
    } catch (err) {
      logger.error('Dispatch error:', err);
    }
  }

  async _findAndAssign(order) {
    if (order.dispatchAttempts >= MAX_DISPATCH_ATTEMPTS) {
      order.status = 'failed';
      order.addTrackingEvent('failed', 'Курьер ёфт нашуд');
      await order.save();
      emitToUser(order.client.toString(), 'order:failed', {
        orderId: order._id,
        message: 'Мутаассифона, курьер ёфт нашуд. Лутфан дубора кӯшиш кунед.',
      });
      return;
    }

    const availableCouriers = await Courier.find({
      isOnline: true,
      isAvailable: true,
      currentOrder: null,
      verificationStatus: 'verified',
    }).populate('user', 'name phone');

    if (!availableCouriers.length) {
      order.dispatchAttempts += 1;
      await order.save();
      logger.warn(`No available couriers for order ${order.orderNumber}, attempt ${order.dispatchAttempts}`);
      setTimeout(() => this._findAndAssign(order), 15000);
      return;
    }

    const pickup = order.pickup.coordinates;
    const nearestCouriers = availableCouriers
      .filter((c) => c.currentLocation && c.currentLocation.lat && c.currentLocation.lng)
      .map((c) => ({
        courier: c,
        distance: haversineDistance(pickup.lat, pickup.lng, c.currentLocation.lat, c.currentLocation.lng),
      }))
      .filter((c) => c.distance <= DISPATCH_RADIUS_KM)
      .sort((a, b) => a.distance - b.distance);

    if (!nearestCouriers.length) {
      order.dispatchAttempts += 1;
      await order.save();
      setTimeout(() => this._findAndAssign(order), 20000);
      return;
    }

    const selected = nearestCouriers[0].courier;
    await this._offerOrderToCourier(order, selected);
  }

  async _offerOrderToCourier(order, courier) {
    const redis = getRedisClient();
    const offerKey = `order:offer:${order._id}:${courier._id}`;
    await redis.setex(offerKey, 35, 'pending');

    emitToUser(courier.user._id.toString(), 'order:new_offer', {
      orderId: order._id,
      orderNumber: order.orderNumber,
      pickup: order.pickup,
      delivery: order.delivery,
      pricing: order.pricing,
      distance: order.distance,
      packageDetails: order.packageDetails,
      expiresIn: 30,
    });

    logger.info(`Order ${order.orderNumber} offered to courier ${courier.user.phone}`);

    setTimeout(async () => {
      const status = await redis.get(offerKey);
      if (status === 'pending') {
        await redis.del(offerKey);
        logger.info(`Courier ${courier.user.phone} did not respond to offer for order ${order.orderNumber}`);
        order.dispatchAttempts += 1;
        await order.save();
        const refreshedOrder = await Order.findById(order._id);
        if (refreshedOrder && refreshedOrder.status === 'searching_courier') {
          await this._findAndAssign(refreshedOrder);
        }
      }
    }, COURIER_RESPONSE_TIMEOUT_MS);
  }

  async acceptOrder(orderId, courierId) {
    const redis = getRedisClient();
    const lockKey = `order:lock:${orderId}`;
    const lock = await redis.set(lockKey, courierId.toString(), 'NX', 'EX', 30);
    if (!lock) throw new Error('Ин фармоиш аллакай қабул карда шуд');

    try {
      const order = await Order.findById(orderId);
      if (!order || order.status !== 'searching_courier') {
        await redis.del(lockKey);
        throw new Error('Фармоиш дастрас нест');
      }

      const courier = await Courier.findOne({ user: courierId });
      if (!courier || !courier.isAvailable) {
        await redis.del(lockKey);
        throw new Error('Курьер дастрас нест');
      }

      const offerKey = `order:offer:${orderId}:${courier._id}`;
      await redis.set(offerKey, 'accepted');

      order.courier = courierId;
      order.status = 'courier_assigned';
      order.addTrackingEvent('courier_assigned', 'Курьер фармоишро қабул кард');
      await order.save();

      courier.isAvailable = false;
      courier.currentOrder = order._id;
      await courier.save();

      await redis.del(lockKey);

      emitToUser(order.client.toString(), 'order:courier_assigned', {
        orderId: order._id,
        courierId,
        message: 'Курьер фармоишро қабул кард',
      });
      emitToOrder(orderId.toString(), 'order:status_changed', { status: 'courier_assigned' });
      emitToAdmins('order:status_changed', { orderId, status: 'courier_assigned', courierId });

      return order;
    } catch (err) {
      await redis.del(lockKey);
      throw err;
    }
  }

  async rejectOrder(orderId, courierId) {
    const courier = await Courier.findOne({ user: courierId });
    if (!courier) return;

    const redis = getRedisClient();
    const offerKey = `order:offer:${orderId}:${courier._id}`;
    await redis.set(offerKey, 'rejected');

    const order = await Order.findById(orderId);
    if (order && order.status === 'searching_courier') {
      order.dispatchAttempts += 1;
      await order.save();
      await this._findAndAssign(order);
    }
  }
}

module.exports = new DispatchService();

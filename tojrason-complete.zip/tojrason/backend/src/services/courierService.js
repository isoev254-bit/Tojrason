const Courier = require('../models/Courier');
const User = require('../models/User');
const { getRedisClient } = require('../config/redis');
const { emitToAdmins } = require('../config/socket');
const { AppError } = require('../middleware/errorHandler');
const logger = require('../utils/logger');

class CourierService {
  async getCourierProfile(userId) {
    const courier = await Courier.findOne({ user: userId })
      .populate('user', 'name phone email avatar isActive')
      .populate('currentOrder');
    if (!courier) throw new AppError('Профили курьер ёфт нашуд', 404);
    return courier;
  }

  async updateOnlineStatus(userId, isOnline) {
    const courier = await Courier.findOne({ user: userId });
    if (!courier) throw new AppError('Курьер ёфт нашуд', 404);

    courier.isOnline = isOnline;
    courier.isAvailable = isOnline ? courier.isAvailable : false;

    if (!isOnline) {
      const redis = getRedisClient();
      await redis.del(`courier:location:${userId}`);
    }

    await courier.save();
    emitToAdmins('courier:status_changed', { courierId: userId, isOnline });
    logger.info(`Courier ${userId} is now ${isOnline ? 'online' : 'offline'}`);
    return courier;
  }

  async updateAvailability(userId, isAvailable) {
    const courier = await Courier.findOne({ user: userId });
    if (!courier) throw new AppError('Курьер ёфт нашуд', 404);
    if (!courier.isOnline) throw new AppError('Аввал онлайн шавед', 400);

    courier.isAvailable = isAvailable;
    await courier.save();
    return courier;
  }

  async updateLocation(userId, lat, lng) {
    const courier = await Courier.findOne({ user: userId });
    if (!courier) throw new AppError('Курьер ёфт нашуд', 404);

    courier.updateLocation(lat, lng);
    await courier.save();

    const redis = getRedisClient();
    await redis.setex(`courier:location:${userId}`, 300, JSON.stringify({ lat, lng, timestamp: Date.now() }));

    return { lat, lng };
  }

  async getAllCouriers(page = 1, limit = 20, filters = {}) {
    const query = {};
    if (filters.isOnline !== undefined) query.isOnline = filters.isOnline;
    if (filters.verificationStatus) query.verificationStatus = filters.verificationStatus;
    if (filters.vehicleType) query.vehicleType = filters.vehicleType;

    const [couriers, total] = await Promise.all([
      Courier.find(query)
        .populate('user', 'name phone email avatar isActive createdAt')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Courier.countDocuments(query),
    ]);

    return { couriers, total, page, totalPages: Math.ceil(total / limit) };
  }

  async verifyCourier(courierId, status, adminId) {
    const courier = await Courier.findById(courierId).populate('user', 'name phone');
    if (!courier) throw new AppError('Курьер ёфт нашуд', 404);

    courier.verificationStatus = status;
    await courier.save();

    logger.info(`Courier ${courier.user.phone} ${status} by admin ${adminId}`);
    return courier;
  }

  async getOnlineCouriers() {
    const couriers = await Courier.find({ isOnline: true })
      .populate('user', 'name phone avatar')
      .select('currentLocation vehicleType isAvailable stats');

    const redis = getRedisClient();
    const enriched = await Promise.all(couriers.map(async (c) => {
      const locData = await redis.get(`courier:location:${c.user._id}`);
      const liveLocation = locData ? JSON.parse(locData) : null;
      return { ...c.toObject(), liveLocation };
    }));

    return enriched;
  }

  async getCourierStats(userId) {
    const courier = await Courier.findOne({ user: userId });
    if (!courier) throw new AppError('Курьер ёфт нашуд', 404);
    return courier.stats;
  }
}

module.exports = new CourierService();

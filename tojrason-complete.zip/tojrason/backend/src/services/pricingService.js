const PRICING_CONFIG = {
  baseFare: 5,
  perKmRate: 2.5,
  perKgRate: 0.5,
  minimumFare: 8,
  surcharges: {
    fragile: 2,
    night: 3,
    peak: 1.5,
    weekend: 1.2,
  },
  vehicleMultipliers: {
    on_foot: 0.8,
    bicycle: 0.9,
    motorcycle: 1.0,
    car: 1.3,
    van: 1.6,
  },
};

class PricingService {
  calculate({ distanceKm, weightKg = 1, fragile = false, scheduledAt = null, vehicleType = 'motorcycle' }) {
    const baseFare = PRICING_CONFIG.baseFare;
    const distanceFare = distanceKm * PRICING_CONFIG.perKmRate;
    const weightFare = weightKg > 1 ? (weightKg - 1) * PRICING_CONFIG.perKgRate : 0;

    let surcharge = 0;
    if (fragile) surcharge += PRICING_CONFIG.surcharges.fragile;

    const now = scheduledAt ? new Date(scheduledAt) : new Date();
    const hour = now.getHours();
    const dayOfWeek = now.getDay();

    if (hour >= 22 || hour < 7) surcharge += PRICING_CONFIG.surcharges.night;
    if ((hour >= 8 && hour <= 10) || (hour >= 17 && hour <= 19)) surcharge += PRICING_CONFIG.surcharges.peak;
    if (dayOfWeek === 0 || dayOfWeek === 6) surcharge += PRICING_CONFIG.surcharges.weekend;

    const vehicleMultiplier = PRICING_CONFIG.vehicleMultipliers[vehicleType] || 1.0;
    let total = (baseFare + distanceFare + weightFare + surcharge) * vehicleMultiplier;
    total = Math.max(total, PRICING_CONFIG.minimumFare);
    total = Math.round(total * 100) / 100;

    return {
      baseFare: Math.round(baseFare * 100) / 100,
      distanceFare: Math.round(distanceFare * 100) / 100,
      weightFare: Math.round(weightFare * 100) / 100,
      surcharge: Math.round(surcharge * vehicleMultiplier * 100) / 100,
      total,
      currency: 'TJS',
    };
  }

  estimateFare(distanceKm) {
    const min = this.calculate({ distanceKm }).total;
    const max = this.calculate({ distanceKm, fragile: true }).total * 1.2;
    return { min: Math.round(min * 100) / 100, max: Math.round(max * 100) / 100, currency: 'TJS' };
  }
}

module.exports = new PricingService();

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Ном талаб карда мешавад'],
    trim: true,
    minlength: [2, 'Ном бояд ҳадди аққал 2 ҳарф дошта бошад'],
    maxlength: [50, 'Ном бояд ҳадди аксар 50 ҳарф дошта бошад'],
  },
  phone: {
    type: String,
    required: [true, 'Рақами телефон талаб карда мешавад'],
    unique: true,
    trim: true,
    match: [/^\+?[1-9]\d{8,14}$/, 'Рақами телефон нодуруст аст'],
  },
  email: {
    type: String,
    unique: true,
    sparse: true,
    lowercase: true,
    trim: true,
    match: [/^\S+@\S+\.\S+$/, 'Суроғаи почтаи электронӣ нодуруст аст'],
  },
  password: {
    type: String,
    required: [true, 'Рамз талаб карда мешавад'],
    minlength: [6, 'Рамз бояд ҳадди аққал 6 рақам дошта бошад'],
    select: false,
  },
  role: {
    type: String,
    enum: ['client', 'courier', 'admin'],
    default: 'client',
  },
  avatar: {
    type: String,
    default: null,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  refreshTokens: [{
    token: String,
    createdAt: { type: Date, default: Date.now },
    expiresAt: Date,
  }],
  address: {
    street: String,
    city: { type: String, default: 'Душанбе' },
    coordinates: {
      lat: Number,
      lng: Number,
    },
  },
  totalOrders: { type: Number, default: 0 },
  lastLogin: Date,
  fcmToken: String,
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

userSchema.methods.toSafeObject = function () {
  const obj = this.toObject();
  delete obj.password;
  delete obj.refreshTokens;
  return obj;
};

userSchema.index({ phone: 1 });
userSchema.index({ role: 1 });
userSchema.index({ isActive: 1 });

module.exports = mongoose.model('User', userSchema);

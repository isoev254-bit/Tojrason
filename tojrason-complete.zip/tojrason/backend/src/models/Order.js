const mongoose = require('mongoose');

const coordinatesSchema = new mongoose.Schema({
  lat: { type: Number, required: true },
  lng: { type: Number, required: true },
}, { _id: false });

const locationSchema = new mongoose.Schema({
  address: { type: String, required: true },
  coordinates: { type: coordinatesSchema, required: true },
  contactName: String,
  contactPhone: String,
  notes: String,
}, { _id: false });

const trackingEventSchema = new mongoose.Schema({
  status: { type: String, required: true },
  message: String,
  timestamp: { type: Date, default: Date.now },
  coordinates: coordinatesSchema,
}, { _id: false });

const orderSchema = new mongoose.Schema({
  orderNumber: {
    type: String,
    unique: true,
    required: true,
  },
  client: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  courier: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  pickup: { type: locationSchema, required: true },
  delivery: { type: locationSchema, required: true },
  status: {
    type: String,
    enum: [
      'pending',
      'searching_courier',
      'courier_assigned',
      'courier_pickup',
      'in_transit',
      'delivered',
      'cancelled',
      'failed',
    ],
    default: 'pending',
  },
  packageDetails: {
    description: { type: String, required: true },
    weight: { type: Number, default: 1 },
    dimensions: {
      length: Number,
      width: Number,
      height: Number,
    },
    fragile: { type: Boolean, default: false },
    category: {
      type: String,
      enum: ['document', 'package', 'food', 'electronics', 'clothing', 'other'],
      default: 'other',
    },
  },
  pricing: {
    baseFare: { type: Number, default: 0 },
    distanceFare: { type: Number, default: 0 },
    weightFare: { type: Number, default: 0 },
    surcharge: { type: Number, default: 0 },
    total: { type: Number, required: true },
    currency: { type: String, default: 'TJS' },
  },
  distance: { type: Number, default: 0 },
  estimatedDuration: { type: Number, default: 0 },
  paymentMethod: {
    type: String,
    enum: ['cash', 'card', 'wallet'],
    default: 'cash',
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'refunded'],
    default: 'pending',
  },
  trackingHistory: [trackingEventSchema],
  courierLocation: coordinatesSchema,
  rating: {
    score: { type: Number, min: 1, max: 5, default: null },
    comment: String,
    ratedAt: Date,
  },
  dispatchAttempts: { type: Number, default: 0 },
  cancelReason: String,
  scheduledAt: Date,
  pickedUpAt: Date,
  deliveredAt: Date,
  cancelledAt: Date,
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

orderSchema.pre('save', async function (next) {
  if (this.isNew && !this.orderNumber) {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substr(2, 4).toUpperCase();
    this.orderNumber = `TJ-${timestamp}-${random}`;
  }
  next();
});

orderSchema.methods.addTrackingEvent = function (status, message, coordinates) {
  this.trackingHistory.push({ status, message, coordinates });
  this.status = status;
};

orderSchema.index({ client: 1, createdAt: -1 });
orderSchema.index({ courier: 1, status: 1 });
orderSchema.index({ status: 1, createdAt: -1 });
orderSchema.index({ orderNumber: 1 });
orderSchema.index({ 'pickup.coordinates': '2dsphere' });
orderSchema.index({ 'delivery.coordinates': '2dsphere' });

module.exports = mongoose.model('Order', orderSchema);

const mongoose = require('mongoose');

const courierSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true,
  },
  vehicleType: {
    type: String,
    enum: ['bicycle', 'motorcycle', 'car', 'van', 'on_foot'],
    required: true,
  },
  vehicleNumber: {
    type: String,
    trim: true,
  },
  licenseNumber: {
    type: String,
    trim: true,
  },
  isOnline: {
    type: Boolean,
    default: false,
  },
  isAvailable: {
    type: Boolean,
    default: false,
  },
  currentLocation: {
    lat: Number,
    lng: Number,
    updatedAt: { type: Date, default: Date.now },
  },
  currentOrder: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Order',
    default: null,
  },
  stats: {
    totalDeliveries: { type: Number, default: 0 },
    completedDeliveries: { type: Number, default: 0 },
    cancelledDeliveries: { type: Number, default: 0 },
    totalEarnings: { type: Number, default: 0 },
    averageRating: { type: Number, default: 0 },
    totalRatings: { type: Number, default: 0 },
  },
  workingHours: {
    start: { type: String, default: '08:00' },
    end: { type: String, default: '22:00' },
  },
  documents: {
    idCard: String,
    driverLicense: String,
    vehicleRegistration: String,
  },
  verificationStatus: {
    type: String,
    enum: ['pending', 'verified', 'rejected'],
    default: 'pending',
  },
  bankDetails: {
    accountNumber: String,
    bankName: String,
  },
  zone: {
    type: String,
    default: 'Душанбе',
  },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

courierSchema.methods.updateLocation = function (lat, lng) {
  this.currentLocation = { lat, lng, updatedAt: new Date() };
};

courierSchema.methods.updateRating = function (newScore) {
  const total = this.stats.totalRatings + 1;
  const avg = ((this.stats.averageRating * this.stats.totalRatings) + newScore) / total;
  this.stats.averageRating = Math.round(avg * 10) / 10;
  this.stats.totalRatings = total;
};

courierSchema.index({ 'currentLocation': 1 });
courierSchema.index({ isOnline: 1, isAvailable: 1 });
courierSchema.index({ user: 1 });

module.exports = mongoose.model('Courier', courierSchema);

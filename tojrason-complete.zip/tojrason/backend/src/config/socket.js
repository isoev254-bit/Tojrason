const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');
const { getRedisClient } = require('./redis');

let io = null;

function initSocket(server) {
  io = new Server(server, {
    cors: {
      origin: [
        process.env.CLIENT_URL || 'http://localhost:3000',
        process.env.ADMIN_URL || 'http://localhost:3001',
      ],
      methods: ['GET', 'POST'],
      credentials: true,
    },
    pingTimeout: 60000,
    pingInterval: 25000,
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];
    if (!token) return next(new Error('Authentication error'));

    try {
      const decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
      socket.userId = decoded.id;
      socket.userRole = decoded.role;
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.id} user: ${socket.userId}`);

    socket.join(`user:${socket.userId}`);
    if (socket.userRole === 'admin') socket.join('admin-room');

    socket.on('courier:location_update', async (data) => {
      try {
        const redis = getRedisClient();
        const locationData = {
          courierId: socket.userId,
          lat: data.lat,
          lng: data.lng,
          timestamp: Date.now(),
          orderId: data.orderId || null,
        };
        await redis.setex(`courier:location:${socket.userId}`, 300, JSON.stringify(locationData));

        if (data.orderId) {
          io.to(`order:${data.orderId}`).emit('courier:location', locationData);
        }
        io.to('admin-room').emit('courier:location', locationData);
      } catch (err) {
        logger.error('Socket location update error:', err);
      }
    });

    socket.on('join:order', (orderId) => {
      socket.join(`order:${orderId}`);
      logger.info(`User ${socket.userId} joined order room: ${orderId}`);
    });

    socket.on('leave:order', (orderId) => {
      socket.leave(`order:${orderId}`);
    });

    socket.on('disconnect', (reason) => {
      logger.info(`Socket disconnected: ${socket.id}, reason: ${reason}`);
    });
  });

  return io;
}

function getIO() {
  if (!io) throw new Error('Socket.io not initialized');
  return io;
}

function emitToUser(userId, event, data) {
  if (io) io.to(`user:${userId}`).emit(event, data);
}

function emitToOrder(orderId, event, data) {
  if (io) io.to(`order:${orderId}`).emit(event, data);
}

function emitToAdmins(event, data) {
  if (io) io.to('admin-room').emit(event, data);
}

module.exports = { initSocket, getIO, emitToUser, emitToOrder, emitToAdmins };

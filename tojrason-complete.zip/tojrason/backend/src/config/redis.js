const Redis = require('ioredis');
const logger = require('../utils/logger');

let redisClient = null;

async function connectRedis() {
  try {
    redisClient = new Redis(process.env.REDIS_URL || 'redis://localhost:6379', {
      retryStrategy(times) {
        const delay = Math.min(times * 50, 2000);
        return delay;
      },
      maxRetriesPerRequest: 3,
      enableReadyCheck: true,
      lazyConnect: true,
    });

    redisClient.on('connect', () => logger.info('Redis connected'));
    redisClient.on('error', (err) => logger.error('Redis error:', err.message));
    redisClient.on('reconnecting', () => logger.warn('Redis reconnecting...'));

    await redisClient.connect();
    return redisClient;
  } catch (error) {
    logger.error('Redis connection failed:', error.message);
    throw error;
  }
}

function getRedisClient() {
  if (!redisClient) throw new Error('Redis not initialized');
  return redisClient;
}

async function setCache(key, value, ttlSeconds = 3600) {
  const client = getRedisClient();
  await client.setex(key, ttlSeconds, JSON.stringify(value));
}

async function getCache(key) {
  const client = getRedisClient();
  const data = await client.get(key);
  return data ? JSON.parse(data) : null;
}

async function deleteCache(key) {
  const client = getRedisClient();
  await client.del(key);
}

async function pushToQueue(queueName, data) {
  const client = getRedisClient();
  await client.rpush(queueName, JSON.stringify(data));
}

async function popFromQueue(queueName) {
  const client = getRedisClient();
  const data = await client.lpop(queueName);
  return data ? JSON.parse(data) : null;
}

async function getQueueLength(queueName) {
  const client = getRedisClient();
  return await client.llen(queueName);
}

module.exports = {
  connectRedis,
  getRedisClient,
  setCache,
  getCache,
  deleteCache,
  pushToQueue,
  popFromQueue,
  getQueueLength,
};

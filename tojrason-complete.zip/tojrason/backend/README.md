# Tojrason Backend API

## Технология
- Node.js + Express
- MongoDB + Mongoose
- Redis (кешинг ва навбат)
- Socket.io (реалвақт)
- JWT аутентификатсия

## Оғоз

```bash
cp .env.example .env
# .env-ро пур кунед

npm install
npm run dev
```

## Docker

```bash
docker-compose up -d
```

## API Endpoints

| Метод | Роҳ | Тавсиф |
|-------|-----|--------|
| POST | /api/auth/register | Ба қайд гирифтан |
| POST | /api/auth/login | Ворид шудан |
| POST | /api/auth/refresh | Токенро нав кардан |
| GET  | /api/auth/profile | Профили корбар |
| POST | /api/orders | Сохтани фармоиш |
| GET  | /api/orders/my | Фармоишҳои ман |
| GET  | /api/orders/:id | Фармоиш аз рӯи ID |
| POST | /api/orders/:id/cancel | Бекор кардан |
| PATCH| /api/orders/:id/status | Навсозии ҳолат |
| GET  | /api/couriers/me | Профили курьер |
| PUT  | /api/couriers/me/online | Ҳолати онлайн |
| PUT  | /api/couriers/me/location | Мавқеияти курьер |

## Муҳити кор

```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/tojrason
REDIS_URL=redis://localhost:6379
JWT_ACCESS_SECRET=secret
JWT_REFRESH_SECRET=secret
```

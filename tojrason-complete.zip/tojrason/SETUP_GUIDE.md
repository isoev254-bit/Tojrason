# Роҳнамои насб ва ба кор андохтани Тоҷрасон

## Сохтори лоиҳа

```
tojrason/
├── backend/          ← Node.js + Express + MongoDB + Redis
├── admin-panel/      ← React.js панели идоракунӣ
├── client-app/       ← React Native барои муштариён
├── courier-app/      ← React Native барои курьерон
└── docker-compose.yml
```

---

## 1. Талаботи системавӣ

- Node.js >= 18.0.0
- MongoDB 7.0
- Redis 7.2
- Docker + Docker Compose (барои насби осон)
- Android Studio / Xcode (барои мобил)

---

## 2. Backend — оғоз

### Роҳи 1: Бо Docker (тавсия мешавад)

```bash
cd tojrason

# Файли .env-ро аз .env.example сохтед
cp backend/.env.example backend/.env

# Калидҳои JWT-ро иваз кунед
# JWT_ACCESS_SECRET=xxxxxxxxxxxxxxxxxx
# JWT_REFRESH_SECRET=xxxxxxxxxxxxxxxxxx

# Оғоз кунед
docker-compose up -d

# Тафтиш кунед
curl http://localhost:5000/health
```

### Роҳи 2: Бидуни Docker

```bash
cd backend
cp .env.example .env
# .env-ро таҳрир кунед

npm install
npm run dev
```

---

## 3. Admin Panel — оғоз

```bash
cd admin-panel
cp .env.example .env
# REACT_APP_API_URL=http://localhost:5000/api
# REACT_APP_SOCKET_URL=http://localhost:5000

npm install
npm start
# http://localhost:3001 дар браузер
```

### Сохтмони истеҳсолӣ

```bash
npm run build
# Папкаи build/-ро ба Vercel/Netlify бор кунед
```

---

## 4. Client App — оғоз

```bash
cd client-app
cp .env.example .env
# API_URL=http://10.0.2.2:5000/api   ← Android Emulator
# API_URL=http://localhost:5000/api  ← iOS Simulator

npm install

# Android
npx react-native run-android

# iOS
cd ios && pod install && cd ..
npx react-native run-ios
```

---

## 5. Courier App — оғоз

```bash
cd courier-app
cp .env.example .env
npm install

# Android
npx react-native run-android

# iOS
cd ios && pod install && cd ..
npx react-native run-ios
```

---

## 6. Базаи маълумот — Схема

### Коллексия Users
```json
{
  "_id": "ObjectId",
  "name": "string",
  "phone": "string (unique)",
  "email": "string (optional)",
  "password": "hashed string",
  "role": "client | courier | admin",
  "isActive": "boolean",
  "isVerified": "boolean",
  "address": { "street": "string", "city": "string", "coordinates": { "lat": number, "lng": number } },
  "totalOrders": "number",
  "lastLogin": "Date",
  "fcmToken": "string",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Коллексия Orders
```json
{
  "_id": "ObjectId",
  "orderNumber": "string (TJ-XXXXX-XXXX)",
  "client": "ObjectId → Users",
  "courier": "ObjectId → Users",
  "pickup": {
    "address": "string",
    "coordinates": { "lat": number, "lng": number },
    "contactName": "string",
    "contactPhone": "string",
    "notes": "string"
  },
  "delivery": { "...same as pickup..." },
  "status": "pending | searching_courier | courier_assigned | courier_pickup | in_transit | delivered | cancelled | failed",
  "packageDetails": {
    "description": "string",
    "weight": "number",
    "fragile": "boolean",
    "category": "document | package | food | electronics | clothing | other"
  },
  "pricing": {
    "baseFare": "number",
    "distanceFare": "number",
    "weightFare": "number",
    "surcharge": "number",
    "total": "number",
    "currency": "TJS"
  },
  "distance": "number (km)",
  "estimatedDuration": "number (minutes)",
  "paymentMethod": "cash | card | wallet",
  "paymentStatus": "pending | paid | refunded",
  "trackingHistory": [{ "status": "string", "message": "string", "timestamp": "Date" }],
  "rating": { "score": "1-5", "comment": "string", "ratedAt": "Date" },
  "createdAt": "Date"
}
```

### Коллексия Couriers
```json
{
  "_id": "ObjectId",
  "user": "ObjectId → Users",
  "vehicleType": "bicycle | motorcycle | car | van | on_foot",
  "vehicleNumber": "string",
  "isOnline": "boolean",
  "isAvailable": "boolean",
  "currentLocation": { "lat": number, "lng": number, "updatedAt": "Date" },
  "currentOrder": "ObjectId → Orders",
  "stats": {
    "totalDeliveries": "number",
    "completedDeliveries": "number",
    "totalEarnings": "number",
    "averageRating": "number"
  },
  "verificationStatus": "pending | verified | rejected"
}
```

---

## 7. API Ҳуҷҷатнигорӣ

### Аутентификатсия

| Метод | Endpoint | Тавсиф | Роль |
|-------|----------|--------|------|
| POST | /api/auth/register | Ба қайд гирифтан | ҳама |
| POST | /api/auth/login | Ворид шудан | ҳама |
| POST | /api/auth/refresh | Нав кардани токен | ҳама |
| POST | /api/auth/logout | Хуруҷ | аутентификатсия |
| GET  | /api/auth/profile | Профили худ | аутентификатсия |
| PUT  | /api/auth/profile | Навсозии профил | аутентификатсия |

### Фармоишҳо

| Метод | Endpoint | Тавсиф | Роль |
|-------|----------|--------|------|
| GET  | /api/orders/estimate?pickupLat=&pickupLng=&deliveryLat=&deliveryLng= | Нархи тахминӣ | аут. |
| POST | /api/orders | Сохтани фармоиш | client |
| GET  | /api/orders/my | Фармоишҳои ман | client |
| GET  | /api/orders/courier/my | Фармоишҳои курьер | courier |
| GET  | /api/orders/stats | Омор | admin |
| GET  | /api/orders | Ҳамаи фармоишҳо | admin |
| GET  | /api/orders/:id | Фармоиш аз рӯи ID | аут. |
| POST | /api/orders/:id/cancel | Бекор кардан | client, admin |
| PATCH| /api/orders/:id/status | Навсозии ҳолат | courier |
| POST | /api/orders/:id/accept | Қабул кардан | courier |
| POST | /api/orders/:id/reject | Рад кардан | courier |
| POST | /api/orders/:id/rate | Баҳо додан | client |

### Курьерон

| Метод | Endpoint | Тавсиф | Роль |
|-------|----------|--------|------|
| GET  | /api/couriers/me | Профили худ | courier |
| PUT  | /api/couriers/me/online | Ҳолати онлайн | courier |
| PUT  | /api/couriers/me/availability | Дастрасӣ | courier |
| PUT  | /api/couriers/me/location | Мавқеият | courier |
| GET  | /api/couriers/me/stats | Омор | courier |
| GET  | /api/couriers/online | Курьерони онлайн | admin, client |
| GET  | /api/couriers | Ҳамаи курьерон | admin |
| PUT  | /api/couriers/:id/verify | Тасдиқ/Рад | admin |

### Корбарон

| Метод | Endpoint | Тавсиф | Роль |
|-------|----------|--------|------|
| GET  | /api/users | Ҳамаи корбарон | admin |
| GET  | /api/users/:id | Корбар аз рӯи ID | admin |
| PUT  | /api/users/:id | Навсозии корбар | admin |
| DELETE | /api/users/:id | Ғайрифаъол кардан | admin |

---

## 8. Socket.io Рӯйдодҳо

### Client → Server
```
courier:location_update  { lat, lng, orderId }  ← Мавқеияти курьер
join:order               orderId                ← Пайвастан ба хонаи фармоиш
leave:order              orderId                ← Ҷудо шудан
```

### Server → Client
```
order:new               { orderId, orderNumber, pickup, delivery, pricing }
order:status_changed    { orderId, status, message }
order:courier_assigned  { orderId, courierId }
order:cancelled         { orderId }
order:failed            { orderId }
order:new_offer         { orderId, pickup, delivery, pricing, expiresIn }
courier:location        { courierId, lat, lng, timestamp, orderId }
courier:status_changed  { courierId, isOnline }
```

---

## 9. Насб дар сервер (VPS/AWS)

### Backend бо Nginx

```nginx
server {
    listen 80;
    server_name api.tojrason.tj;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# SSL бо Certbot
sudo certbot --nginx -d api.tojrason.tj
```

### Admin Panel бо Vercel

```bash
cd admin-panel
npm run build
# Vercel CLI
npx vercel --prod
```

### Тағйирёбандаҳои муҳити истеҳсолӣ

```env
NODE_ENV=production
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/tojrason
REDIS_URL=redis://user:pass@redis-host:6379
JWT_ACCESS_SECRET=<хеле дарози тасодуфӣ - ҳадди аққал 64 рақам>
JWT_REFRESH_SECRET=<дигар калиди тасодуфӣ>
CLIENT_URL=https://app.tojrason.tj
ADMIN_URL=https://admin.tojrason.tj
```

---

## 10. Сохтани аввалин администратор

```javascript
// Ин скриптро як маротиба иҷро кунед
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

mongoose.connect(process.env.MONGODB_URI);

const User = require('./src/models/User');

async function createAdmin() {
  const admin = await User.create({
    name: 'Суперадмин',
    phone: '+992900000001',
    password: 'Admin@2024',
    role: 'admin',
    isActive: true,
    isVerified: true,
  });
  console.log('Администратор сохта шуд:', admin.phone);
  process.exit(0);
}

createAdmin();
```

```bash
node create-admin.js
```

---

## 11. Санҷиши системавӣ

```bash
# Backend health check
curl http://localhost:5000/health

# Ба қайд гирифтан
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Тест Корбар","phone":"+992901234567","password":"test123","role":"client"}'

# Ворид шудан
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"+992901234567","password":"test123"}'
```
